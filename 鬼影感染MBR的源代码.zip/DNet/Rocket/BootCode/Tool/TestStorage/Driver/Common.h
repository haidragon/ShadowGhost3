#define	_X86_

#ifdef	__cplusplus
	extern	"C"
	{
#endif

#include <ntddk.h>
#include <conio.h>

#ifdef	__cplusplus
	}
#endif



#define IOCTL_DISK_INITIAL			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90E, METHOD_IN_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_DISK_READWRITE		CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90F, METHOD_IN_DIRECT, FILE_ANY_ACCESS)


typedef	unsigned long	DWORD;