////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RBuild.rc
//
#define IDD_RBUILD_DIALOG               102
#define IDR_MAINFRAME                   128
#define FILE_Rocket                     129
#define FILE_SR                         130
#define FILE_Rdrv                       131
#define BootLoader                      136
#define NTFSdriver                      137
#define DiskDD                          138
#define DiskSystem                      139
#define FATdriver                       140
#define icl_Error                       141
#define icl_KS                          142
#define icl_MF                          143
#define nasm                            146
#define FILE_ASPack                     147
#define FILE_ASPackini                  148
#define FILE_VMPCON                     149
#define FILE_PROJECT                    150
#define IDR_FILE2                       151
#define FILE_MAP                        151
#define IDC_BUTTON1                     1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003
#define IDC_EDIT5                       1004
#define IDC_EDIT6                       1005
#define IDC_EDIT7                       1006
#define IDC_BUTTON2                     1007
#define IDC_EDIT8                       1008
#define IDC_EDIT9                       1009
#define IDC_EDIT10                      1010
#define IDC_EDIT11                      1011
#define IDC_EDIT12                      1012
#define IDC_CHECK1                      1013
#define IDC_CHECK2                      1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
