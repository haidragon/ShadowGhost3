////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#define	_X86_

#ifdef	__cplusplus
	extern	"C"
	{
#endif

#include <ntddk.h>
#include <conio.h>
#include <stdio.h>

#ifdef	__cplusplus
	}
#endif


#define IOCTL_INITIAL				CTL_CODE(FILE_DEVICE_UNKNOWN, 0x910, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_KILLPROCESS			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x911, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_DISK_INITIAL			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90E, METHOD_IN_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_DISK_READWRITE		CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90F, METHOD_IN_DIRECT, FILE_ANY_ACCESS)



typedef	unsigned long	DWORD;

typedef	struct	__INITIALDRIVER{
	DWORD	dwAddr_MmGetSystemRoutineAddress;
	DWORD	dwAddr_PspTerminateThreadByPointer;
	DWORD	dwAddr_KeInsertQueueApc;
	DWORD	dwAddr_KiInsertQueueApc;

	char	cPspTerminateThreadByPointerHead[12];
	char	cKeInsertQueueApcHead[12];
	char	cKiInsertQueueApcHead[12];

	DWORD	dwThreadListHeadOffset;
	DWORD	dwThreadListEntryOffset;
}INITIALDRIVER, *PINITIALDRIVER;


extern	INITIALDRIVER			g_InitialDirver;
extern	RTL_OSVERSIONINFOEXW	g_OSVersionInfo;