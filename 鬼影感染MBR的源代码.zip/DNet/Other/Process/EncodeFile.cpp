#include "WinMain.h"

//>>>>>>>>>>>>>>>>>>>>> code <<<<<<<<<<<<<<<<<<<<<<<
//���ݵ�ǰϵͳʱ��Ϊ����,����һ�������
int	GetRandomVal()
{
	int		iResult = 0;
	SYSTEMTIME	time;

	memset(&time, 0, sizeof(time));
	GetSystemTime( &time );
	srand( (unsigned int)time.wMilliseconds );
	iResult = rand();
	
	return	iResult;
}

//dwInputSize һ��Ҫ�� 4 �ֽڶ���
BOOL Encode(char *pInput, DWORD	dwInputSize, DWORD dwRendomVal, DWORD dwFlag)
{
	DWORD	*pDword = NULL, dwAlign= 0, dwLastVal = 0, dwMoveBit = 0, dwRO = 0;


	//�Ƿ� 4�ֽ� ����?
	dwAlign = dwInputSize % sizeof(DWORD);
	if(dwAlign != 0)
	{
		return	FALSE;
	}

	//�ƶ������һ��DWORD
	pDword = ( (DWORD*)(pInput + dwInputSize) ) - 1;

	//���һ��ֵ
	dwLastVal = ~( *pDword ^ dwRendomVal );
	dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
	__asm	//ѭ������
	{
		push	ecx;
		mov		ecx, dwMoveBit;
		ROR		dword ptr [dwLastVal], cl;
		pop		ecx;
	}
	dwLastVal = dwLastVal - dwRendomVal;
	*pDword = dwLastVal;
			
	//�� 4�ֽ� �������
	pDword -- ;
	while((DWORD)pDword >= (DWORD)pInput)
	{
		DWORD	dwCurrentVal = 0, dwNextVal = 0;


		dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
		dwRO = dwMoveBit & 0x04;

		dwCurrentVal = ~( *(pDword) - *(pDword + 1) - dwRendomVal ) ^ dwRendomVal;
		//����ǰƫ����λ

		if(dwRO > 1)	//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROL		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}
		else			//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROR		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}

		*pDword = dwCurrentVal;

		pDword --;
	}
	
	return TRUE;
}

//������� 155�ֽ�����
BOOL Decode(char *pInput, DWORD	dwInputSize, DWORD dwRendomVal, DWORD dwFlag)
{
	DWORD	*pDword = NULL, *pLast = NULL, dwAlign = 0;


	//�Ƿ� 4�ֽ� ����?
	dwAlign = dwInputSize % sizeof(DWORD);
	if(dwAlign != 0)
	{
		return FALSE;
	}
	pLast = ( (DWORD*)(pInput + dwInputSize) ) - 1;
	pDword = (DWORD*)pInput;
	while(true)
	{
		DWORD	dwCurrentVal = 0, dwMoveBit = 0, dwRO = 0;


		dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
		dwRO = dwMoveBit & 0x04;
		dwCurrentVal = *pDword;
		if(dwRO < 1)	//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROL		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}
		else			//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROR		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}
		*pDword = (~(dwCurrentVal ^ dwRendomVal) ) + dwRendomVal + *(pDword + 1);
		
		pDword ++;
		if( pDword >= pLast)	//��������һ��ֵ
		{
			DWORD	dwLastVal = 0;

			dwLastVal = *pDword + dwRendomVal;
			dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
			__asm	//ѭ������
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROL		dword ptr [dwLastVal], cl;
				pop		ecx;
			}
			*pDword = (~dwLastVal) ^ dwRendomVal;
			break;
		}
	}

	return TRUE;
}

DWORD EncodeFile(char *szSrcFile, char *szDestFile)
{
	char	*pFileByte = NULL;
	DWORD	dwFileSize = 0, dwTemp = 0, dwByte = 0, dwAlign = 0, dwRendomValue = 0;
	HANDLE	hFile = INVALID_HANDLE_VALUE, hMap = NULL;


	if(PathFileExists( szDestFile ) == TRUE)
	{
		DeleteFile( szDestFile );
	}
	CopyFile(szSrcFile, szDestFile, FALSE);

	hFile = CreateFile(szDestFile, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	dwFileSize = GetFileSize(hFile, NULL);

	//Ŀ���ļ��Ƿ� 4�ֽڶ���? �������� ����� ����
	dwAlign = dwFileSize % sizeof(DWORD);
	if(dwAlign != 0)
	{
		SetFilePointer(hFile, 0, 0, FILE_END);
		dwTemp = GetRandomVal();
		WriteFile(hFile, &dwTemp, (sizeof(DWORD) - dwAlign), &dwByte, NULL);
		SetEndOfFile( hFile );
		//�����ļ���С
		dwFileSize = dwFileSize + (sizeof(DWORD) - dwAlign);
	}

	hMap = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, NULL);		//��дȨ��
	pFileByte = (char*)MapViewOfFile(hMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);	//Ӱ�������ļ�

	dwRendomValue = GetRandomVal();

	//ͷ������������ֵ
	*(DWORD*)pFileByte = dwRendomValue;

	if( Encode(pFileByte + sizeof(DWORD), dwFileSize - 4, *(DWORD*)pFileByte, 1) == FALSE)
	{
		MessageBox(NULL, "�����ļ�ʱ��������!", "����", MB_OK);
		return -1;
	}

	////Decode(pFileByte, dwFileSize, dwRendomValue, 1);

	UnmapViewOfFile( pFileByte );
	CloseHandle( hMap );
	CloseHandle( hFile );

	return dwRendomValue;
}

void SYSandDLL(char *szParam)
{
	DWORD	dwRandomVal = 0;
	char	*pSrcFilePath = NULL, *pDestFilePath = NULL;


	pSrcFilePath = szParam;
	pDestFilePath = szParam + lstrlen(szParam) + 1;

	dwRandomVal = EncodeFile(pSrcFilePath, pDestFilePath);
	printf("%s -> %s �������, �������ֵ: 0x%X\n", pSrcFilePath, pDestFilePath, dwRandomVal);

	return;
}