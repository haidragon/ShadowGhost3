#include "E:\Products\MFD\WorkApp\Common.h"


//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//
extern	char	g_szSystemPath[MAX_PATH];
extern	HANDLE	g_hDriver;
//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//

//--------------------------------------------------------------------------//

#define	SECTORSIZE	512		//������С

#define IOCTL_DISK_INITIAL			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90E, METHOD_IN_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_DISK_READWRITE		CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90F, METHOD_IN_DIRECT, FILE_ANY_ACCESS)

#pragma pack(1)
typedef	struct	__RWINFO{
	unsigned __int64	LBA;
	USHORT	usSectorCount;
	DWORD	dwOperateSize;
	DWORD	dwFlags;
}RWINFO, *PRWINFO;
#pragma pack()

DWORD	g_dwCurHDDId = 0, g_dwDiskInitial = 0;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//��ȡϵͳ�����ڵ�Ӳ�̵�MBR��'Windows disk signature'
DWORD GetCurHDDSign()
{
	DWORD	dwSignature = 0;
	char	szVN[MAX_PATH];
	HANDLE	hFile = INVALID_HANDLE_VALUE;


	//��·��
	wsprintf(szVN, "\\\\.\\%C:", *g_szSystemPath);

	//��ȡ�˷���(��)��Ϣ
	hFile = CreateFile(szVN, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
	if(hFile != INVALID_HANDLE_VALUE)
	{
		char	cOutBuf[512];//ע���С
		DWORD	dwByte = 0;
		

		memset(cOutBuf, 0, sizeof(cOutBuf));
		if(DeviceIoControl(hFile, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, NULL, 0, cOutBuf, sizeof(cOutBuf), &dwByte, NULL) == TRUE)
		{
			dwSignature = (DiskGeometryGetPartition( (DISK_GEOMETRY_EX*)&cOutBuf[0] ))->Mbr.Signature;
		}

		CloseHandle( hFile );
	}

	return dwSignature;
}

BOOL DiskInitial()
{
	if(g_hDriver != INVALID_HANDLE_VALUE)
	{
		DWORD	dwByte = 0, dwSignatrue = 0;

		dwSignatrue = GetCurHDDSign();
		if(dwSignatrue != 0)
		{
			return DeviceIoControl(g_hDriver, IOCTL_DISK_INITIAL, &dwSignatrue, sizeof(dwSignatrue), NULL, 0, &dwByte, NULL);
		}
		//////else
		//////{
		//////	//��ȡӲ�̵����к�,�����кŽ���ƥ��
		//////	//CreateFile(volume,....)
		//////	//DeviceIoControl(, IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS, ....)
		//////	//CreateFile(\\\\.\\PhysicalDrive + DISK_EXTENT.DiskNumber, .... )
		//////	//DeivceIoControl(, SMART_RCV_DRIVE_DATA, )
		//////	;
		//////}
	}

	return FALSE;
}

//1 - ��, 2 - д
DWORD DiskReadWrite(unsigned __int64 LBA, USHORT usSectorCount, char *pBuffer, DWORD dwBufSize, DWORD dwFlags)
{
	#define	SECTIONSIZE		512

	DWORD	dwResult = 0, dwByte = 0;
	RWINFO	RwInfo;



	//�����Ҫ,��ʼ��
	if(g_dwDiskInitial == 0)
	{
		g_dwDiskInitial = 1;
		if(DiskInitial() == FALSE)
		{
			g_dwDiskInitial = 2;
		}
	}
	if(g_dwDiskInitial != 1)
	{
		dwResult = 2;
		goto __END;
	}

	//�������
	if((usSectorCount < 1) || dwBufSize < (SECTORSIZE * (DWORD)usSectorCount))
	{
		dwResult = 1;
		goto __END; 
	}

	//����
	RwInfo.LBA = LBA;
	RwInfo.usSectorCount = usSectorCount;
	RwInfo.dwOperateSize = RwInfo.usSectorCount * SECTORSIZE;
	RwInfo.dwFlags = dwFlags;

	if(DeviceIoControl(g_hDriver, IOCTL_DISK_READWRITE, &RwInfo, sizeof(RwInfo), pBuffer/*ע��*/, dwBufSize, &dwByte, NULL) == FALSE)
	{
		dwResult = 3;
		goto __END;
	}

__END:
	return dwResult;
}