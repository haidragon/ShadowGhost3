#include "stdafx.h"
#include "RBuild.h"
#include "RBuildDlg.h"

//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//

//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//

//--------------------------------------------------------------------------//

char	*g_pFileName[] = {
	"Disk System.asm",
	"Disk Device Driver.asm",
	"NTFS driver.asm",
	"FAT driver.asm"
};


DWORD	g_dwPileCount = 0;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//�ҵ��ļ��еİ�׮���, ���ð�׮
BOOL EditFile(char *pDir, char *pFileName, char *pExeData, DWORD dwExeSize)
{
	BOOL	bState = TRUE;
	char	szCurFile[MAX_PATH], *pFileByte = NULL, *pMove = NULL;
	DWORD	dwFileSize = 0;
	HANDLE	hFile = INVALID_HANDLE_VALUE, hMap = NULL;

	//�ļ�ӳ��
	wsprintfA(szCurFile, "%s\\%s", pDir, pFileName);
	hFile = CreateFileA(szCurFile, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		bState = FALSE;
		goto __END;
	}
	dwFileSize = GetFileSize(hFile, NULL);
	hMap = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, NULL);
	pFileByte = (char*)MapViewOfFile(hMap, FILE_MAP_ALL_ACCESS, 0, 0, dwFileSize);
	if(pFileByte == NULL)
	{
		bState = FALSE;
		goto __END;
	}

	//�����ַ���
	pMove = pFileByte;
	for(;;)
	{
		char	*pVal = NULL, cTemp[512];
		DWORD	dwOffset = 0, dwValSize = 0, dwCurVal = 0;

		pMove = strstr(pMove, ";//��׮:");
		if(pMove == NULL)
		{
			break;
		}

		//val
		pVal = strstr(pMove, "0x") + 2;

		//offset
		pMove = strstr(pVal, "0x") + 2;
		memset(cTemp, 0, sizeof(cTemp));
		memcpy(cTemp, pMove, 4);
		dwOffset = strtoul(cTemp, NULL, 16);

		//valsize
		pMove = strstr(pMove, "\x09\x09") + 2;
		memset(cTemp, 0, sizeof(cTemp));
		memcpy(cTemp, pMove, 1);
		dwValSize = strtoul(cTemp, NULL, 16);

		memset(cTemp, 0, sizeof(cTemp));
		switch(dwValSize)
		{
			case 1:
				 {
					 if(dwOffset <= (dwExeSize - sizeof(DWORD)))
					 {
						 dwCurVal = (DWORD)(*(unsigned char*)(pExeData + dwOffset));
					 }
					 else
					 {
						 dwCurVal = 0;
					 }
					 wsprintfA(cTemp, "%.2X", dwCurVal);
				 }
				 break;
			case 2:
				 {
					 if(dwOffset <= (dwExeSize - sizeof(DWORD)))
					 {
						 dwCurVal = (DWORD)(*(WORD*)(pExeData + dwOffset));
					 }
					 else
					 {
						 dwCurVal = 0;
					 }
					 wsprintfA(cTemp, "%.4X", dwCurVal);
				 }
				 break;
			case 4:
				 {
					 if(dwOffset <= (dwExeSize - sizeof(DWORD)))
					 {
						 dwCurVal = (DWORD)(*(DWORD*)(pExeData + dwOffset));
					 }
					 else
					 {
						 dwCurVal = 0;
					 }
					 wsprintfA(cTemp, "%.8X", dwCurVal);
				 }
				 break;
			default:
				{
					bState = FALSE;
					goto __END;
				}
		}
		memcpy(pVal, cTemp, (dwValSize * 2));

		//ͳ��,��¼
		g_dwPileCount ++;
	}

__END:
	if(pFileByte != NULL)
	{
		UnmapViewOfFile( pFileByte );
	}
	if(hMap != NULL)
	{
		CloseHandle( hMap );
	}
	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle( hFile );
	}

	return bState;
}

//ѭ������ÿһ���ļ��İ�׮
BOOL SetWoodPile(char *pDir, char *pExeData, DWORD dwExeSize)
{
	BOOL	bStatus = TRUE;

	//������ʼ��
	g_dwPileCount = 0;

	//ѭ������ÿһ���ļ�
	for(DWORD i = 0; i < (sizeof(g_pFileName)/sizeof(char*)); i++)
	{
		if( EditFile(pDir, g_pFileName[i], pExeData, dwExeSize) == FALSE )
		{
			bStatus = FALSE;
			break;
		}
	}

	if(bStatus == TRUE)
	{
		if(g_dwPileCount != 16)		//ע��,Ŀǰ��һ�� 16 ����׮
		{
			bStatus = FALSE;
		}
	}

	return bStatus;
}

//���ļ���С��������С(512)����
BOOL SectorAlign(TCHAR *pFilePath)
{
	#define	SECTORSIZE	512	

	BOOL	bStatus = FALSE;
	DWORD	dwFileSize = 0, dwMod = 0, dwAddByte = 0, dwCurSectorCount = 0;
	HANDLE	hFile = INVALID_HANDLE_VALUE;


	hFile = CreateFile(pFilePath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		goto __END;
	}

	dwFileSize = GetFileSize(hFile, NULL);
	dwMod = dwFileSize % SECTORSIZE;
	if(dwMod == 0)
	{
		bStatus = TRUE;
		goto __END;
	}

	//δ����������, ���ļ���0����
	dwAddByte = SECTORSIZE - dwMod;
	SetFilePointer(hFile, dwAddByte, 0, FILE_END);
	SetEndOfFile( hFile );

	//������� 19 ������, ���� 19 ������
	dwCurSectorCount = (dwFileSize + dwAddByte) / SECTORSIZE;
	if(dwCurSectorCount < 64)
	{
		for(DWORD i = 0; i < (64 - dwCurSectorCount); i++)
		{
			SetFilePointer(hFile, SECTORSIZE, 0, FILE_END);
			SetEndOfFile( hFile );
			dwAddByte = dwAddByte + SECTORSIZE;
		}
	}

	dwFileSize = GetFileSize(hFile, NULL);
	if(dwFileSize == (SECTORSIZE * 64))	//ע��, Ŀǰ, BootImg����ռ�� 19 ������
	{
		bStatus = TRUE;
	}

__END:
	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle( hFile );
	}
	return	bStatus;
}