#include "WinMain.h"

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//���ļ����ڴ�, ������ڴ��ɵ������ͷ�
BOOL ReadFileInMem(char *szTargetPath, char **pFileByteParam, DWORD *dwFileSizeParam, DWORD dwFlag)
{
	BOOL				bStatus = FALSE;
	char				*pFilePath = NULL, /*szSelfPath[MAX_PATH], */*pFileByte = NULL;
	HANDLE				hFile = INVALID_HANDLE_VALUE;
	DWORD				dwFileSize = 0, dwByte = 0, dwTotalRead = 0, dwCurrentRead = 0;


	if(szTargetPath == NULL)
	{
		//memset(szSelfPath, 0, sizeof(szSelfPath));
		//GetModuleFileName(g_hSelfModule, szSelfPath, MAX_PATH);
		//pFilePath = szSelfPath;
		MessageBox(NULL, "szTargetPath ����Ϊ��", "Error", MB_ICONERROR);
	}
	else
	{
		pFilePath = szTargetPath;
	}

	if ( pFilePath[0] == ' ') pFilePath ++;
	if(PathFileExists( pFilePath ) == FALSE)
	{
		printf("�ļ������� ----------------------------------------> !!!!!!!!!!!!!!!!!!!\n");
		goto __END;
	}


	for(int i = 0; i < 50; i++)
	{
		hFile = CreateFile(pFilePath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
		if(hFile != INVALID_HANDLE_VALUE)
		{
			break;
		}
		Sleep( 100 );
	}

	dwFileSize = GetFileSize(hFile, NULL);
	if(dwFileSize == 0 || dwFileSize == INVALID_FILE_SIZE)
	{
		printf("���ļ����� ----------------------------------------> !!!!!!!!!!!!!!!!!!!\n");
		goto __END;
	}

	pFileByte = (char*)VirtualAlloc(NULL, dwFileSize, MEM_RESERVE|MEM_COMMIT, PAGE_READWRITE);
	if(pFileByte == NULL)
	{
		goto __END;
	}

	dwCurrentRead = dwFileSize;
	while(dwTotalRead < dwFileSize)
	{
		if( ReadFile(hFile, pFileByte, dwCurrentRead, &dwByte, NULL) == FALSE )
		{
			goto __END;
		}

		dwTotalRead = dwTotalRead + dwByte;
		dwCurrentRead = dwFileSize - dwTotalRead;
	}

	bStatus = TRUE;

	if(dwFlag < 2)
	{
		IMAGE_NT_HEADERS	*PE = NULL;

		//�޸��ļ�ͷ
		PE = (IMAGE_NT_HEADERS*)(pFileByte + *((DWORD*)(pFileByte + 0x3C)));
		if(dwFlag == 0)
		{
			PE->FileHeader.Characteristics |= 0x2000;	//��Ϊ DLL
		}
		else if(dwFlag == 1)
		{
			PE->FileHeader.Characteristics &= 0xDFFF;	//��Ϊ EXE
		}
	}

__END:
	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle( hFile );
	}

	if(bStatus == FALSE)
	{
		if(pFileByte != NULL)
		{
			VirtualFree(pFileByte, 0, MEM_RELEASE);
		}
		
		*pFileByteParam = NULL;
		*dwFileSizeParam = 0;
	}
	else
	{
		*pFileByteParam = pFileByte;
		*dwFileSizeParam = dwFileSize;
	}

	return bStatus;
}

//������д���ļ�
void WriteDataToFile(char *pTargetPath, char *pData, DWORD dwSize)
{
	HANDLE	hFile = INVALID_HANDLE_VALUE;
	DWORD	dwByte = 0;

		if ( pTargetPath[0] == ' ') pTargetPath ++;


	if(PathFileExists( pTargetPath ) == TRUE)
	{
		if( DeleteFile( pTargetPath ) == FALSE )
		{
			printf("dll�ļ��Ѵ���, �����޷�ɾ�� ----------------------------------------> !!!!!!!!!!!!!!!!!!!\n");
		}
	}
	
	hFile = CreateFile(pTargetPath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		printf("�����ļ����� ----------------------------------------> !!!!!!!!!!!!!!!!!!!\n");
	}
	else
	{
		WriteFile(hFile, pData, dwSize, &dwByte, NULL);
		CloseHandle( hFile );
	}

	return;
}

//��Exeת��ΪDll
void ConverExeToDll(char *szParam)
{

	char	*pFileData = NULL, *pSrcExe = NULL, *pNewDll = NULL;
	DWORD	dwFileSize = 0;



	pSrcExe = szParam;
	pNewDll = szParam + lstrlen(szParam) + 1;


	ReadFileInMem(pSrcExe, &pFileData, &dwFileSize, 0);
	WriteDataToFile(pNewDll, pFileData, dwFileSize);

	printf("ת���� DLL �ļ����, Դ�ļ�Ϊ: %s\n", pSrcExe);

	VirtualFree(pFileData, 0, MEM_RELEASE);


	return;
}
