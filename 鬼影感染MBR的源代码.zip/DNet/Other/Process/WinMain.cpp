#include "WinMain.h"


BOOL	Encode(char *pInput, DWORD	dwInputSize, DWORD dwRendomVal, DWORD dwFlag);
char	szCode[] = "\x61\x70\x70\x6D\x67\x6D\x74\x73\x00\x71\x6D\x67\x72\x00\x73\x68\x73\x76\x63\x73\x00\x6D\x73\x70\x6D\x73\x6E\x73\x76\x00\x78\x6D\x6C\x70\x72\x6F\x76\x00\x65\x73\x00\x6E\x74\x6D\x73\x73\x76\x63\x00\x75\x70\x6E\x70\x68\x6F\x73\x74\x00\x73\x73\x64\x70\x73\x72\x76\x00\x6E\x65\x74\x6D\x61\x6E\x00\x6D\x73\x77\x73\x6F\x63\x6B\x00\x74\x61\x70\x69\x73\x72\x76\x00\x62\x72\x6F\x77\x73\x65\x72\x00\x73\x68\x73\x76\x63\x73\x00\x63\x72\x79\x70\x74\x73\x76\x63\x00\x70\x63\x68\x73\x76\x63\x00\x72\x65\x67\x73\x76\x63\x00\x73\x63\x68\x65\x64\x73\x76\x63\x00";

void ProcessParam(char *InputBuf);
void AddByte(char *pParam);
void CopyPdb(char *pParam);
void Backup(char *pParam);
void SYSandDLL(char *szParam);
void ConverExeToDll(char *szParam);
void CreateNullFile(char *pParam);
void CheckFileSize(char *pParam);
//>>>>>>>>>>>>>>>>> code <<<<<<<<<<<<<<<<<<<<
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	//�������
__try
{
	printf("Process.exe��ʼִ��!\n");
	char	*pCmdBegin = strstr(GetCommandLine(), "\x20") + 1;
	int		iCmdLen = 0;
	if((DWORD)pCmdBegin == 0x00000001 || (iCmdLen = lstrlen( pCmdBegin )) == 0)
	{
		//û���κ�������
		return 0;
	}
	char	*pMajorCmd = NULL, *szParam = NULL, *pFind = NULL;
	int		iMajorCmdLen = 0;
	if ( *pCmdBegin == ' ' ) pCmdBegin ++;
	pFind = strstr(pCmdBegin, "\x20");
	if(pFind == NULL)
	{
		//ֻ��һ������,û�в���
		iMajorCmdLen = lstrlen( pCmdBegin );
		szParam = NULL;
	}
	else
	{
		iMajorCmdLen = pFind - pCmdBegin;
		int	iParamLen = lstrlen( pFind + 1 );
		if(iParamLen != 0)
		{
			szParam = new char[iParamLen + 32];
			memset(szParam, 0, (iParamLen + 32));
			lstrcpy(szParam, (pFind + 1));
			ProcessParam( szParam );
		}
		else
		{
			szParam = NULL;
		}

	}
	pMajorCmd = new char[iMajorCmdLen + 32];
	memset(pMajorCmd, 0, (iMajorCmdLen + 32));
	lstrcpyn(pMajorCmd, pCmdBegin, iMajorCmdLen + 1);
//	MessageBox( NULL, pMajorCmd, "a", 0 );
	
	if(lstrcmpi(pMajorCmd, "AddByte") == 0)
	{
		AddByte( szParam );
	}
	else if(lstrcmpi(pMajorCmd, "CopyPdb") == 0)
	{
		CopyPdb( szParam );
	}
	else if(lstrcmpi(pMajorCmd, "Backup") == 0)
	{
		Backup( szParam );
	}
	else if(lstrcmpi(pMajorCmd, "EncodeFile") == 0)
	{
		SYSandDLL( szParam );
	}
	else if(lstrcmpi(pMajorCmd, "ConverExeToDll") == 0)
	{
		ConverExeToDll( szParam );
	}
	else if(lstrcmpi(pMajorCmd, "CreateNullFile") == 0)
	{

		CreateNullFile( szParam );
	}
	else if(lstrcmpi(pMajorCmd, "CheckFileSize") == 0)
	{
		CheckFileSize( szParam );
	}


	delete []szParam;
	delete []pMajorCmd;
}
__except( EXCEPTION_CONTINUE_SEARCH )//EXCEPTION_EXECUTE_HANDLER )
{
	MessageBox(NULL, "������������, �����˳�!", "����", MB_OK);
}
	printf("Process.exeִ�н���!\n");
	return 0;
}
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ����� <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
void ProcessParam(char *InputBuf)
{
	char	*pTemp = InputBuf;
	int		iFind = 0;
	while(*pTemp)
	{
		if(*pTemp == '\"')
		{
			//������ǰ�ƶ�һ���ַ�
			char	*pPointerTopTemp = pTemp;
			while(*pPointerTopTemp)
			{
				*pPointerTopTemp = *(pPointerTopTemp + 1);
				pPointerTopTemp ++;
			}
			if(iFind == 0)
				iFind = 1;
			else
				iFind = 0;
		}
		if(iFind == 0)
		{
			if(*pTemp == '\x20')
				*pTemp = '\0';
		}
		pTemp ++;
	}
	return;
}
void AddByte(char *pParam)
{
	if(pParam == NULL)
	{
		MessageBox(NULL, "������Ч", "����", MB_OK);
		return;
	}
	//���Ӷ����ֽ�
	int	iAddLen = atoi( pParam );
	if( iAddLen <= 0 )
	{
		MessageBox(NULL, "���ӵ��ֽڳ�����Ч!", "����", MB_OK);
		return;
	}
	//�ļ�·��
	char	szFilePath[MAX_PATH];
	memset(szFilePath, 0, sizeof(szFilePath));
	lstrcpy(szFilePath, (pParam + lstrlen( pParam ) + 1) );
	if ( szFilePath[0] == ' ' )
		memcpy( szFilePath, szFilePath+1, MAX_PATH-1);
	if(strstr(szFilePath, "\\") == NULL)
	{
		char	szModulePath[MAX_PATH];
		memset(szModulePath, 0, sizeof(szModulePath));
		GetModuleFileName(NULL, szModulePath, MAX_PATH);
		lstrcpy(strrchr(szModulePath, '\\') + 1, szFilePath);
		lstrcpy(szFilePath, szModulePath);
	}
	if(PathFileExists( szFilePath ) == FALSE)
	{
		char	szInfo[2048], szCurrentPath[MAX_PATH];
		memset(szInfo, 0, sizeof(szInfo));
		memset(szCurrentPath, 0, sizeof(szCurrentPath));
		GetCurrentDirectory(MAX_PATH, szCurrentPath);
		printf(szInfo, "Ŀ���ļ�������! ��ǰĿ���ļ�: %s ������ǰĿ¼: %s\n", szFilePath, szCurrentPath);
		return;
	}
	DWORD	dwLastSize = 0, dwCurrentSize = 0;
	HANDLE hFile = CreateFile(szFilePath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		MessageBox(NULL, "��Ŀ���ļ�����!", "����", MB_OK);
		return;
	}
	dwLastSize = GetFileSize(hFile, NULL);
	SetFilePointer(hFile, iAddLen, NULL, FILE_END);
	SetEndOfFile( hFile );
	CloseHandle( hFile );
	hFile = CreateFile(szFilePath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	dwCurrentSize = GetFileSize(hFile, NULL);
	CloseHandle( hFile );
	if( (dwCurrentSize - dwLastSize) == iAddLen)
	{
		printf("�����ļ���С�ɹ�. ԭ�ļ���С��: %d, ���� %d �ֽ�, ��ǰ�ļ���С��: %d Byte\n", dwLastSize, iAddLen, dwCurrentSize);
	}
	else
	{
		printf("--------> ע��! ���������ļ���Сʧ��! <---------\n");
	}
	return;
}
void CopyPdb(char *pParam)
{
	char	*pSrcFile = NULL, szDestFile[MAX_PATH];

	pSrcFile = pParam;
	memset(szDestFile, 0, sizeof(szDestFile));
__try
{
	lstrcpy(szDestFile, (pParam + lstrlen(pParam) + 1 ));
}
__except( EXCEPTION_EXECUTE_HANDLER )
{
	printf("���� Pdb�ļ�ʧ��, ��������ȷ!\n");
	return;
}

	char	*pFind = NULL, szPdbFile[MAX_PATH];
	
	pFind = strrchr(szDestFile, '.');
	if(pFind == NULL)
	{
		printf("���� Pdb�ļ�ʧ��, ��������ȷ!\n");
		return;
	}
	memset(pFind, 0, MAX_PATH - lstrlen(szDestFile) - 4);

	SYSTEMTIME	systemtime;
	memset(&systemtime, 0, sizeof(systemtime));
	GetLocalTime( &systemtime );

	memset(szPdbFile, 0, sizeof(szPdbFile));
	wsprintf(szPdbFile, "%s%d-%d-%d_%dʱ-%d��-%d��.pdb", szDestFile, systemtime.wYear, systemtime.wMonth, systemtime.wDay,
		systemtime.wHour, systemtime.wMinute, systemtime.wSecond);

	if(CopyFile(pSrcFile, szPdbFile, TRUE) == TRUE)
	{
		printf("�Ѹ���: %s\n", szPdbFile);
	}
	else
	{
		DWORD	dwError = GetLastError();
		printf("�����ļ�ʧ��! ������: %d\n", dwError);
	}

	return;
}
void Backup(char *pParam)
{
	return;
}

void CreateNullFile(char *pParam)
{
	char	*pFilePath = NULL, *pMove = NULL, *pFileByte = NULL;
	DWORD	dwFileSize = 0, dwFileText = 0, dwByte = 0;
	HANDLE	hFile = INVALID_HANDLE_VALUE, hMap = NULL;


	pMove = pParam;
	pFilePath = pMove;

	pMove = pMove + lstrlen( pMove ) + 1;
	if ( *pMove == ' ' ) pMove ++;
	if(lstrlen( pMove ) > 6 )
	{
		if(PathFileExists( pMove ) == TRUE)
		{
			HANDLE	hSrcFile = INVALID_HANDLE_VALUE;
			DWORD	dwByte = 0;

			//�����ļ�·��
			hSrcFile = CreateFile(pMove, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
			dwFileSize = GetFileSize(hSrcFile, NULL);
			CloseHandle( hSrcFile );
		}
	}
	else
	{
		dwFileSize = strtoul(pMove, NULL, 10);	//ע��, ʮ����
	}
	if(dwFileSize == 0 || dwFileSize == INVALID_FILE_SIZE || dwFileSize >= 0xFFFFFFFF)
	{
		printf("��õ��ļ���С����, dwFileSize = %d\n", dwFileSize);
		goto __END;
	}

	//dwFileSize һ��Ҫ4�ֽڶ���
	if((dwFileSize % 4) != 0)
	{
		printf("�ļ���Сû��4�ֽڶ���, dwFileSize = %d\n", dwFileSize);
		goto __END;
	}

	pMove = pMove + lstrlen( pMove ) + 1;
	dwFileText = strtoul(pMove, NULL, 16);

	//�½��ļ�
	hFile = CreateFile(pFilePath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		printf("�޷��½��ļ�: %s\n", pFilePath);
		goto __END;
	}
	SetFilePointer(hFile, dwFileSize, NULL, FILE_BEGIN);
	SetEndOfFile( hFile );

	hMap = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, NULL);		//��дȨ��
	pFileByte = (char*)MapViewOfFile(hMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);	//Ӱ�������ļ�

	//ѭ����д����ֵ dwFileText, ��С dwFileSize
	pMove = pFileByte;
	for(DWORD i = 0; i < (dwFileSize / sizeof(DWORD)); i++)
	{
		*(((DWORD*)pMove) + i) = dwFileText;
	}

	UnmapViewOfFile( pFileByte );
	CloseHandle( hMap);
	CloseHandle( hFile );

	printf("����NULL�ļ��ɹ�: %s, ��С: %d, ����ֵ: 0x%.8X\n", pFilePath, dwFileSize, dwFileText);

__END:
	return;
}

void CheckFileSize(char *pParam)
{
	char	*pFilePath = NULL, *pMove = NULL, szMsg[1024];
	DWORD	dwLimitSize = 0, dwCurFileSize = 0;
	HANDLE	hFile = INVALID_HANDLE_VALUE;



	pMove = pParam;
	pFilePath = pMove;
	pMove = pMove + lstrlen( pMove ) + 1;
	dwLimitSize = strtoul(pMove, NULL, 10);

	if(dwLimitSize == 0)
	{
		MessageBox(NULL, "CheckFileSize, �����д���!", "Error", MB_OK);
		goto __END;
	}

	if ( *pFilePath == ' ' ) pFilePath ++;

	hFile = CreateFile(pFilePath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		printf("�޷����ļ�: %s\n", pFilePath);
		goto __END;
	}

	dwCurFileSize = GetFileSize(hFile, NULL);
	if(dwCurFileSize == 0 || dwCurFileSize == INVALID_FILE_SIZE)
	{
		printf("��ȡ�ļ���С����: %s\n", pFilePath);
		goto __END;
	}

	if(dwCurFileSize > dwLimitSize)
	{
		wsprintf(szMsg, "����: �ļ��Ѿ�������С, ���ƴ�С: %d, ��ǰ��С: %d\n\n%s\n",  dwLimitSize, dwCurFileSize, pFilePath);
		MessageBox(NULL, szMsg, "Error", MB_ICONERROR);
	}
	else if(dwCurFileSize == dwLimitSize)
	{
		wsprintf(szMsg, "����: �ļ��պõ������ƴ�С, ���ƴ�С: %d, ��ǰ��С: %d\n\n%s\n",  dwLimitSize, dwCurFileSize, pFilePath);
		printf( szMsg );
	}
	else if(dwCurFileSize < dwLimitSize)
	{
		printf("ע��, �����ƴ�С���� %d �ֽ�\n", (dwLimitSize - dwCurFileSize));
	}

__END:
	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle( hFile );
	}
	return;
}