#include <Windows.h>
#include <shlwapi.h>




//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//

//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
BOOL	ReadFileInMem(char *szTargetPath, char **pFileByteParam, DWORD *dwFileSizeParam, DWORD dwFlag);
//--------------------------------------------------------------------------//

#define	LOGFILE		"E:\\Products\\DNet\\Rocket\\BootCode\\��׮����.log"
#define	LOGSTRING_1	"___________________________________________"

char	*g_FileDir = "E:\\Products\\DNet\\Rocket\\BootCode\\DiskSystem";
char	*g_pFileName[] = {
	"Disk System.asm",
	"Disk Device Driver.asm",
	"NTFS driver.asm",
	"FAT driver.asm"
};


DWORD	g_dwPileCount = 0;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
void BoxError(char *szErrorMsg)
{
	MessageBox(NULL, szErrorMsg, "Error", MB_ICONERROR);
	return;
}

void WriteLog(char *pText, DWORD dwLen)
{
	static	BOOL	bFirstIn = FALSE;
	HANDLE	hFile = INVALID_HANDLE_VALUE;
	DWORD	dwByte = 0;
	char	*pTime = NULL, szCurrentTime[128];

	if(bFirstIn == FALSE)
	{
		SYSTEMTIME	systemtime;

		DeleteFile( LOGFILE );
		bFirstIn = TRUE;

		GetLocalTime( &systemtime );
		memset(szCurrentTime, 0, sizeof(szCurrentTime));
		wsprintf(szCurrentTime, "%d��%d��%d�� %dʱ-%d��-%d�룺 \r\n%s\r\n", systemtime.wYear, systemtime.wMonth, systemtime.wDay, systemtime.wHour, systemtime.wMinute, systemtime.wSecond, LOGSTRING_1);
		pTime = szCurrentTime;
	}

	hFile = CreateFile(LOGFILE, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	SetFilePointer(hFile, 0, 0, FILE_END);
	if(pTime != NULL)
	{
		WriteFile(hFile, pTime, lstrlen( pTime ), &dwByte, NULL);
	}
	WriteFile(hFile, pText, dwLen, &dwByte, NULL);
	WriteFile(hFile, "\x0d\x0a", 2, &dwByte, NULL);
	CloseHandle( hFile );

	return;
}

BOOL EditFile(char *pFileName, char *pExeData, DWORD dwExeSize)
{
	BOOL	bState = TRUE;
	char	szCurFile[MAX_PATH], *pFileByte = NULL, szMsg[1024], *pMove = NULL;
	DWORD	dwFileSize = 0;
	HANDLE	hFile = INVALID_HANDLE_VALUE, hMap = NULL;

	//�ļ�ӳ��
	wsprintf(szCurFile, "%s\\%s", g_FileDir, pFileName);
	hFile = CreateFile(szCurFile, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		wsprintf(szMsg, "�޷���: %s",szCurFile);
		BoxError( szMsg );
		bState = FALSE;
		goto __END;
	}
	dwFileSize = GetFileSize(hFile, NULL);
	hMap = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, NULL);
	pFileByte = (char*)MapViewOfFile(hMap, FILE_MAP_ALL_ACCESS, 0, 0, dwFileSize);
	if(pFileByte == NULL)
	{
		wsprintf(szMsg, "�޷�ӳ��: %s",szCurFile);
		BoxError( szMsg );
		bState = FALSE;
		goto __END;
	}

	WriteLog(szCurFile, lstrlen(szCurFile));

	//�����ַ���
	pMove = pFileByte;
	for(;;)
	{
		char	*pVal = NULL, cTemp[512];
		DWORD	dwOffset = 0, dwValSize = 0, dwCurVal = 0;

		pMove = strstr(pMove, ";//��׮:");
		if(pMove == NULL)
		{
			break;
		}

		//val
		pVal = strstr(pMove, "0x") + 2;

		//offset
		pMove = strstr(pVal, "0x") + 2;
		memset(cTemp, 0, sizeof(cTemp));
		memcpy(cTemp, pMove, 4);
		dwOffset = strtoul(cTemp, NULL, 16);

		//valsize
		pMove = strstr(pMove, "\x09\x09") + 2;
		memset(cTemp, 0, sizeof(cTemp));
		memcpy(cTemp, pMove, 1);
		dwValSize = strtoul(cTemp, NULL, 16);

		memset(cTemp, 0, sizeof(cTemp));
		switch(dwValSize)
		{
			case 1:
				 {
					 if(dwOffset <= (dwExeSize - sizeof(DWORD)))
					 {
						 dwCurVal = (DWORD)(*(unsigned char*)(pExeData + dwOffset));
					 }
					 else
					 {
						 dwCurVal = 0;
					 }
					 wsprintfA(cTemp, "%.2X", dwCurVal);
				 }
				 break;
			case 2:
				 {
					 if(dwOffset <= (dwExeSize - sizeof(DWORD)))
					 {
						 dwCurVal = (DWORD)(*(WORD*)(pExeData + dwOffset));
					 }
					 else
					 {
						 dwCurVal = 0;
					 }
					 wsprintfA(cTemp, "%.4X", dwCurVal);
				 }
				 break;
			case 4:
				 {
					 if(dwOffset <= (dwExeSize - sizeof(DWORD)))
					 {
						 dwCurVal = (DWORD)(*(DWORD*)(pExeData + dwOffset));
					 }
					 else
					 {
						 dwCurVal = 0;
					 }
					 wsprintfA(cTemp, "%.8X", dwCurVal);
				 }
				 break;
			default:
				{
					bState = FALSE;
					goto __END;
				}
		}
		memcpy(pVal, cTemp, (dwValSize * 2));

		//ͳ��,��¼
		g_dwPileCount ++;

		pMove = pVal;
		while(*(WORD*)(pMove - 2) != 0x0A0D)
		{
			pMove --;
		}
		memset(cTemp, 0, sizeof(cTemp));
		memcpy(cTemp, pMove, ((strstr(pMove, "\x0D\x0A")+2) - pMove));
		WriteLog(cTemp, lstrlen(cTemp));
	}

__END:
	if(pFileByte != NULL)
	{
		UnmapViewOfFile( pFileByte );
	}
	if(hMap != NULL)
	{
		CloseHandle( hMap );
	}
	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle( hFile );
	}

	return bState;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	char	*pExePath = NULL, *pExeData = NULL, szMsg[1024];
	DWORD	dwExeSize = 0;


	pExePath = strstr(GetCommandLine(), "\x20") + 1;

	
	//pExePath = "E:\\Products\\MFD\\Other\\ModuleTest\\InfectMBR\\BootCode\\Tool\\SetWoodPile\\Release\\tape.sys";


	ReadFileInMem(pExePath, &pExeData, &dwExeSize, 3);
	if(pExeData == NULL)
	{
		BoxError("��ȡ �����ļ� ����!");
		goto __END;
	}

	//ѭ������ÿһ���ļ�
	for(DWORD i = 0; i < (sizeof(g_pFileName)/sizeof(char*)); i++)
	{
		if( EditFile(g_pFileName[i], pExeData, dwExeSize) == FALSE )
		{
			break;
		}
		else
		{
			WriteLog(LOGSTRING_1, lstrlen(LOGSTRING_1));
		}
	}

	VirtualFree(pExeData, 0, MEM_RELEASE);

	wsprintf(szMsg, "��׮�Զ����� �ѽ���, �˴ι�������׮  %d  ��.\n\n�Ƿ�鿴��־�ļ�? \n\n �мǣ�-> ���±��� DiskSystem", g_dwPileCount);
	if(MessageBox(NULL, szMsg, "ע��", MB_YESNO) == IDYES)
	{
		ShellExecute(NULL, "open", LOGFILE, NULL, NULL, SW_SHOW);
	}

__END:
	ExitProcess( 0 );
}