#include <windows.h>
#include <shlwapi.h>
#include <stdio.h>