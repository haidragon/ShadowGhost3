#include "Common.h"


//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//

//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//

//--------------------------------------------------------------------------//

//custom defined structure
#pragma pack(1)
typedef	struct _IDEINITIAL{
 short	CMDBase;
 short	CTRBase;
 short	Master;
 short	CMDBase0;
 short	CTRBase0;
 long	Bus;
 char	Count;
 char	Lba48;
}IDEINITIAL, *PIDEINITIAL;
#pragma pack()

#pragma pack(1)
typedef	struct _IDECOMMAND{
  long	LBA0;
  long	LBA1;
  short	Device;
  short	Feature;
  short	Counter;
  short	Control;
  char	Type;	//bit 0--->Ex Flags. bit1--->Ins. bit2--->Outs
  char	Command;
  long	Buffer;
  long	BufLen;
}IDECOMMAND, *PIDECOMMAND;
#pragma pack()


#define	IDE_SECTOR_SIZE		200h
#define	CDROM_SECTOR_SIZE	800h
#define	SECTOR_SHIFT		9
#define	IDE_TIMEOUT			5000d	//The maximum time any IDE command can last 31 seconds.
#define	IDE_RESET_PULSE		2

#define	IDE_BASE0	 1f0h  //primary controller
#define	IDE_BASE1	 170h  //secondary controller
#define	IDE_BASE2	 0f0h  //third controller
#define	IDE_BASE3	 70h   //fourth controller
//other ide control is got by the pci bus scaning

//IDE registers
#define	IDE_REG_EXTENDED_OFFSET	0204h
#define	IDE_REG_DATA			0
#define	IDE_REG_ERROR			1
#define	IDE_REG_PRECOMP			1
#define	IDE_REG_FEATURE			1
#define	IDE_REG_SECTOR_COUNT	2
#define	IDE_REG_SECTOR_NUMBER	3
#define	IDE_REG_LBA_LOW			3
#define	IDE_REG_CYLINDER_LSB	4
#define	IDE_REG_LBA_MID			4
#define	IDE_REG_CYLINDER_MSB	5
#define	IDE_REG_LBA_HIGH		5
#define	IDE_REG_DRIVEHEAD		6
#define	IDE_REG_DEVICE			6
#define	IDE_REG_STATUS			7
#define	IDE_REG_COMMAND			7
#define	IDE_REG_ALTSTATUS		2
#define	IDE_REG_DEVICE_CONTROL	2


 #define	IDE_ERR_ICRC    0x80    /* ATA Ultra DMA bad CRC */
 #define	IDE_ERR_BBK     0x80    /* ATA bad block */
 #define	IDE_ERR_UNC     0x40    /* ATA uncorrected error */
 #define	IDE_ERR_MC      0x20    /* ATA media change */
 #define	IDE_ERR_IDNF    0x10    /* ATA id not found */
 #define	IDE_ERR_MCR     0x08    /* ATA media change rest */
 #define	IDE_ERR_ABRT    0x04    /* ATA command aborted */
 #define	IDE_ERR_NTK0    0x02    /* ATA track 0 not found */
 #define	IDE_ERR_NDAM    0x01    /* ATA address mark not found */

 #define	IDE_STATUS_BSY  0x80    /* busy */
 #define	IDE_STATUS_RDY  0x40    /* ready */
 #define	IDE_STATUS_DF	0x20    /* device fault */
 #define	IDE_STATUS_WFT  0x20    /* write fault (old name) */
 #define	IDE_STATUS_SKC  0x10    /* seek complete */
 #define	IDE_STATUS_DRQ  0x08    /* data rest */
 #define	IDE_STATUS_CORR	0x04	/* corrected */
 #define	IDE_STATUS_IDX  0x02    /* index */
 #define	IDE_STATUS_ERR  0x01    /* error (ATA) */
 #define	IDE_STATUS_CHK  0x01    /* check (ATAPI) */

 #define	IDE_CTRL_HD15	 0x08    /* bit should always be set to one */
 #define	IDE_CTRL_SRST	 0x04    /* soft reset */
 #define	IDE_CTRL_NIEN	 0x02    /* disable interrupts */

/* Most mandtory and optional ATA commands (from ATA-3), */
 #define	IDE_CMD_CFA_ERASE_SECTORS				0xC0
 #define	IDE_CMD_CFA_REQUEST_EXT_ERR_CODE		0x03
 #define	IDE_CMD_CFA_TRANSLATE_SECTOR			0x87
 #define	IDE_CMD_CFA_WRITE_MULTIPLE_WO_ERASE		0xCD
 #define	IDE_CMD_CFA_WRITE_SECTORS_WO_ERASE		0x38
 #define	IDE_CMD_CHECK_POWER_MODE1				0xE5
 #define	IDE_CMD_CHECK_POWER_MODE2				0x98
 #define	IDE_CMD_DEVICE_RESET					0x08
 #define	IDE_CMD_EXECUTE_DEVICE_DIAGNOSTIC		0x90
 #define	IDE_CMD_FLUSH_CACHE						0xE7
 #define	IDE_CMD_FORMAT_TRACK					0x50
 #define	IDE_CMD_IDENTIFY_DEVICE					0xEC
 #define	IDE_CMD_IDENTIFY_DEVICE_PACKET			0xA1
 #define	IDE_CMD_IDENTIFY_PACKET_DEVICE			0xA1
 #define	IDE_CMD_IDLE1							0xE3
 #define	IDE_CMD_IDLE2							0x97
 #define	IDE_CMD_IDLE_IMMEDIATE1					0xE1
 #define	IDE_CMD_IDLE_IMMEDIATE2					0x95
 #define	IDE_CMD_INITIALIZE_DRIVE_PARAMETERS		0x91
 #define	IDE_CMD_INITIALIZE_DEVICE_PARAMETERS	0x91
 #define	IDE_CMD_NOP								0x00
 #define	IDE_CMD_PACKET							0xA0
 #define	IDE_CMD_READ_BUFFER						0xE4
 #define	IDE_CMD_READ_DMA						0xC8
 #define	IDE_CMD_READ_DMA_QUEUED					0xC7
 #define	IDE_CMD_READ_MULTIPLE					0xC4
 #define	IDE_CMD_READ_SECTORS					0x20
 #define	IDE_CMD_READ_SECTORS_EXT				0x24
 #define	IDE_CMD_READ_VERIFY_SECTORS				0x40
 #define	IDE_CMD_RECALIBRATE						0x10
 #define	IDE_CMD_SEEK							0x70
 #define	IDE_CMD_SET_FEATURES					0xEF
 #define	IDE_CMD_SET_MAX_ADDR_EXT				0x24
 #define	IDE_CMD_SET_MULTIPLE_MODE				0xC6
 #define	IDE_CMD_SLEEP1							0xE6
 #define	IDE_CMD_SLEEP2							0x99
 #define	IDE_CMD_STANDBY1						0xE2
 #define	IDE_CMD_STANDBY2						0x96
 #define	IDE_CMD_STANDBY_IMMEDIATE1				0xE0
 #define	IDE_CMD_STANDBY_IMMEDIATE2				0x94
 #define	IDE_CMD_WRITE_BUFFER					0xE8
 #define	IDE_CMD_WRITE_DMA						0xCA
 #define	IDE_CMD_WRITE_DMA_QUEUED				0xCC
 #define	IDE_CMD_WRITE_MULTIPLE					0xC5
 #define	IDE_CMD_WRITE_SECTORS					0x30
 #define	IDE_CMD_WRITE_VERIFY					0x3C

/* IDE_CMD_SET_FEATURE sub commands */
 #define	IDE_FEATURE_CFA_ENABLE_8BIT_PIO			0x01
 #define	IDE_FEATURE_ENABLE_WRITE_CACHE			0x02
 #define	IDE_FEATURE_SET_TRANSFER_MODE			0x03
 #define	IDE_FEATURE_ENABLE_POWER_MANAGEMENT		0x05
 #define	IDE_FEATURE_ENABLE_POWERUP_IN_STANDBY	0x06
 #define	IDE_FEATURE_STANDBY_SPINUP_DRIVE		0x07
 #define	IDE_FEATURE_CFA_ENABLE_POWER_MODE1		0x0A
 #define	IDE_FEATURE_DISABLE_MEDIA_STATUS_NOTIFICATION		0x31
 #define	IDE_FEATURE_ENABLE_AUTOMATIC_ACOUSTIC_MANAGEMENT	0x42
 #define	IDE_FEATURE_SET_MAXIMUM_HOST_INTERFACE_SECTOR_TIMES	0x43
 #define	IDE_FEATURE_DISABLE_READ_LOOKAHEAD		0x55
 #define	IDE_FEATURE_ENABLE_RELEASE_INTERRUPT	0x5D
 #define	IDE_FEATURE_ENABLE_SERVICE_INTERRUPT	0x5E
 #define	IDE_FEATURE_DISABLE_REVERTING_TO_POWERON_DEFAULTS	0x66
 #define	IDE_FEATURE_CFA_DISABLE_8BIT_PIO		0x81
 #define	IDE_FEATURE_DISABLE_WRITE_CACHE			0x82
 #define	IDE_FEATURE_DISABLE_POWER_MANAGEMENT	0x85
 #define	IDE_FEATURE_DISABLE_POWERUP_IN_STANDBY	0x86
 #define	IDE_FEATURE_CFA_DISABLE_POWER_MODE1		0x8A
 #define	IDE_FEATURE_ENABLE_MEDIA_STATUS_NOTIFICATION		0x95
 #define	IDE_FEATURE_ENABLE_READ_LOOKAHEAD		0xAA
 #define	IDE_FEATURE_DISABLE_AUTOMATIC_ACOUSTIC_MANAGEMENT	0xC2
 #define	IDE_FEATURE_ENABLE_REVERTING_TO_POWERON_DEFAULTS	0xCC
 #define	IDE_FEATURE_DISABLE_SERVICE_INTERRUPT	0xDE

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//check ide busy flag
__declspec (naked)	BOOLEAN __stdcall IdeCheckBusy(long	IdeBaseAddress)
{
	__asm
	{
		mov edx,dword ptr [esp+4]
		add edx,IDE_REG_STATUS	//�� 0x1F7  Cmd Reg 7   Status/Command
		in al,dx
		and eax,IDE_STATUS_BSY	//��7λ���㣬ʣ�� BSY λ
		shr eax,7
		ret 4
	}
}

//delay		//����൱�� Sleep( useconds );
__declspec (naked)	BOOLEAN __stdcall UDelay(long useconds)
{
	__asm
	{
		pushad
		mov ecx,[esp+24h]
		uwait:
		 in al,80h
		 sub ecx,1
		 jnz uwait
		popad
		ret 4
	}
}

//wait for busying (false:timemout)
__declspec (naked)	BOOLEAN __stdcall IdeWait(long IdeBaseAddress, long TimeOut)
{
	__asm
	{
		push ebp
		mov ebp,esp

		xor eax,eax
		mov ecx,dword ptr[ebp+0ch]
		or ecx,ecx
		jz __RET	//if(TimeOut == 0) goto __RET;

		imul ecx,ecx,100d	//milliseconds		ecx = TimeOut * 1000;

		iwait:
		 push 10d
		 call UDelay		//useconds		�൱�� Sleep( 10 )

		 sub ecx,1			//if( (ecx = ecx - 1) <= 0) goto __RET;
		 jz __RET

		 push dword ptr[ebp+8]
		 call IdeCheckBusy	//if( IdeCheckBusy( IdeBaseAddress ) != 0)
		 or eax,eax			//{
		 jnz iwait			//	 goto iwait;
							//}

		 mov eax,1	//����TRUE,�ȴ��ɹ�
	__RET:
		leave
		ret 8
	}
}


//Send an IDE command ( return:boolean      (-1:right) )
__declspec (naked)	BOOLEAN __stdcall IdeSendCommand(long IdeInitial, long IdeCommand)
{
	__asm
	{
		push	ebp
		mov		ebp,esp
		push	edi
		push	esi
		push	ebx
		push	0		//result
		
		mov		edi,[ebp+8]
		or		edi,edi
		jz		ide5
		mov		esi,[ebp+0ch]
		or		esi,esi
		jz		ide5	//if(IdeInitial == NULL || IdeCommand == NULL)
						//{
						//		return 0;
						//}


		push	IDE_TIMEOUT
		mov	eax, [edi/*+0x00 IdeInitial.CMDBase*/]
		push	eax
		call	IdeWait
		or		eax,eax
		jz		ide5	//if(IdeWait(IdeInitial->CMDBase, 5000) == FALSE)	//5��
						//{
						//		return 0;
						//}

		//disable interrupts	//�ر��ж�(IDE��)
		mov	edx,[edi+0x02/*IdeInitial.CTRBase*/]
		mov		ax,IDE_CTRL_HD15	//0x08
		or		ax,IDE_CTRL_NIEN	//0x02
		out		dx,al				//out	0x3F6, 00001010


		//change device			//�ı��豸
		mov	ecx,[edi/*+0x00 IdeInitial.CMDBase*/]	//ecx = IdeInitial->CMDBase	, ecx Ϊ�����Ĵ���, �� 0x1F6
		lea		edx,[ecx+IDE_REG_DEVICE]				//edx = IdeInitial->CMDBase + 6
		in		al,dx									//in	al, 0x1F6
		mov		bl,al	//save device	//�����豸�� bl

		mov		al,byte ptr[esi+0x08/*IdeCommand.Device*/]	// al = IdeCommand->Device
		out		dx,al	//select device	//ѡ�����豸		// out	0x1F6, IdeCommand->Device

		and		bl,010h		//0x10 = 00010000
		xor		bl,0
		jz		__FLAG_1	//�ж� 0x1F6 ԭ��������,  ��Ϊ����������ǲ��� Device 0, ����ڴ�֮ǰDevice 1���������͵ȴ�5�룬�ȴ���������ϣ�

		push	5000d
		call	UDelay		//͢��

__FLAG_1:
		//set feature	//��������
		lea		edx,[ecx+IDE_REG_FEATURE]
		mov		al,0
		out		dx,al	// out	0x1F1, 0

		//check EX		//����Ƿ��� '��չ'
		mov	eax,[esi+0x10/*IdeCommand.Type*/]
		test	eax,1
		jz		__FLAG_2

		//high byte		//���ֽ�
		mov		ax,[esi+0x0C/*IdeCommand.Counter*/]
		lea		edx,[ecx+IDE_REG_SECTOR_COUNT]	//0x1F2
		shr		al,8
		out		dx,al
		mov		eax,[esi/*+0x00 IdeCommand.LBA0*/]
		lea		edx,[ecx+IDE_REG_LBA_LOW]	//0x1F3
		shr		eax,24d
		out		dx,al
		mov		eax,[esi+0x04/*IdeCommand.LBA1*/]
		lea		edx,[ecx+IDE_REG_LBA_MID]	//0x1F4
		out		dx,al
		shr		eax,8
		lea		edx,[ecx+IDE_REG_LBA_HIGH]	//0x1F5
		out		dx,al
		push	2
		call	UDelay

__FLAG_2:	//no ex		//�� '��չ'
		mov		ax,[esi+0x0C/*IdeCommand.Counter*/]
		lea		edx,[ecx+IDE_REG_SECTOR_COUNT]
		out		dx,al				// out	0x1F2, IdeCommand->Counter		//Ҫ��д�������� ��8λ


		//���� LBA
		mov		eax,[esi/*+0x00 IdeCommand.LBA0*/]
		lea		edx,[ecx+IDE_REG_LBA_LOW]	//0x1F3
		out		dx,al

		shr		eax,8
		lea		edx,[ecx+IDE_REG_LBA_MID]	//0x1F4
		out		dx,al

		shr		eax,8
		lea		edx,[ecx+IDE_REG_LBA_HIGH]	//0x1F5
		out		dx,al

		//set Command	//��������
		mov		al,[esi+0x11/*IdeCommand.Command*/]
		lea		edx,[ecx+IDE_REG_COMMAND]
		out		dx,al			//out	0x1F7, IdeCommand->Command			//��������, ��д�����벻����20h��30h.���ֱ���29h��39h.

		push	1000
		call	UDelay	//͢�� 1����

		push	IDE_TIMEOUT
		push	ecx
		call	IdeWait
		or		eax,eax
		jz		ide5	//if(IdeWait(IdeInitial->CMDBase, 5000) == FALSE)	//5��
						//{
						//		return 0;
						//}

		//check error	//��������ɹ�, ������
		mov	ecx,[edi/*+0x00 IdeInitial.CMDBase*/]
		lea		edx,[ecx+IDE_REG_STATUS]
		in		al,dx	//out	al, 0x1F7

		test	al,1		//if( (al & 0x1) == 0)	goto __FLAG_3;	��� ERRλ
		jz		__FLAG_3

		lea		edx,[ecx+1]
		in		al,dx				//in	al, 0x1F1	//�������������Ϣ, �����䷵��
		mov		byte ptr[esp],al
		jmp		ide5

__FLAG_3:	//��
		test	al,IDE_STATUS_DRQ	//0x08 = 00001000  DRQλ		�����������Ƿ��Ѿ�׼���ô������ݡ�������
		jz		ide6

		//check data	//���ݼ��
		mov	eax,[esi+0x10/*IdeCommand.Type*/]
		test	eax,2
		jz		__FLAG_4	//if( (IdeCommad->Type & 0x02) == 0)
							//{
							//		goto __FLAG_4;	//����"д"
							//}

		//ins	'��'
		xchg	ebx,ecx
		mov		edx,ebx		//edx = 0x1F0 (��д�Ĵ���)
		mov		ecx,[esi+0x16/*IdeCommand.BufLen*/]
		mov		edi,[esi+0x12/*IdeCommand.Buffer*/]
		shr		ecx,1	//IdeCommand.BufLen / 2
		cld
		rep		insw
f5:
		lea		edx,[ebx+7]
		in		al,dx	//in	al, 0x1F7
		cmp		al,58h	// if( al != 01011000 ) goto f4; jmp ide6  (���� DRQλ������ȡ�Ƿ�ȫ�����)
		jnz		f4

		//����û����? ������ȡ?
		mov		edx,ebx
		in		ax,dx	//int	ax, 0x1F0	ʣ��û����ģ�������ʵ�Ƿ�����
		jmp		f5
f4:
		jmp		ide6

__FLAG_4:	//д
		test	eax,4
		jz		ide6	//if( (IdeCommad->Type & 0x04) == 0)
						//{
						//		goto ide6;	//�ⲻ�� "��"
						//}

		//outs	'д'
		xchg	ebx,ecx
		mov		edx,ebx
		mov		ecx,[esi+0x16/*IdeCommand.BufLen*/]
		mov		esi,[esi+0x12/*IdeCommand.Buffer*/]
		shr		ecx,1
		cld
		rep		outsw	//�� '��' ��ͬ

ide6:  // ====> ���� 0x1F7 �е����ݣ�����ɹ������سɹ�������д���������������������������
		mov		esi,[ebp+0ch]	//IdeCommand
		mov		edi,[ebp+8]		//IdeInitial
		mov	ecx,[edi/*+0x00 IdeInitial.CMDBase*/]

		//map register		ӳ��Ĵ���  
		lea		edx,[ecx+IDE_REG_COMMAND]
		in		al,dx			//in	al, 0x1F7
		mov		[esi+0x11/*IdeCommand.Command*/],al		//ע��, IdeCommand.Command = al, ����ʱ 0x1F7 �е�����
		test	al, 9h		//00001001
		jz		__FLAG_5	

		mov		edi,[ebp+8]
		mov	edx,[edi+0x02/*IdeInitial.CTRBase*/]
		mov		al,6	//00000110	����������, �ر��ж�???
		out		dx,al	//out	0x3F6, 6

__FLAG_5:
		mov		dword ptr[esp],-1d		//���� -1 , 0xFF,Ϊ�����ɹ�

ide5:
		pop		eax
		pop		ebx
		pop		esi
		pop		edi
		leave
		ret		8d
	}
}

// IDE LBA Read (false:timemout)
__declspec (naked)	BOOLEAN __stdcall IDELba48Read(long IdeInitial, long IdeCommand)
{
	__asm
	{
		push ebp
		mov ebp,esp
		push esi
		push edi
		push ebx
		push 0 //result

		  mov esi,[ebp+0ch]
		  or esi,esi
		  jz Ide0
		  mov edi,[ebp+8]
		  cmp byte ptr[edi+0x0F/*IdeInitial.Lba48*/],1
		  jz __NEXT_1

		  mov [esi+0x11/*IdeCommand.Command*/],20h
		  mov [esi+0x10/*IdeCommand.Type*/],2	//3
		  mov eax,[esi/*+0x00 IdeCommand.LBA0*/]
		  shr eax,24d
		  and eax,0fh
		  or byte ptr[esi+0x08/*IdeCommand.Device*/],al
		  jmp dd1

		 __NEXT_1:
		  mov [esi+0x11/*IdeCommand.Command*/],24h   //24
		  mov [esi+0x10/*IdeCommand.Type*/],3		//3
		 dd1:
		  mov [esi+0x0A/*IdeCommand.Feature*/],0
		  mov eax,[esi+0x12/*IdeCommand.Buffer*/]
		  or eax,eax
		  jz Ide0
		  mov eax,[esi+0x16/*IdeCommand.BufLen*/]
		  or eax,eax
		  jz Ide0

		  push dword ptr[ebp+0ch]
		  push dword ptr[ebp+08h]
		  call IdeSendCommand
		  cmp eax,-1
		  jne Ide0
		  mov dword ptr[esp],1

		Ide0:
		pop eax
		pop ebx
		pop edi
		pop esi
		leave
		ret 8d
	}
}

//IDE LBA Write (false:timemout)
__declspec (naked)	BOOLEAN __stdcall IDELba48Write(long IdeInitial, long IdeCommand)
{
	__asm
	{
		push ebp
		mov ebp,esp
		push esi
		push edi
		push ebx
		push 0		//result

		  mov esi,[ebp+0ch]
		  or esi,esi
		  jz Ide1
		  mov edi,[ebp+8]
		  cmp byte ptr[edi+0x0F/*IdeInitial.Lba48*/],1
		  jz __NEXT_1

		  mov [esi+0x11/*IdeCommand.Command*/],30h	 //34
		  mov [esi+0x10/*IdeCommand.Type*/],4;4
		  mov eax,[esi/*+0x00 IdeCommand.LBA0*/]
		  shr eax,24d
		  and eax,0fh
		  or byte ptr[esi+0x08/*IdeCommand.Device*/],al
		  jmp dd2

		 __NEXT_1:
		  mov [esi+0x11/*IdeCommand.Command*/],34h	 //34
		  mov [esi+0x10/*IdeCommand.Type*/],5;4
		 dd2:
		  mov [esi+0x0A/*IdeCommand.Feature*/],0
		  mov eax,[esi+0x12/*IdeCommand.Buffer*/]
		  or eax,eax
		  jz Ide1
		  mov eax,[esi+0x16/*IdeCommand.BufLen*/]
		  or eax,eax
		  jz Ide1
		  push dword ptr[ebp+0ch]
		  push dword ptr[ebp+08h]
		  call IdeSendCommand
		  cmp eax,-1
		  jne Ide1
		  mov dword ptr[esp],1

		Ide1:
		pop eax
		pop ebx
		pop edi
		pop esi
		leave
		ret 8d
	}
}


//ע�⣡��---> ���������������"�豸���ܺ�"!!!!!
//Find a store device ( return:eax:bus number (end flag:-1) )
//       edx:device type
//       0--->SCSI       1--->IDE        2--->Floppy disk
//       3--->IPI        4--->RAID       5--->ATA DMA
//       6--->AHCI       7--->           8--->NVMHCI
//       80h--->Other
__declspec (naked)	long __stdcall PCISearchStoreDev(long BusNumber)
{
	__asm
	{
		push ebp
		mov ebp,esp
		push edi
		push esi
		push ebx
		push -1;result

		  push dword ptr[ebp+8]
		  mov ecx,7f0000ffh
		  not ecx		//ecx = 80ffff00
		  and [esp],ecx	//[esp] = 0x80ffff00 & 0x100 = 0x100
		  or dword ptr[esp],80000000h //[esp] = 0x80000000 & 0x100 = 0x80000100

		 __FLAG_1:
		  pop eax	// eax = [esp] = 0x80000100
		  cmp eax,81000000h //if( eax >= 0x81000000 )
		  jae pci0			//{
							//		goto pci0;
							//}

		  mov edx,0cf8h		// CONFIG_ADDRESS = 0x0cf8
		  out dx,eax		// 1 0000000 00000000 00000 001  000000   0 0
		  add eax,100h		// �豸�� ++
		  push eax			// ������һ��Ҫ���� ID��

		  mov edx,0cfch		//CONFIG_DATA = 0x0cfc
		  in eax,dx			// Deivce ID  Vendor ID
		  cmp eax,-1d		//if( eax == 0xffffffff )	// Vendor ID = 0xffff ��һ���Ƿ�����, ���ж�PCI�豸�Ƿ����
		  je __FLAG_1		//{
							//		goto __FLAG_1;
							//}

		//PCI�豸����,
		  mov edx,0cf8h
		  mov eax,[esp]		//eax = [esp] = ��һ�α���� CONFIG_ADDRESS = push eax = 0x80000200	, (�豸�� ++)
		  sub eax,100h		//�ָ�����⵽���ڵ�ID��
		  add eax,8			//0x80000108 = 1 0000000 00000000 00000 001  000010   0 0   ( 000010 = 2)	, ��ȡPCI�豸���ÿռ�ĵڶ����Ĵ��� Class Code + Rev ID
		  out dx,eax

		  mov edx,0cfch		//CONFIG_DATA = 0x0cfc
		  in eax,dx
		  shr eax,8			//Clase Code ռ�� 24λ, Rev ID ռ�� 8λ, ���� 8λ, ��ʣ�� Classe Code
		  mov ecx,eax		//ecx =  Classe Code, �����ֽڣ��ֱ��ǣ�����롢������롢��̽ӿ�
		  shr ecx,16d		//ecx = �����
		  cmp ecx,1			//if( ����� != 1 )
		  jne __FLAG_1		//{
							//		goto __FLAG_1;
							//}

		  sub dword ptr[esp],100h	//(����)�ָ�����⵽���ڵ�ID��
		  pop dword ptr[esp]		// esp = esp + 4
		  mov edx,eax				// edx = eax = Classe Code
		  shr edx,8					// edx = ����롢�������
		  and edx,0ffh				// edx = �������
		  and dword ptr[esp],7fffff00h	//(����) = dword ptr[esp] = 0x100 = 001  000000   0 0 = �����������豸��?

		pci0:
		pop eax	//eax = �豸��, edx = �������
		pop ebx	//�ָ���ջ���ָ��Ĵ���������.....
		pop esi
		pop edi
		leave
		ret 4
	}
}

// Find a IDE Device ( return:eax:bus number (end flag:-1) )
__declspec (naked)	long __stdcall IDESearch(long BusNumber)
{
	__asm
	{
		push ebp
		mov ebp,esp
		push edi
		push esi
		push ebx
		push -1		//result

		  push dword ptr[ebp+8]

		 __FLAG_1:
		  add dword ptr[esp],100h	// ��� BusNumber = 0, �� dword ptr[esp] = 0x100 + 0 = 0x100
		  call PCISearchStoreDev	// if( PCISearchStoreDev( BusNumber + 0x100 ) == -1 )
		  cmp eax,-1				// {
		  jz __FLAG_2				//		goto __FLAG_2;	//����ʧ��,û�е���
									// }

		  cmp edx,1		//��� PCI�豸 �� ������� �� 1, ����Ϊ�ҵ���,  ���� �ڵ�ǰ ���ߺ� �µ� �豸��
		  push eax
		  jnz __FLAG_1
		  pop dword ptr[esp]

		__FLAG_2:
		pop eax
		pop ebx
		pop esi
		pop edi
		leave
		ret 4
	}
}

//Probe a legal IDE Device  ( return:device bus number (failed:-1) )
__declspec (naked)	long __stdcall IDEProbeLegalDev(long IdeInitial, long StartBusNumber)
{
	__asm
	{
		push ebp
		mov ebp,esp
		push edi
		push esi
		push ebx
		push -1		//result


			mov edi,[ebp+8]		//if(IdeInitial == NULL)
			or edi,edi			//{
			jz ide3				//	return;
								//}

			push dword ptr[ebp+0ch]		//if(IDESearch( StartBusNumber ) == -1)
										//{
		   ide2:						//		return;
			call IDESearch				//}		
			cmp eax,-1					//else
			jz ide3						//{
										//		eax = ��ǰ�����µ��豸��;
										//}



			mov [edi+0x0E/*IdeInitial.Count*/],0	//IdeInitial.Count = 0;

			or eax,80000000h	//������� CONFIG_ADDRESS, �� 0x80000100
			mov ecx,eax			// ecx = CONFIG_ADDRESS
			add eax,10h			//1 0000000 00000000 00000 001  000100   0 0,  000100 = 4 = PCI���ÿռ�� Base Address Register 0 (BAR 0)
			mov edx,0cf8h
			out dx,eax

			mov edx,0cfch		//CONFIG_DATA
			in eax,dx
			test eax,1			//if( (eax & 0x01) == 0 ) goto __FLAG_1;
			jz __FLAG_1

			mov ebx,0fh
			not ebx			//ebx = 0xFFFFFFF0
			and eax,ebx		//���� eax �ĸ� 28λ, �� BAR 0 �� ��4λ ����
			jz __FLAG_1		//if(eax == 0) goto __FLAG_1;

			 //check	//���һ����� BAR 0 �Ƿ�����Ч(��ȷ)��?
			mov [edi/*+0x00 IdeInitial.CMDBase*/],ax		//BAR 0 �� ��16λ, ע�⣬�� ��16λ �� ��4λ �Ѿ�����, �� 0x01F0
			mov dx,ax	//dx = CMDBase���� 0x1F0
			add dx,7	//dx = Status/Command REGISTER, �� 0x1F0 + 7 = 0x1F7
			in al,dx	//�� �� 0x1F7 �˿� �� al
			cmp al,0ffh	//if(al == 0xff || al == 0x7f)
			jz __FLAG_1	//{
			cmp al,7fh	//	goto __FLAG_1;
			jz __FLAG_1	//}


			mov [edi+0x0A/*IdeInitial.Bus*/],ecx	//ecx = CONFIG_ADDRESS, �� 0x80000100, IdeInitial.Bus ���ǵ��������ߺţ���������豸�� ID��, ����˵�� CONFIG_ADDRESS
			mov eax,ecx
			add eax,14h	//eax = 0x80000114 = 1 0000000 00000000 00000 001  000101   0 0 , 000101 = 5, �� ��ȡ PCI���ÿռ� �� BAR 1

			mov edx,0cf8h
			out dx,eax
			mov edx,0cfch
			in eax,dx	// eax = BAR 1											//������ 0x03F6

			mov ebx,0fh
			not ebx		//ebx = 0xFFFFFFF0
			and eax,ebx	//���� eax �ĸ� 28λ, �� BAR 1 �� ��4λ ����			//��ô���� 0x03F6 & 0xFFFFFFF0 = 0x03F0

			add ax,2															//������� 0x03F2
			mov [edi+0x02/*IdeInitial.CTRBase*/],ax								//IdeInitial.CTRBase = 0x03F2  ????

			mov eax,ecx	//ecx = CONFIG_ADDRESS
			add eax,20h	//1 0000000 00000000 00000 001  001000   0 0, 001000 = 8 , ����ȡ PCI���ÿռ� �� BAR 4
			mov edx,0cf8h
			out dx,eax
			mov edx,0cfch
			in eax,dx

			mov ebx,0fh
			not ebx
			and eax,ebx
			mov [edi+0x04/*IdeInitial.Master*/],ax	//IdeInitial.Master = BAR 4 & 0xFFFFFFF0

			add [edi+0x0E/*IdeInitial.Count*/],1	// IdeInitial.Count ++


		   __FLAG_1:
			mov eax,ecx	//ecx = CONFIG_ADDRESS
			add eax,18h	//1 0000000 00000000 00000 001  000110   0 0, 000110 = 6, ����ȡ PCI���ÿռ� �� BAR 2
			mov edx,0cf8h
			out dx,eax
			mov edx,0cfch
			in eax,dx

			test eax,1
			push ecx	//���� CONFIG_ADDRESS, ���豸ID�ŵ�
			jz ii	//if( (BAR 2 & 0x01) == 0) goto ii;

			mov ebx,0fh
			not ebx
			and eax,ebx
			jz ii	//if( (BAR 2 & 0xFFFFFFF0) == 0 ) goto ii;

			//check	//���м��
			mov [edi+0x06/*IdeInitial.CMDBase0*/],ax	//IdeInitial.CMDBase0 = BAR 2 & 0x0000FFF0;
			mov dx,ax
			add dx,7
			in al,dx	//�� 0x01F0 + 7 = 0x1F7

			cmp al,0ffh	//if( al == 0xff || al == 0x7f)	goto ii;
			jz ii
			cmp al,7fh
			jz ii

			pop ecx   //ecx = CONFIG_ADDRESS, ���豸ID�ŵ�
			mov [edi+0x0A/*IdeInitial.Bus*/],ecx	//ecx = CONFIG_ADDRESS, �� 0x80000100, IdeInitial.Bus ���ǵ��������ߺţ���������豸�� ID��, ����˵�� CONFIG_ADDRESS 

			mov eax,ecx
			add eax,1ch	//1 0000000 00000000 00000 001  000111   0 0, 000111 = 7, ����ȡ PCI���ÿռ� �� BAR 3
			mov edx,0cf8h
			out dx,eax
			mov edx,0cfch
			in eax,dx

			mov ebx,0fh
			not ebx
			and eax,ebx
			add ax,2
			mov [edi+0x08/*IdeInitial.CTRBase0*/],ax	//IdeInitial.CTRBase0 = ( BAR 3 & 0x0000FFF0 ) + 2

			mov eax,ecx
			add eax,20h	//1 0000000 00000000 00000 001  001000   0 0, 001000 = 8, ����ȡ PCI���ÿռ� �� BAR 4
			mov edx,0cf8h
			out dx,eax
			mov edx,0cfch
			in eax,dx

			mov ebx,0fh
			not ebx
			and eax,ebx
			mov [edi+0x04/*IdeInitial.Master*/],ax	//IdeInitial.Master = BAR 4  & 0x0000FFF0

			add [edi+0x0E/*IdeInitial.Count*/],1	//IdeInitial.Count ++

			cmp [edi+0x0E/*IdeInitial.Count*/],1	//if(IdeInitial.Count > 1) goto __FALG_2;
			jnz __FLAG_2


			mov ax,[edi+0x06/*IdeInitial.CMDBase0*/]	// IdeInitial.CMDBase = IdeInitial.CMDBase0;
			mov [edi/*+0x00 IdeInitial.CMDBase*/],ax
			mov ax,[edi+0x08/*IdeInitial.CTRBase0*/]
			mov [edi+0x02/*IdeInitial.CTRBase*/],ax		//IdeInitial.CTRBase = IdeInitial.CTRBase0;
		   __FLAG_2:
			mov [esp],ecx	//ecx = CONFIG_ADDRESS, ���豸ID�ŵ�
			jmp ide3		// ide3: pop eax, eax = CONFIG_ADDRESS, ���豸ID�ŵ�

		   ii:
			cmp [edi+0x0E/*IdeInitial.Count*/],0	//if(IdeInitial.Count > 0)	goto __FLAG_2;	�ɹ�����
			jnz __FLAG_2
			jmp ide2								//else	goto ide2;   ide2: ��ͷ��ʼ call IDESearch ....

		ide3:
		pop eax	//���� CONFIG_ADDRESS, ���豸ID�ŵ�
		pop ebx
		pop esi
		pop edi
		leave
		ret 8d
	}
}


char		*g_pBuffer = NULL;
IDEINITIAL	g_IdeInitial;
IDECOMMAND	g_IdeCommand;

//IDE Initailing
BOOLEAN IDEInitial()
{
	BOOLEAN		bStatus = FALSE;
	char		cBuffer[1024];


	memset(&g_IdeInitial, 0, sizeof(g_IdeInitial));
	g_IdeInitial.CMDBase = 0x1F0;
	g_IdeInitial.CTRBase = 0x3F6;
	g_IdeInitial.Lba48 = 0;
	
	memset(&g_IdeCommand, 0, sizeof(g_IdeCommand));
	g_IdeCommand.LBA0 = 0;
	g_IdeCommand.Device = 0x40;
	g_IdeCommand.Counter = 1;
	g_IdeCommand.Buffer = (long)&cBuffer[0];
	g_IdeCommand.BufLen = 512;

	__asm
	{
		int		3;
	}

	memset(cBuffer, 0, sizeof(cBuffer));
	IDELba48Read((long)&g_IdeInitial, (long)&g_IdeCommand);

	//char	*g_pBuffer = (char*)ExAllocatePoolWithTag(NonPagedPool, 10000, 0x3366);
	//memset(g_pBuffer, 0, 10000);

	//memset(&g_IdeInitial, 0, sizeof(g_IdeInitial));
	//g_IdeInitial.CMDBase	= 0x1F0;
	//g_IdeInitial.CTRBase	= 0x3F6;
	//g_IdeInitial.Bus		= -1;
	//
	//memset(&g_IdeCommand, 0, sizeof(g_IdeCommand));
	//g_IdeCommand.Device		= 0x40;
	////g_IdeCommand.Control	= 0x0A;
	//g_IdeCommand.Buffer		= (long)g_pBuffer;
	//g_IdeCommand.BufLen		= 512;

	//g_IdeCommand.Counter	= 1;
	//g_IdeCommand.LBA0		= 0;

	//__asm
	//{
	//	int		3;
	//}

	//IDELba48Read((long)&g_IdeInitial, (long)&g_IdeCommand);


	return bStatus;
}