#include <Windows.h>



//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//

//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//

//--------------------------------------------------------------------------//

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//�������̫��,���в��
void ProcessClusterList(DWORD *pdwList)
{
	DWORD	*pdwSrcEnd, *pdwCurEnd, *pdwMove;

	pdwSrcEnd = pdwList;
	while( *pdwSrcEnd != 0)
	{
		pdwSrcEnd ++;
	}

	pdwCurEnd = pdwSrcEnd;
	pdwMove = pdwList;
	while(pdwMove != pdwSrcEnd)
	{
		DWORD	dwCurLen, dwRemianLen;

		dwCurLen = *pdwMove;
		if(dwCurLen > 10)	//��� 10����, 80������, 40960�ֽ�, 0xA000�ֽ�;
		{
			dwRemianLen = dwCurLen - 10;
			*pdwMove = dwRemianLen;

			*pdwCurEnd = 10;
			pdwCurEnd ++;
			*pdwCurEnd = *(pdwMove+1) + dwRemianLen;
			pdwCurEnd ++;
			*pdwCurEnd = 0;

			continue;
		}
		else
		{
			pdwMove = pdwMove + 2;
		}
	}

	return;
}

__declspec (naked)	void ProcessCluster_ASM(void)
{
	__asm
	{
		ProcessClusterList:
		cmp         dword ptr [ecx],0 
		push        edi  
		mov         edi,ecx 
		je          ProcessClusterLis_2
		ProcessClusterLis_1:
		add         edi,4 
		cmp         dword ptr [edi],0 
		jne         ProcessClusterLis_1
		ProcessClusterLis_2:
		mov         eax,edi 
		cmp         ecx,edi 
		je          ProcessClusterLis_6
		push        ebx  
		ProcessClusterLis_3:
		mov         edx,dword ptr [ecx] 
		cmp         edx,0Ah 
		jbe         ProcessClusterLis_4
		add         edx,0FFFFFFF6h 
		mov         dword ptr [ecx],edx 
		mov         dword ptr [eax],0Ah 
		mov         ebx,dword ptr [ecx+4] 
		add         eax,4 
		add         ebx,edx 
		mov         dword ptr [eax],ebx 
		add         eax,4 
		and         dword ptr [eax],0 
		jmp         ProcessClusterLis_5
		ProcessClusterLis_4:
		add         ecx,8 
		ProcessClusterLis_5:
		cmp         ecx,edi 
		jne         ProcessClusterLis_3
		pop         ebx 
		ProcessClusterLis_6:
		pop         edi  
		ret 
	}
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	DWORD	dwClusterList[50] = {1, 17, 23, 53, 6, 80, 0, 0, 0}; 
	DWORD	dwClusterList_2[50] = {17, 1, 52, 23, 80, 6, 27, 85, 0}; 


	__asm
	{

		lea		ecx, [dwClusterList]
		call	ProcessCluster_ASM;
	}

	ProcessClusterList( dwClusterList );

	ExitProcess( 0 );
}