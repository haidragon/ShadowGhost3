#include <Windows.h>
#include <shlwapi.h>


//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//

//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//

//--------------------------------------------------------------------------//

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//���ļ����ڴ�, ������ڴ��ɵ������ͷ�
BOOL ReadFileInMem(char *pFilePath, char **pFileByteParam, DWORD *dwFileSizeParam)
{
	BOOL				bStatus = FALSE;
	char				*pFileByte = NULL;
	HANDLE				hFile = INVALID_HANDLE_VALUE;
	DWORD				dwFileSize = 0, dwByte = 0, dwTotalRead = 0, dwCurrentRead = 0;


	if(PathFileExists( pFilePath ) == FALSE)
	{
		goto __END;
	}

	for(int i = 0; i < 50; i++)
	{
		hFile = CreateFile(pFilePath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
		if(hFile != INVALID_HANDLE_VALUE)
		{
			break;
		}
		Sleep( 100 );
	}

	dwFileSize = GetFileSize(hFile, NULL);
	if(dwFileSize == 0 || dwFileSize == INVALID_FILE_SIZE)
	{
		goto __END;
	}

	pFileByte = (char*)VirtualAlloc(NULL, dwFileSize, MEM_RESERVE|MEM_COMMIT, PAGE_READWRITE);
	if(pFileByte == NULL)
	{
		goto __END;
	}

	dwCurrentRead = dwFileSize;
	while(dwTotalRead < dwFileSize)
	{
		if( ReadFile(hFile, pFileByte, dwCurrentRead, &dwByte, NULL) == FALSE )
		{
			goto __END;
		}

		dwTotalRead = dwTotalRead + dwByte;
		dwCurrentRead = dwFileSize - dwTotalRead;
	}

	bStatus = TRUE;

__END:
	if(hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle( hFile );
	}

	if(bStatus == FALSE)
	{
		if(pFileByte != NULL)
		{
			VirtualFree(pFileByte, 0, MEM_RELEASE);
		}
		
		*pFileByteParam = NULL;
		*dwFileSizeParam = 0;
	}
	else
	{
		*pFileByteParam = pFileByte;
		*dwFileSizeParam = dwFileSize;
	}

	return bStatus;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	char	*pSFC = NULL;
	DWORD	dwSFCSSize = 0;


	ReadFileInMem("C:\\Windows\\System32\\sfc.dll", &pSFC, &dwSFCSSize);
	if(pSFC == NULL)
	{
		MessageBox(NULL, "�޷���ȡ SFC.dll", "Error", MB_ICONERROR);
		goto __END;
	}

	if(*(DWORD*)(pSFC + 0x3C) == 0x000000D8 && *(DWORD*)(pSFC + 0x13F0) == 0x00000000)
	{
		MessageBox(NULL, " SFC.dll û�б���д��", "Error", MB_ICONERROR);
	}
	else
	{
		MessageBox(NULL, " ===> SFC.dll <==== ���ܣ�ֻ�ǿ��ܣ� ����д�ˣ� ����", "OK", MB_OK);
	}


__END:
	if(pSFC != NULL)
	{
		VirtualFree(pSFC, 0, MEM_RELEASE);
	}

	ExitProcess( 0 );
}