////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#include "Common.h"

//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//

//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
void	CTLBreak(BOOLEAN bStatus);
//--------------------------------------------------------------------------//
#ifdef	__cplusplus
extern	"C" 
#endif
__declspec(dllimport)
NTSTATUS
PsLookupProcessByProcessId(
	IN ULONG ProcessId,
	OUT PEPROCESS *Process
);

typedef	NTSTATUS (__stdcall *XP_PspTerminateThreadByPointer)(
    IN PETHREAD Thread,
    IN NTSTATUS ExitStatus
);
typedef	NTSTATUS (__stdcall *DEF_PspTerminateThreadByPointer)(
    IN PETHREAD Thread,
    IN NTSTATUS ExitStatus,
	IN ULONG	Unknow
);

XP_PspTerminateThreadByPointer	fnXPTerminate	= NULL;
DEF_PspTerminateThreadByPointer	fnTerminate		= NULL;


BOOLEAN	g_bKillProInit = FALSE, g_bIsHookPTTBP = FALSE, g_bIsHookKeIQA = FALSE, g_bIsHookKiIQA = FALSE;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
NTSTATUS KillProcess(ULONG ulProcessId)
{
	PEPROCESS	pEProcess = NULL;
	PETHREAD	pEThread = NULL;
	PLIST_ENTRY	ListHead = NULL, Entry = NULL;



	if(fnTerminate == NULL && g_bKillProInit == TRUE)
	{
		return STATUS_UNSUCCESSFUL;
	}

	if(fnTerminate == NULL)	//ע��, ring3һ��Ҫ��֤��Щ��ַ��ȷ,������ܱ�֤����ȷ, �뽫��ַ��Ϊ 0
	{
		g_bKillProInit = TRUE;

		if(g_InitialDirver.dwAddr_PspTerminateThreadByPointer != 0)
		{
			fnTerminate = (DEF_PspTerminateThreadByPointer)g_InitialDirver.dwAddr_PspTerminateThreadByPointer;
			fnXPTerminate = (XP_PspTerminateThreadByPointer)g_InitialDirver.dwAddr_PspTerminateThreadByPointer;

			//PspTerminateThreadByPointer�Ƿ�Hook
			if(*(DWORD*)fnTerminate != *(DWORD*)&g_InitialDirver.cPspTerminateThreadByPointerHead[0])
			{
				g_bIsHookPTTBP = TRUE;
			}
		}

		//KeInsertQueueApc�Ƿ�Hook
		if(g_InitialDirver.dwAddr_KeInsertQueueApc != 0)
		{
			if(*(DWORD*)g_InitialDirver.dwAddr_KeInsertQueueApc != *(DWORD*)&g_InitialDirver.cKeInsertQueueApcHead[0])
			{
				g_bIsHookKeIQA = TRUE;
			}
		}

		//KiInsertQueueApc�Ƿ�Hook
		if(g_InitialDirver.dwAddr_KiInsertQueueApc != 0)
		{
			if(*(DWORD*)g_InitialDirver.dwAddr_KiInsertQueueApc != *(DWORD*)&g_InitialDirver.cKiInsertQueueApcHead[0])
			{
				g_bIsHookKiIQA = TRUE;
			}
		}
	}

	if( PsLookupProcessByProcessId(ulProcessId, &pEProcess) != STATUS_SUCCESS )
	{
		return STATUS_UNSUCCESSFUL;
	}

	__try
	{
		//�����߳�,�������
		ListHead = (PLIST_ENTRY)((ULONG)pEProcess + g_InitialDirver.dwThreadListHeadOffset);
		Entry = ListHead->Flink;

		while(Entry != ListHead && MmIsAddressValid( Entry ) == TRUE)
		{
			pEThread = (PETHREAD)((ULONG)Entry - g_InitialDirver.dwThreadListEntryOffset );
			if ( ObReferenceObjectByPointer( pEThread, 0, NULL, KernelMode) == STATUS_SUCCESS)
			{
				KIRQL	OldIrql;


				ObfDereferenceObject( pEThread );

				//�ָ���InlineHook�ĵط�
				OldIrql = KfRaiseIrql( DISPATCH_LEVEL );
				CTLBreak( FALSE );

				if(g_bIsHookPTTBP == TRUE)
				{
					memcpy((char*)fnTerminate, g_InitialDirver.cPspTerminateThreadByPointerHead, sizeof(g_InitialDirver.cPspTerminateThreadByPointerHead));
				}
				if(g_bIsHookKeIQA == TRUE)
				{
					memcpy((char*)g_InitialDirver.dwAddr_KeInsertQueueApc, g_InitialDirver.cKeInsertQueueApcHead, sizeof(g_InitialDirver.cKeInsertQueueApcHead));
				}
				if(g_bIsHookKiIQA == TRUE)
				{
					memcpy((char*)g_InitialDirver.dwAddr_KiInsertQueueApc, g_InitialDirver.cKiInsertQueueApcHead, sizeof(g_InitialDirver.cKiInsertQueueApcHead));
				}

				CTLBreak( TRUE );
				KfLowerIrql( OldIrql );

				//���� PspTerminateThreadByPointer
				if(g_OSVersionInfo.dwMajorVersion == 5 && g_OSVersionInfo.dwMinorVersion <= 1)
				{
					fnXPTerminate(pEThread, 0);
				}
				else
				{
					fnTerminate(pEThread, 0, 0);
				}
			}

			Entry = Entry->Flink;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		return STATUS_UNSUCCESSFUL;
	}

	return STATUS_SUCCESS;
}