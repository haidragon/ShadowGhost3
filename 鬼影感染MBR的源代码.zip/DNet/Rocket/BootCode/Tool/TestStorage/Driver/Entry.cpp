#include "Common.h"


//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//

//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
NTSTATUS	DiskInitial(DWORD dwHDDId);
NTSTATUS	DiskReadWrite(PIRP  pIrp);
//--------------------------------------------------------------------------//

#define	DEVICENAME	L"\\Device\\TestStorage"
#define	SYMBOLLINK	L"\\??\\TestStorage"


UNICODE_STRING		g_usSymbolLink;
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

NTSTATUS DispatchDeviceControl(IN PDEVICE_OBJECT  DeviceObject, IN PIRP  pIrp)
{
	NTSTATUS			ntStatus = 0;
	PIO_STACK_LOCATION	pIrpStack = NULL;

	

	pIrpStack = IoGetCurrentIrpStackLocation( pIrp );

	switch( pIrpStack->Parameters.DeviceIoControl.IoControlCode )
	{
		case IOCTL_DISK_INITIAL:
			{
				ntStatus = DiskInitial( *(DWORD*)pIrp->AssociatedIrp.SystemBuffer);
			}
			break;
		case IOCTL_DISK_READWRITE:
			{
				ntStatus = DiskReadWrite( pIrp );
			}
			break;
		default:
			break;
	}

	pIrp->IoStatus.Status = ntStatus;
	pIrp->IoStatus.Information = 0;
	IofCompleteRequest(pIrp, IO_NO_INCREMENT);

	return ntStatus;
}

void DriverUnload(PDRIVER_OBJECT pDriverObj)
{
	IoDeleteSymbolicLink( &g_usSymbolLink );
	IoDeleteDevice(pDriverObj->DeviceObject);

	return;
}

NTSTATUS DisPatchCreateClose(PDEVICE_OBJECT pDriverObj, PIRP pIrp)
{
	pIrp->IoStatus.Status = STATUS_SUCCESS;
	pIrp->IoStatus.Information = 0;
	IofCompleteRequest(pIrp, IO_NO_INCREMENT);

	return STATUS_SUCCESS;
}

#ifdef	__cplusplus
extern	"C" 
#endif
NTSTATUS DriverEntry( IN PDRIVER_OBJECT DriverObject, IN PUNICODE_STRING theRegistryPath )
{
	NTSTATUS		ntStatus = 0;
	UNICODE_STRING	DeviceName;
	PDEVICE_OBJECT	pDeviceObject = NULL;


	RtlInitUnicodeString(&DeviceName, DEVICENAME);
	ntStatus = IoCreateDevice(DriverObject, 0, &DeviceName, FILE_DEVICE_UNKNOWN, 0, FALSE, &pDeviceObject);
	if(ntStatus != STATUS_SUCCESS)
	{
		return ntStatus;
	}

	pDeviceObject->Flags = pDeviceObject->Flags|DO_DIRECT_IO;

	RtlInitUnicodeString(&g_usSymbolLink, SYMBOLLINK);
	ntStatus = IoCreateSymbolicLink(&g_usSymbolLink, &DeviceName);
	if(ntStatus != STATUS_SUCCESS)
	{
		IoDeleteDevice( pDeviceObject );
		return ntStatus;
	}

	//��������
	for(int i= 0; i < IRP_MJ_MAXIMUM_FUNCTION; ++i)
		DriverObject->MajorFunction[i] = DisPatchCreateClose;
	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]	= DispatchDeviceControl;
	DriverObject->DriverUnload							= DriverUnload;

	return ntStatus;
}